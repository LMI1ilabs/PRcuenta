# AGENTS.md

## Project

Puerto Rico Cuenta is a bilingual (ES/EN) advocacy and education site about the proposed 2030 Census rule (15 CFR Parts 60 and 70, FR Doc 2026-18481, docket USBC-2026-0628). It focuses on how the rule would affect Puerto Rico and the diaspora. It is modeled on handsoffourcens.us.

## Stack

TanStack Start (React 19, Vite 7) deployed on Netlify · Tailwind CSS 4 · Netlify Database with Drizzle ORM (`drizzle-orm@beta`) · Netlify Image CDN.

## Layout

```
db/schema.ts, db/index.ts      Drizzle schema (pledges table) and client
netlify/database/migrations/   Generated migrations (never edit applied ones)
public/img/                    Generated artwork (hero.png, island.png); always serve via cdn() in src/lib/img.ts
src/content/                   ALL campaign copy and facts, bilingual
  site.ts                      Rule identifiers, deadline, official links (single source of truth)
  rule.ts                      Per-section explainer: plain text, verbatim quote, PR impact
  comment.ts                   Comment-builder paragraphs and commenter roles
  faq.ts, toolkit.ts           FAQ, talking points, grouped social posts, organizing steps, letter to elected officials
  impact.ts                    /impacto: addresses, surnames, tax records, funding scenario, electoral districts, asks
  diaspora.ts                  /quienes-somos: Part 70, the Hispanic-origin question, diaspora and race data
  municipios.ts                78 municipios + diaspora states; PLACES is the allow-list for the API
src/lib/i18n.tsx               LangProvider/useLang; copy is typed as L = { es, en }, render with t(copy)
src/components/                Header (with deadline bar), Footer, Countdown, Tracker, PledgeForm, CommentBuilder, ContactForm, ui
src/routes/                    index, la-regla, impacto, quienes-somos, comenta, herramientas, preguntas, api/pledges (GET stats, POST pledge)
public/__forms.html            Static skeleton that registers the "contacto" Netlify Form; ContactForm posts to it
```

## Conventions and decisions

- **Every user-facing string is bilingual.** Write `t({ es: '…', en: '…' })`, or put the copy in `src/content`. Spanish is the default and is what the server renders. The language choice is restored from localStorage after hydration.
- **Time-dependent UI renders after mount.** This covers the countdown and anything that reads `window`, and avoids hydration mismatches.
- **The tracker is aggregate-only.** `GET /api/pledges` returns counts by place and never returns names or emails. A POST with an email that already exists updates that row instead of adding a new one. The hidden `website` field is a honeypot.
- **The comment builder is client-only.** Drafts are never sent to the server.
- **The contact form uses Netlify Forms.** Any new field must be added to `public/__forms.html` too.
- **Estimates are labeled.** The funding-loss figure on /impacto is an illustrative scenario with its assumptions stated; keep it labeled that way.
- **Accuracy matters.** Rule quotes are verbatim from the Federal Register text. Phrase claims about Puerto Rico as concerns or open questions unless the source supports them, because the rule itself never mentions Puerto Rico.
- **Visual language.** A two-ink risograph look: `ink` navy and `coral` on `paper` cream. Utilities include `riso-shadow`, `riso-text`, and `halftone`. Display font is Bricolage Grotesque; body and mono are IBM Plex.
