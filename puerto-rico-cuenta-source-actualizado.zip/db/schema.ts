import { pgTable, serial, text, timestamp, boolean, index } from 'drizzle-orm/pg-core'

// One row per person who joins the public tracker. Only aggregate counts are
// ever exposed publicly; name and email stay private for organizer follow-up.
export const pledges = pgTable(
  'pledges',
  {
    id: serial().primaryKey(),
    name: text(),
    email: text(),
    // Municipio of Puerto Rico, or "diaspora:<state>" for Puerto Ricans stateside.
    place: text().notNull(),
    role: text().notNull(),
    // "pledged" (will comment) or "commented" (already submitted).
    status: text().notNull(),
    language: text().notNull().default('es'),
    contactOk: boolean('contact_ok').notNull().default(false),
    createdAt: timestamp('created_at').notNull().defaultNow(),
  },
  (t) => [index('pledges_place_idx').on(t.place)],
)
