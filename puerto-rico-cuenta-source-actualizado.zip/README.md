# Puerto Rico Cuenta

A bilingual (Spanish and English) public-benefit campaign site. It helps Puerto Rico and the Puerto Rican diaspora understand the Census Bureau's proposed 2030 Census rule (15 CFR Parts 60 and 70, docket USBC-2026-0628) and send in a public comment before **November 2, 2026**. The site is modeled on the national [Hands Off Our Census](https://handsoffourcens.us) campaign and focuses on Puerto Rico. It also makes the broader case for public and open federal data.

## What's on the site

- **Home (`/`)**: the hero with a live countdown, the three key changes, why they matter for Puerto Rico, a three-step action plan, a live tracker of all 78 municipios, and the pledge form.
- **The rule (`/la-regla`)**: a section-by-section plain-language explainer. Each section shows the verbatim proposed text and its impact on Puerto Rico, followed by questions the Bureau has left unanswered.
- **Comment builder (`/comenta`)**: visitors pick their concerns, add their own story, and generate a formal comment in English, Spanish, or both. They can copy it, download it, or open Regulations.gov to submit it. Nothing typed here is stored.
- **Toolkit (`/herramientas`)**: talking points, ready-to-share social posts, WhatsApp sharing, a guide to running a comment-a-thon, and further reading.
- **FAQ (`/preguntas`)**.

## Tech

- [TanStack Start](https://tanstack.com/start) (React 19, file-based routing, server routes) on Netlify
- Tailwind CSS 4 with a custom risograph-inspired theme
- Netlify Database (managed Postgres) with Drizzle ORM for the pledge tracker
- Netlify Image CDN for the artwork, which was generated with Netlify AI Gateway

## Running locally

```bash
pnpm install
netlify dev        # runs the app with Netlify Database emulation
```

Database migrations live in `netlify/database/migrations/` and are applied automatically on deploy. After changing `db/schema.ts`, run `npx drizzle-kit generate --name <change>`.

## Updating campaign facts

All rule identifiers, the deadline, and the official links are in `src/content/site.ts`. If the Bureau extends the deadline again or publishes a final rule, update that file.

## Possible next steps

- Add a contact address and a partners section once coalition organizations sign on
- Add a private organizer export of the pledges that opted in to contact
- Add events (webinars, comment-a-thons) as they are scheduled
