import type { L } from '@/lib/i18n'

export const TALKING_POINTS: L[] = [
  { es: 'El texto de la regla no menciona a Puerto Rico ni una vez. Exigimos claridad.', en: 'The rule’s text never mentions Puerto Rico once. We demand clarity.' },
  { es: 'Sin la pregunta de origen hispano, el Censo no puede identificar a los más de 5.8 millones de boricuas en la diáspora.', en: 'Without the Hispanic-origin question, the Census cannot identify the more than 5.8 million Puerto Ricans in the diaspora.' },
  { es: 'La mayoría de los residentes de Puerto Rico rinde planilla en Hacienda, no en el IRS, y la regla no aclara si el Censo usaría esas planillas. Aun si las usara, cerca de un tercio de la población no rinde planilla y está en la economía informal (Caraballo-Cueto), y muchas planillas usan un apartado o una ruta rural como dirección.', en: 'Most Puerto Rico residents file with Hacienda, not the IRS, and the rule doesn’t say whether the Census would use those returns. Even if it did, about one-third of the population doesn’t file and works in the informal economy (Caraballo-Cueto), and many returns list a P.O. box or rural route as the address.' },
  { es: 'Entre el 40% y el 60% de las estructuras en Puerto Rico no tienen una dirección física de calle y número (city-style) que los sistemas federales puedan validar, parear o ubicar en un mapa. Un apartado o una ruta rural no prueba dónde vives.', en: 'An estimated 40% to 60% of structures in Puerto Rico have no physical street-and-number (city-style) address that federal systems can validate, match, or map. A P.O. box or rural route doesn’t prove where you live.' },
  { es: 'La regla de los 89 días (del 3 de enero al 1 de abril) no refleja la vida boricua: estudiantes, cuidadores y trabajadores que pasan parte del año en los estados podrían contarse en el lugar equivocado, dos veces o ninguna.', en: 'The 89-day rule (January 3 to April 1) doesn’t reflect Puerto Rican life: students, caregivers, and workers who spend part of the year in the states could be counted in the wrong place, twice, or not at all.' },
  { es: 'Los datos del Censo son datos abiertos: con ellos se redibujan los distritos electorales de Puerto Rico y se planifican la salud pública, la recuperación de desastres y la economía.', en: 'Census data are open data: they are used to redraw Puerto Rico’s electoral districts and to plan public health, disaster recovery, and the economy.' },
  { es: 'Comentar es gratis, toma 15 minutos y queda en el récord oficial.', en: 'Commenting is free, takes 15 minutes, and becomes part of the official record.' },
]

// `{dias}` is replaced with the live number of days left once the page mounts.
export const DAYS_TOKEN = '{dias}'

export const SOCIAL_GROUPS: { title: L; posts: L[] }[] = [
  {
    title: { es: 'Lo esencial', en: 'The essentials' },
    posts: [
      {
        es: 'La propuesta del Censo 2030 no menciona a Puerto Rico ni una vez, pero eliminaría el encasillado “puertorriqueño”. Tienes hasta el 2 de noviembre para comentar. #PRCuenta',
        en: 'The 2030 Census proposal never mentions Puerto Rico, but it would eliminate the “Puerto Rican” checkbox. You have until Nov 2 to comment. #PRCuenta',
      },
      {
        es: 'Los datos abiertos empiezan con el Censo. Si no nos cuentan, no existimos en los datos. Comenta en la regla USBC-2026-0628. #PRCuenta',
        en: 'Open data starts with the Census. If we aren’t counted, we don’t exist in the data. Comment on rule USBC-2026-0628. #PRCuenta',
      },
    ],
  },
  {
    title: { es: 'Récords contributivos', en: 'Tax records' },
    posts: [
      {
        es: 'La regla del Censo usaría récords contributivos para probar dónde vives. ¿Usarían las planillas de Hacienda? No lo dice. Y un tercio de Puerto Rico no rinde planilla. ¿Entonces contamos? Comenta antes del 2 de noviembre. #PRCuenta',
        en: 'The Census rule would use tax records to prove where you live. Would it use Hacienda returns? It doesn’t say. And a third of Puerto Rico doesn’t file. So do we count? Comment before Nov 2. #PRCuenta',
      },
      {
        es: '¿Cobras en efectivo, trabajas por tu cuenta o vives de tu retiro? Si la residencia depende de récords contributivos, podrías quedar fuera del conteo. Comenta en USBC-2026-0628. #PRCuenta',
        en: 'Paid in cash, self-employed, or living on your pension? If residence depends on tax records, you could be left out of the count. Comment on USBC-2026-0628. #PRCuenta',
      },
    ],
  },
  {
    title: { es: 'Direcciones', en: 'Addresses' },
    posts: [
      {
        es: 'Carretera 2, km 14.3. Así se llega a muchas casas en Puerto Rico. Se estima que entre el 40% y el 60% de las estructuras no tienen una dirección que los sistemas federales puedan validar, parear ni ubicar en un mapa. Comenta antes del 2 de noviembre. #PRCuenta',
        en: 'Road 2, km 14.3. That’s how you find many homes in Puerto Rico. An estimated 40–60% of structures have no address that federal systems can validate, match, or map. Comment before Nov 2. #PRCuenta',
      },
      {
        es: 'Tu dirección postal no es donde vives. Un apartado o la casa de un familiar no te ubica en tu barrio. La regla podría contarte en el lugar equivocado, o no contarte. #PRCuenta',
        en: 'Your mailing address isn’t where you live. A P.O. box or a relative’s house doesn’t place you in your barrio. The rule could count you in the wrong place, or not at all. #PRCuenta',
      },
      {
        es: 'En 2020, a Puerto Rico no le faltaron récords: no cuadraban. El 9.8% de los conteos fueron erróneos, mayormente duplicados. La nueva regla depende aún más de esos récords. #PRCuenta',
        en: 'In 2020, Puerto Rico didn’t lack records; they didn’t match. 9.8% of enumerations were erroneous, mostly duplicates. The new rule leans even harder on those records. #PRCuenta',
      },
    ],
  },
  {
    title: { es: 'Diáspora y migración circular', en: 'Diaspora and circular migration' },
    posts: [
      {
        es: '¿Estudias en los estados y vuelves en verano? ¿Pasas parte del año cuidando a mami en Puerto Rico? La regla de los 89 días (del 3 de enero al 1 de abril) no explica dónde te contarían. #PRCuenta',
        en: 'Study in the states and come home for summer? Spend part of the year caring for mami in Puerto Rico? The 89-day rule (January 3 to April 1) never says where you’d be counted. #PRCuenta',
      },
      {
        es: '¿Vives entre Puerto Rico y los estados? El Censo propone definir tu residencia con la regla de los 89 días (del 3 de enero al 1 de abril) y tus récords contributivos. Comenta antes del 2 de noviembre. #PRCuenta',
        en: 'Live between Puerto Rico and the states? The Census proposes defining your residence with the 89-day rule (January 3 to April 1) and your tax records. Comment before Nov 2. #PRCuenta',
      },
    ],
  },
  {
    title: { es: 'Lo que está en juego', en: 'What’s at stake' },
    posts: [
      {
        es: 'Un conteo cada diez años decide fondos de salud, nutrición, escuelas y carreteras en los 78 municipios. Quien no se cuenta igual necesita un CDT, una escuela y un plan para el próximo huracán. #PRCuenta',
        en: 'One count every ten years shapes funds for health, nutrition, schools, and roads in all 78 municipios. Whoever isn’t counted still needs a clinic, a school, and a plan for the next hurricane. #PRCuenta',
      },
      {
        es: 'Después de María, Fiona y los terremotos, la recuperación se planificó con datos del Censo por barrio. Sin datos locales, no hay plan. Comenta antes del 2 de noviembre. #PRCuenta',
        en: 'After Maria, Fiona, and the earthquakes, recovery was planned with Census data by barrio. Without local data, there’s no plan. Comment before Nov 2. #PRCuenta',
      },
      {
        es: 'En 2020 cambió mucho cómo Puerto Rico se identificó por raza. La regla prohibiría esas preguntas en el Censo 2030 y perderíamos la única medida completa de quiénes somos. #PRCuenta',
        en: 'In 2020, how Puerto Rico identified by race changed a lot. The rule would ban those questions in 2030, and we’d lose the only full measure of who we are. #PRCuenta',
      },
      {
        es: '¿Tienes un negocio? Dónde abrir, a quién contratar, cuánta demanda hay: todo empieza con datos del Censo. Datos malos cuestan dinero. Comenta como empresa en USBC-2026-0628. #PRCuenta',
        en: 'Run a business? Where to open, whom to hire, how much demand there is: it all starts with Census data. Bad data costs money. Comment as a business on USBC-2026-0628. #PRCuenta',
      },
      {
        es: 'Con los datos del Censo se redibujan los 40 distritos representativos y 8 senatoriales de Puerto Rico. Si el conteo sale mal, los mapas también. #PRCuenta',
        en: 'Census data are used to redraw Puerto Rico’s 40 house and 8 senate districts. If the count is wrong, so are the maps. #PRCuenta',
      },
    ],
  },
  {
    title: { es: 'Cómo comentar', en: 'How to comment' },
    posts: [
      {
        es: 'Comentar es gratis, toma unos 15 minutos y queda en el récord oficial. Di quién eres, tu municipio y un ejemplo local. Fecha límite: 2 de noviembre. #PRCuenta',
        en: 'Commenting is free, takes about 15 minutes, and goes on the official record. Say who you are, your municipio, and a local example. Deadline: Nov 2. #PRCuenta',
      },
      {
        es: 'Un comentario con tu historia pesa más que mil copias iguales. Cuenta qué servicio o decisión en tu comunidad depende del Censo. #PRCuenta',
        en: 'One comment with your story outweighs a thousand identical copies. Tell them which service or decision in your community depends on the Census. #PRCuenta',
      },
      {
        es: 'Tus respuestas al Censo son confidenciales por ley y no se comparten con otras agencias. Lo que está en juego no es tu privacidad, es si te cuentan. #PRCuenta',
        en: 'Your Census answers are confidential by law and aren’t shared with other agencies. What’s at stake isn’t your privacy; it’s whether you’re counted. #PRCuenta',
      },
      {
        es: `Quedan ${DAYS_TOKEN} días para comentar. Puerto Rico no aparece en la propuesta del Censo 2030. Que aparezca en los comentarios. #PRCuenta`,
        en: `${DAYS_TOKEN} days left to comment. Puerto Rico doesn’t appear in the 2030 Census proposal. Let it appear in the comments. #PRCuenta`,
      },
    ],
  },
]

export const ORGANIZE_STEPS: { title: L; body: L }[] = [
  {
    title: { es: 'Convoca un “comment-a-thon”', en: 'Host a comment-a-thon' },
    body: {
      es: 'Reserva una hora en tu centro comunal, iglesia, biblioteca, universidad o por Zoom. Lleva laptops o usa celulares. La meta: que cada persona salga habiendo enviado su comentario.',
      en: 'Book an hour at your community center, church, library, university, or on Zoom. Bring laptops or use phones. The goal: everyone leaves having submitted a comment.',
    },
  },
  {
    title: { es: 'Explica en 5 minutos', en: 'Explain it in 5 minutes' },
    body: {
      es: 'Usa las páginas “La regla” e “Impacto en PR” de este sitio web. Enfócate en las dos o tres preocupaciones que más le importan a tu comunidad.',
      en: 'Use this site’s “The rule” and “Impact on PR” pages. Focus on the two or three concerns that matter most to your community.',
    },
  },
  {
    title: { es: 'Escriban juntos, envíen por separado', en: 'Write together, submit separately' },
    body: {
      es: 'Usen el generador de comentarios y pide a cada persona que añada su historia. Los mensajes pueden ser parecidos, pero no idénticos: los comentarios personales pesan más que las copias.',
      en: 'Use the comment builder and ask each person to add their own story. Messages can be similar but not identical: personal comments carry more weight than copies.',
    },
  },
  {
    title: { es: 'Súmense al mapa', en: 'Add yourselves to the map' },
    body: {
      es: 'Después de enviar, que cada persona se registre en el contador para que su municipio aparezca. Así mostramos que todo Puerto Rico está presente.',
      en: 'After submitting, have everyone sign the tracker so their municipio shows up. That’s how we show all of Puerto Rico is present.',
    },
  },
]

// Meeting request to an elected official or agency head. Brackets are for the sender to fill in.
export const OFFICIAL_LETTER: L = {
  es: `[Fecha]

[Nombre del oficial electo]
[Cargo]
San Juan, Puerto Rico

Estimado/a [nombre del oficial electo]:

Reciba un cordial saludo de parte de la iniciativa Puerto Rico Cuenta y [organización co-firmante]. Somos un colectivo cívico que prioriza el uso de datos para el bienestar social, el crecimiento económico y la política pública en Puerto Rico. [Una oración sobre la organización co-firmante y su misión.]

Solicitamos respetuosamente una reunión urgente para dialogar sobre la regla propuesta por el Negociado del Censo de los Estados Unidos para el Censo 2030 (15 CFR Partes 60 y 70; 91 FR 57524; expediente USBC-2026-0628). El periodo de comentarios públicos cierra el 2 de noviembre de 2026. La regla no menciona a Puerto Rico ni una sola vez; sin embargo, regirá cómo se cuentan los 3.2 millones de personas que viven en Puerto Rico y cómo se identifican los más de 5.8 millones de puertorriqueños en los estados.

El censo decenal es la base de casi todas las cifras con las que Puerto Rico planifica y recibe fondos federales: la Encuesta sobre la Comunidad de Puerto Rico (PRCS), la Encuesta de Grupo Trabajador, las tasas de salud y pobreza, la planificación de Medicaid y del Programa de Asistencia Nutricional, la redistribución de los distritos electorales y la recuperación tras desastres por barrio y sector censal. Un error en 2030 se arrastraría hasta 2040. El propio análisis de impacto del Negociado reconoce que las estimaciones de la Encuesta sobre la Comunidad “will become less reliable” y que no existen fuentes comparables para sustituir los datos de raza y etnicidad del censo.

Las implicaciones para Puerto Rico son profundas. La regla:

• Exige que la residencia se evidencie con récords contributivos. La mayoría de los residentes de Puerto Rico rinde planilla ante el Departamento de Hacienda y no ante el IRS. Se asume que el Negociado del Censo usaría las planillas de Hacienda, pero la regla no aclara si esas planillas o los Formularios 499R-2/W-2PR y 1040-SS serían aceptados. Aun si lo fueran, se estima que cerca de un tercio de la población no rinde planilla y está en la economía informal (Caraballo-Cueto), y preocupa que una porción sustancial de las planillas use un apartado postal o una ruta rural como dirección, que no se puede validar, parear ni ubicar en un mapa. Las personas en la economía informal, los adultos mayores y quienes viven de transferencias son los menos propensos a tener un récord contributivo, y son precisamente quienes los programas federales buscan servir.

• Depende de direcciones que en Puerto Rico no se pueden validar. Se estima que entre el 40% y el 60% de las estructuras en Puerto Rico no tienen una dirección que los sistemas federales puedan validar, parear ni ubicar en un mapa; muchas usan rutas rurales o apartados postales, que no identifican una vivienda ni coinciden con los récords administrativos.

• Define la residencia con la regla de los 89 días (del 3 de enero al 1 de abril). Miles de familias se mueven entre Puerto Rico y los estados durante el año. La regla no explica cómo se contaría a estudiantes, cuidadores o trabajadores que dividen su tiempo, lo que arriesga que se cuenten en el lugar equivocado, dos veces o ninguna.

• Elimina las preguntas de raza y origen hispano. En Puerto Rico desaparecería la única medida completa de cómo nos identificamos racialmente, y se eliminaría el encasillado “puertorriqueño”, la única forma en que el censo identifica a nuestra gente en los estados.

El censo de 2020 tuvo en Puerto Rico un sobreconteo neto de 5.7% y enumeraciones erróneas de 9.8%, mayormente duplicados. El problema fueron récords que no cuadraban. Una regla que depende aún más de esos récords podría dejar fuera a hogares reales y reducir la base poblacional que determina la asignación de fondos federales.

Estas disposiciones afectan a los municipios, a las agencias, al sector privado y a la capacidad del Gobierno de Puerto Rico de planificar y defender su justa participación en fondos federales durante la próxima década.

Por estas razones, solicitamos una reunión para presentar nuestro análisis y explorar cómo el Gobierno de Puerto Rico, la Administración de Asuntos Federales de Puerto Rico (PRFAA), el Instituto de Estadísticas, la Junta de Planificación y los municipios pueden someter comentarios formales antes del 2 de noviembre. Entre otras cosas, proponemos solicitar al Negociado del Censo que aclare cómo aplica la regla a Puerto Rico; que acepte récords de Hacienda y otros récords administrativos de agencias de Puerto Rico para validar direcciones; que aclare el proceso para parear récords con una dirección; que conserve las preguntas de raza y origen hispano (donde aparece la opción “puertorriqueño”), y que extienda el periodo de comentarios con oportunidades de participación en español.

Estamos disponibles de inmediato para coordinar una reunión y agradecemos su atención y su compromiso con Puerto Rico.

Atentamente,

[Nombre y apellidos]
[Cargo]
[Organización co-firmante]

Endosado por:
[Organizaciones, municipios, académicos e individuos endosantes]`,
  en: `[Date]

[Elected official’s name]
[Title]
San Juan, Puerto Rico

Dear [elected official’s name]:

Warm greetings from the Puerto Rico Cuenta initiative and [co-signing organization]. We are a civic collective that puts data to work for social well-being, economic growth, and public policy in Puerto Rico. [One sentence about the co-signing organization and its mission.]

We respectfully request an urgent meeting to discuss the U.S. Census Bureau’s proposed rule for the 2030 Census (15 CFR Parts 60 and 70; 91 FR 57524; docket USBC-2026-0628). The public comment period closes on November 2, 2026. The rule does not mention Puerto Rico a single time, yet it would govern how the 3.2 million people living in Puerto Rico are counted and how the more than 5.8 million Puerto Ricans in the states are identified.

The decennial census is the base for nearly every figure Puerto Rico uses to plan and to receive federal funds: the Puerto Rico Community Survey (PRCS), the Encuesta de Grupo Trabajador, health and poverty rates, Medicaid and Nutrition Assistance Program planning, the redrawing of electoral districts, and disaster recovery by barrio and census tract. An error in 2030 would carry through to 2040. The Bureau’s own impact analysis acknowledges that American Community Survey estimates “will become less reliable” and that no comparable sources exist to replace the census’s race and ethnicity data.

The implications for Puerto Rico are profound. The rule:

• Requires residence to be evidenced by tax records. Most Puerto Rico residents file with the Puerto Rico Department of the Treasury (Hacienda), not the IRS. The assumption is that the Census Bureau would use Hacienda returns, but the rule does not say whether those returns or Forms 499R-2/W-2PR and 1040-SS would be accepted. Even if they were, an estimated one-third of the population doesn’t file and works in the informal economy (Caraballo-Cueto), and there is concern that a substantial share of returns list a P.O. box or rural route as the address, which cannot be validated, matched, or placed on a map. People in the informal economy, older adults, and households living on transfers are the least likely to have a tax record, and they are exactly who federal programs exist to serve.

• Depends on addresses that cannot be validated in Puerto Rico. An estimated 40% to 60% of structures in Puerto Rico have no address that federal systems can validate, match, or map; many use rural routes or post office boxes, which do not identify a dwelling or match administrative records.

• Defines residence with the 89-day rule (January 3 to April 1). Thousands of families move between Puerto Rico and the states during the year. The rule does not explain how students, caregivers, or workers who split their time would be counted, risking that they are counted in the wrong place, twice, or not at all.

• Eliminates the race and Hispanic-origin questions. Puerto Rico would lose its only full-count measure of how we identify racially, and the “Puerto Rican” checkbox, the only way the census identifies our people in the states, would disappear.

The 2020 Census found a net overcount of 5.7% in Puerto Rico and erroneous enumerations of 9.8%, mostly duplicates. The problem was records that did not line up. A rule that leans even harder on those records could leave out real households and shrink the population base that determines federal funding.

These provisions affect municipios, agencies, the private sector, and the Government of Puerto Rico’s ability to plan and to defend its fair share of federal funds over the next decade.

For these reasons, we request a meeting to present our analysis and explore how the Government of Puerto Rico, the Puerto Rico Federal Affairs Administration (PRFAA), the Puerto Rico Institute of Statistics, the Planning Board, and the municipios can submit formal comments before November 2. Among other things, we propose asking the Census Bureau to clarify how the rule applies to Puerto Rico; to accept Hacienda records and other Puerto Rico agency records to validate addresses; to clarify how records would be matched to an address; to keep the race and Hispanic-origin questions (where the “Puerto Rican” option appears); and to extend the comment period with meaningful opportunities to participate in Spanish.

We are available immediately to coordinate a meeting and thank you for your attention and your commitment to Puerto Rico.

Sincerely,

[Full name]
[Title]
[Co-signing organization]

Endorsed by:
[Endorsing organizations, municipios, academics, and individuals]`,
}
