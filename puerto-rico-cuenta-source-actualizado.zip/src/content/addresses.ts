import type { L } from '@/lib/i18n'

// Copy for the /direcciones page, summarized from the iCasaPR address brief.
// The headline figures (ADDRESS_STATS) live in impact.ts and are shared with /impacto.

export const CITY_STYLE: { title: L; body: L }[] = [
  {
    title: { es: 'Lo que el sistema federal espera', en: 'What the federal system expects' },
    body: {
      es: 'Una dirección “city-style”: número de casa, nombre de calle y código postal. Con eso, un sistema puede ubicar la vivienda en un mapa (geolocalizarla) y saber en qué bloque, barrio y municipio está.',
      en: 'A “city-style” address: house number, street name, and ZIP code. With that, a system can place the home on a map (geocode it) and know which block, barrio, and municipio it’s in.',
    },
  },
  {
    title: { es: 'Lo que tenemos en muchos lugares de Puerto Rico', en: 'What much of Puerto Rico has instead' },
    body: {
      es: 'Un apartado postal, una ruta rural (RR), un “highway contract” (HC) o una descripción como “Carr. 123, km 4.5, frente al colmado”. Eso dice dónde recoges el correo o cómo llegar, pero no es una dirección física estandarizada. Y aun las direcciones de calle y número siguen una estructura distinta a la federal: tres líneas, el campo “Urbanización”, acentos y la ñ. Por eso muchas no se validan ni se parean (“match”) con los sistemas federales, y tampoco se pueden geolocalizar.',
      en: 'A P.O. box, a rural route (RR), a highway contract (HC) route, or a description like “Carr. 123, km 4.5, across from the colmado.” That says where you pick up mail or how to get there, but it isn’t a standardized physical address. And even street-and-number addresses follow a structure different from the federal one: three lines, an “Urbanización” field, accents, and the ñ. That’s why many don’t validate or match against federal systems, and can’t be geocoded either.',
    },
  },
]

export const ADDRESS_ISSUES: { title: L; body: L }[] = [
  {
    title: { es: 'La mayoría de los municipios no tiene calles y números', en: 'Most municipios lack street-and-number systems' },
    body: {
      es: 'En 24 de los 78 municipios, más del 60% de las residencias no tienen una dirección convencional. La gente usa rutas rurales (RR), “highway contract” (HC) o apartados postales, que no identifican dónde está la vivienda.',
      en: 'In 24 of the 78 municipios, more than 60% of residences lack a conventional address. People use rural routes (RR), highway contract (HC) routes, or P.O. boxes, which don’t identify where the home is.',
    },
  },
  {
    title: { es: 'Más de un millón de personas', en: 'More than a million people' },
    body: {
      es: 'Se estima que entre el 40% y el 60% de la población no tiene una dirección convencional. Si la regla depende de direcciones de calle para verificar residencia, podría dejar fuera del Censo a una parte grande de Puerto Rico.',
      en: 'An estimated 40% to 60% of the population lacks a conventional address. If the rule relies on street addresses to verify residence, it could leave a large share of Puerto Rico out of the Census.',
    },
  },
  {
    title: { es: 'Aun con calle y número, no validan', en: 'Even street addresses don’t validate' },
    body: {
      es: 'Puerto Rico es la única jurisdicción de EE. UU. con una dirección de tres líneas y el campo “Urbanización”, que necesita más del 48% de las direcciones de calle. Con los acentos y la ñ, muchas no se validan, no se estandarizan y no se geolocalizan bien en los sistemas federales.',
      en: 'Puerto Rico is the only U.S. jurisdiction with a three-line address and an “Urbanización” field, which more than 48% of street addresses need. Add accents and the ñ, and many don’t validate, standardize, or geocode correctly in federal systems.',
    },
  },
  {
    title: { es: 'Ya pasó con FEMA', en: 'It already happened with FEMA' },
    body: {
      es: 'Después del huracán María, según reportes, muchas direcciones sometidas en el campo de una sola línea de FEMA no se pudieron procesar para la asistencia individual.',
      en: 'After Hurricane Maria, many addresses entered in FEMA’s single-line address field reportedly could not be processed for individual assistance.',
    },
  },
  {
    title: { es: 'Y con las vacunas', en: 'And with vaccines' },
    body: {
      es: 'En 2021, según reportes, residentes con direcciones RR o HC no pudieron recibir la vacuna del COVID-19 gratis en el programa federal de farmacias, porque se exigía una dirección de calle. Como se permitía una sola vacuna por dirección, tampoco podían usar la de un familiar.',
      en: 'In 2021, residents with RR or HC addresses were reportedly unable to get free COVID-19 vaccines through the Federal Retail Pharmacy Program because a street address was required. Since only one allocation was allowed per address, they couldn’t use a relative’s address either.',
    },
  },
]

export const ADDRESS_CHAIN: { title: L; body: L }[] = [
  {
    title: { es: 'La regla pide récords contributivos', en: 'The rule asks for tax records' },
    body: {
      es: 'La sección 60.2 dice que tu residencia “debe ser consistente con” tus récords contributivos. Se asume que en Puerto Rico serían las planillas de Hacienda, pero la regla no lo dice.',
      en: 'Section 60.2 says your residence “should be consistent with” your tax records. The assumption is that in Puerto Rico those would be Hacienda returns, but the rule doesn’t say so.',
    },
  },
  {
    title: { es: 'Un tercio no rinde planilla', en: 'A third don’t file' },
    body: {
      es: 'Se estima que cerca de un tercio de la población no rinde planilla y está en la economía informal (Caraballo-Cueto). Para esas personas no hay récord que comparar.',
      en: 'An estimated one-third of the population doesn’t file and works in the informal economy (Caraballo-Cueto). For those people there’s no record to compare.',
    },
  },
  {
    title: { es: 'La planilla trae la dirección postal', en: 'The return carries the mailing address' },
    body: {
      es: 'De las planillas que sí se rinden, preocupa que una porción sustancial use un apartado postal o una ruta rural. El récord dice dónde recibes el correo, no dónde vives.',
      en: 'Of the returns that are filed, there is concern that a substantial share list a P.O. box or rural route. The record says where you get mail, not where you live.',
    },
  },
  {
    title: { es: 'El sistema no encuentra la casa', en: 'The system can’t find the home' },
    body: {
      es: 'Una dirección que no se valida, no se parea con los sistemas federales o no se puede geolocalizar no se puede vincular con una vivienda. El hogar puede quedar fuera del conteo o en el bloque o municipio equivocado.',
      en: 'An address that doesn’t validate, doesn’t match federal systems, or can’t be geocoded can’t be tied to a housing unit. The household can be left out of the count or placed in the wrong block or municipio.',
    },
  },
]

export const ADDRESS_ASKS: L[] = [
  { es: 'Aclarar por escrito si se usarían las planillas de Hacienda y cómo se parearían sus direcciones postales con viviendas reales.', en: 'State in writing whether Hacienda returns would be used, and how their mailing addresses would be matched to actual homes.' },
  { es: 'Publicar la cobertura y las tasas de pareo de direcciones en Puerto Rico de cada fuente administrativa (IRS, Seguro Social, Medicaid, PAN, Hacienda) antes de usarlas.', en: 'Publish Puerto Rico coverage and address-match rates for every administrative source (IRS, SSA, Medicaid, NAP, Hacienda) before relying on any of them.' },
  { es: 'No tratar un apartado postal, una ruta rural o una dirección que no se valide, paree o geolocalice como evidencia de que una persona no vive en Puerto Rico.', en: 'Not treat a P.O. box, rural route, or an address that doesn’t validate, match, or geocode as evidence that a person doesn’t live in Puerto Rico.' },
  { es: 'Mantener la enumeración en persona donde las direcciones no se puedan parear, y permitir que LUCA use descripciones físicas para añadir y ubicar viviendas.', en: 'Keep in-person enumeration wherever addresses can’t be matched, and let LUCA submissions with physical descriptions add and locate housing units.' },
]

export const ADDRESS_SOURCES: { label: string; href?: string }[] = [
  { label: 'Federal Register, Proposed Rule 2026-18481 (91 FR 57524), § 60.2', href: 'https://www.federalregister.gov/d/2026-18481' },
  { label: 'Initiative for Civic Address Systems Assessment in Puerto Rico (iCasaPR), address study' },
  { label: 'Caraballo-Cueto, J. (2026). Informal Labor Markets After Disasters: Evidence From Rural and Urban Low-Income Communities in Puerto Rico. Social Science Quarterly, 107(2), e70148' },
  { label: 'Census Bureau and HUD, Opportunity Project problem statement (2022): P.O. Box and HC addresses aren’t locatable by digital mapping', href: 'https://opportunity.census.gov/assets/files/2022-Census-HUD.pdf' },
  { label: 'USPS, Puerto Rico and USVI addressing guide', href: 'https://postalpro.usps.com/storages/2017-03/PR_AND_USVI_ADDRESSING_-_ENGLISH.pdf' },
  { label: 'Centro de Periodismo Investigativo, “Those Living on Unnamed Streets in Puerto Rico Are Invisible” (2024)', href: 'https://periodismoinvestigativo.com/2024/01/those-living-on-unnamed-streets-in-puerto-rico-are-invisible/' },
  { label: 'El Vocero, “La población invisible”', href: 'https://www.elvocero.com/actualidad/la-poblaci-n-invisible/article_e039fac4-ddb7-11e9-bc0a-8f29effc41a5.html' },
  { label: 'AP, “Navigating by mango trees, pink houses in rural Puerto Rico”', href: 'https://apnews.com/article/723960c28989ccfeccab55244994c384' },
  { label: 'CienciaPR, “Local Team Creates Tools to Improve Housing Addresses in Puerto Rico”', href: 'https://www.cienciapr.org/en/local-team-creates-tools-improve-housing-addresses-puerto-rico' },
]
