import type { L } from '@/lib/i18n'

// Puerto Rico-specific analysis behind the /impacto page. Figures are attributed
// to their source; anything that is reasoning from the rule's design is phrased
// as a risk, not a measured result.

export const COMPARE: { topic: L; rule: L; reality: L; risk: L }[] = [
  {
    topic: { es: 'Residencia', en: 'Residence' },
    rule: { es: 'Exige que la residencia sea consistente con planillas federales (IRS / W-2).', en: 'Residence should be consistent with federal tax records (IRS / W-2).' },
    reality: { es: 'Rendimos en Hacienda (Formulario 499R-2/W-2PR) o no estamos obligados a radicar planilla federal. Se asume que el Censo usaría las planillas de Hacienda, pero la regla no lo aclara.', en: 'We file with Hacienda (Form 499R-2/W-2PR) or aren’t required to file a federal return. The assumption is that the Census would use Hacienda returns, but the rule doesn’t say so.' },
    risk: { es: 'Un conteo incompleto que reduce la base para fondos de Medicaid, PAN y WIC.', en: 'An incomplete count that shrinks the base for Medicaid, NAP, and WIC funds.' },
  },
  {
    topic: { es: 'Dirección', en: 'Address' },
    rule: { es: 'Valida viviendas con récords de planillas/contribuciones y bases de datos administrativas.', en: 'Validates dwellings against tax-return records and administrative databases.' },
    reality: { es: 'Entre el 40% y el 60% de las estructuras no tienen una dirección física de calle y número (el estándar federal “city-style”): usan rutas rurales, apartados o descripciones físicas, que no se validan ni se parean con los sistemas federales ni se pueden ubicar en un mapa.', en: 'An estimated 40–60% of structures have no physical street-and-number address (the federal “city-style” standard): they use rural routes, P.O. boxes, or physical descriptions, which don’t validate or match against federal systems and can’t be placed on a map.' },
    risk: { es: 'La dirección no se valida ni se parea, el sistema no ubica la casa y se pierden datos del barrio y del municipio.', en: 'The address doesn’t validate or match, the system can’t locate the home, and barrio and municipio data are lost.' },
  },
  {
    topic: { es: 'Conteo', en: 'Count' },
    rule: { es: 'Aplica la regla de los 89 días (del 3 de enero al 1 de abril): cuenta dónde pasas más días.', en: 'Applies the 89-day rule (January 3 to April 1): counts where you spend the most days.' },
    reality: { es: 'Migración circular constante: familias que van y vienen entre Puerto Rico y los estados.', en: 'Constant circular migration: families moving back and forth between Puerto Rico and the states.' },
    risk: { es: 'Confusión sobre dónde se cuenta a cada persona: en el lugar equivocado, dos veces o ninguna.', en: 'Confusion over where each person is counted: in the wrong place, twice, or not at all.' },
  },
  {
    topic: { es: 'Identidad', en: 'Identity' },
    rule: { es: 'Prohíbe preguntar raza y origen hispano (etnicidad), donde está la subcategoría “puertorriqueño” (Puerto Rican).', en: 'Bans race and Hispanic-origin (ethnicity) questions, which include the “Puerto Rican” subcategory.' },
    reality: { es: 'Es la única medida completa del número de “puertorriqueños” en el archipiélago y en la diáspora.', en: 'It is the only full-count measure of the number of “Puerto Ricans” in the archipelago and in the diaspora.' },
    risk: { es: 'Sin punto de referencia para estudiar desigualdades ni para contar a los boricuas en los estados.', en: 'No benchmark to study disparities or to count Puerto Ricans in the states.' },
  },
]

export const ADDRESS_STATS: { v: string; l: L }[] = [
  { v: '40–60%', l: { es: 'de las estructuras en Puerto Rico no tienen una dirección que los sistemas federales puedan validar, parear ni ubicar en un mapa', en: 'of structures in Puerto Rico have no address that federal systems can validate, match, or map' } },
  { v: '1M+', l: { es: 'residentes sin una dirección convencional de calle y número', en: 'residents without a conventional street-and-number address' } },
  { v: '24 de 78', l: { es: 'municipios donde más del 60% de las residencias no tienen una dirección convencional verificable', en: 'municipios where more than 60% of residences lack a verifiable conventional address' } },
  { v: '48%', l: { es: 'de las direcciones de calle necesitan el campo “Urbanización”, que no se usa en los estados', en: 'of street addresses need an “Urbanización” line, which isn’t used in the states' } },
]

export const TAX_POINTS: { title: L; body: L }[] = [
  {
    title: { es: 'La mayoría no rinde planilla federal', en: 'Most people don’t file a federal return' },
    body: {
      es: 'Si tu ingreso es de Puerto Rico, rindes tu planilla en Hacienda, no en el IRS, y tu patrono te entrega el 499R-2/W-2PR. Se asume que el Censo usaría las planillas de Hacienda, pero la regla no lo dice. Hay que exigir que lo aclare.',
      en: 'If your income is from Puerto Rico, you file with Hacienda, not the IRS, and your employer gives you Form 499R-2/W-2PR. The assumption is that the Census would use Hacienda returns, but the rule doesn’t say so. The Bureau must be pressed to clarify it.',
    },
  },
  {
    title: { es: 'Muchos no rinden ninguna planilla', en: 'Many file no return at all' },
    body: {
      es: 'Se estima que cerca de un tercio de la población no rinde planilla y está en la economía informal (Caraballo-Cueto): gente que cobra en efectivo, trabaja por su cuenta o vive de ayudas del gobierno. Para esas personas no hay ningún récord contributivo que comparar.',
      en: 'An estimated one-third of the population doesn’t file and works in the informal economy (Caraballo-Cueto): people paid in cash, self-employed, or living on government assistance. For them there is no tax record to compare at all.',
    },
  },
  {
    title: { es: 'Y la planilla no dice dónde vives', en: 'And a tax return doesn’t say where you live' },
    body: {
      es: 'Preocupa que muchas de las planillas que sí se rinden usen un apartado postal o una ruta rural como dirección. Eso dice dónde recibes el correo, no dónde duermes, y el Censo no lo puede ubicar en un mapa.',
      en: 'There is concern that many of the returns that are filed list a P.O. box or rural route as the address. That says where you get mail, not where you sleep, and the Census can’t place it on a map.',
    },
  },
]

export const TAX_RESULT: L = {
  es: 'Si el Censo trata la falta de un récord, o un récord que no cuadra, como señal de que no vives aquí, quienes más riesgo corren de quedar fuera o de ser contados en el lugar equivocado son los trabajadores informales, los adultos mayores, las personas que reciben asistencia pública y los jóvenes que viven con su familia. Son las mismas personas a quienes sirven los programas federales.',
  en: 'If the Census treats a missing or mismatched record as a sign that you don’t live here, those most at risk of being left out or counted in the wrong place are informal workers, older adults, people on public assistance, and young adults living with family. They are the same people federal programs serve.',
}

export const FUNDING_PROGRAMS: { area: L; programs: L }[] = [
  { area: { es: 'Salud', en: 'Health' }, programs: { es: 'Medicaid, centros de salud comunitaria (CDT)', en: 'Medicaid, community health centers' } },
  { area: { es: 'Nutrición', en: 'Nutrition' }, programs: { es: 'PAN (NAP), WIC y programas para adultos mayores', en: 'NAP, WIC, and senior programs' } },
  { area: { es: 'Educación y niñez', en: 'Education and children' }, programs: { es: 'Título I y Head Start', en: 'Title I and Head Start' } },
  { area: { es: 'Vivienda e infraestructura', en: 'Housing and infrastructure' }, programs: { es: 'Sección 8, CDBG, carreteras y fondos de resiliencia ante desastres', en: 'Section 8, CDBG, highways, and disaster-resilience grants' } },
]

export const FUNDING_SCENARIO = {
  population: '3.2M',
  undercountShare: '40%',
  uncounted: '1.28M',
  perCapita: { es: '$1,500–$3,000', en: '$1,500–$3,000' },
  annual: { es: '$1.9–$3.8 mil millones', en: '$1.9–$3.8 billion' },
  decade: { es: '$19–$38 mil millones', en: '$19–$38 billion' },
}

export const DISTRICT_POINTS: { title: L; body: L }[] = [
  {
    title: { es: 'Un ciudadano, un voto', en: 'One person, one vote' },
    body: {
      es: 'Se toma la población total que reporta el Censo y se divide entre los 40 distritos representativos y los 8 senatoriales para fijar la población ideal de cada distrito. Ningún distrito debe alejarse mucho de esa cifra, para que el voto en un municipio menos poblado no valga más que en uno denso.',
      en: 'The total population reported by the Census is divided among the 40 house districts and 8 senate districts to set each district’s ideal population. No district should stray far from that figure, so a vote in a less populated municipio doesn’t count more than one in a dense area.',
    },
  },
  {
    title: { es: 'Bloque por bloque', en: 'Block by block' },
    body: {
      es: 'La Junta de Redistribución trabaja con la cartografía y los datos del Censo a nivel de bloques censales y barrios, para mover fronteras dentro de un municipio o entre municipios y balancear los números, procurando la contigüidad y evitar dividir municipios salvo cuando la densidad lo hace necesario, como en San Juan, Bayamón o Ponce.',
      en: 'The redistricting board works with Census maps and data at the census block and barrio level to move boundaries within or between municipios and balance the numbers, aiming for contiguity and avoiding splitting municipios unless density requires it, as in San Juan, Bayamón, or Ponce.',
    },
  },
  {
    title: { es: 'Lo que la regla pone en riesgo', en: 'What the rule puts at risk' },
    body: {
      es: 'Si la regla deja fuera a hogares cuyos récords no cuadran, o los ubica en la dirección postal y no donde viven, la población de cada bloque y barrio cambia, y con ella los mapas de 2032 en adelante. Es una inferencia del diseño de la regla, pero los mapas solo pueden ser tan buenos como el conteo.',
      en: 'If the rule drops households whose records don’t match, or places them at a mailing address instead of where they live, the population of each block and barrio shifts, and so do the maps from 2032 on. That is an inference from the rule’s design, but the maps can only be as good as the count.',
    },
  },
]

export const ASKS: L[] = [
  { es: 'Aclarar cómo aplica la Parte 60 al conteo de Puerto Rico y qué criterios rigen los productos estadísticos y las fórmulas de fondos que dependen de él.', en: 'State how Part 60 applies to Puerto Rico’s count, and which criteria govern the statistical products and funding formulas that depend on it.' },
  { es: 'Mantener las preguntas de raza y origen hispano en Puerto Rico, con categorías probadas localmente.', en: 'Keep race and Hispanic-origin questions in Puerto Rico, with categories tested locally.' },
  { es: 'Aclarar por escrito si se usarían las planillas de Hacienda y el 499R-2/W-2PR como récords contributivos en Puerto Rico, y no hacer de las planillas la prueba de residencia: aceptar la autorespuesta y la verificación en el campo.', en: 'State in writing whether Hacienda returns and Form 499R-2/W-2PR would be used as tax records in Puerto Rico, and not make tax returns the proof of residence: accept self-response and field verification.' },
  { es: 'Publicar un análisis del efecto de la regla en la base poblacional de Puerto Rico, la Encuesta sobre la Comunidad y los fondos federales antes de adoptarla.', en: 'Publish an analysis of the rule’s effect on Puerto Rico’s population base, the Community Survey, and federal funding before finalizing it.' },
  { es: 'Publicar la cobertura y las tasas de pareo de direcciones en Puerto Rico de cada fuente administrativa (IRS, Seguro Social, Medicaid, PAN, Hacienda) antes de usarlas.', en: 'Publish Puerto Rico coverage and address-match rates for every administrative source (IRS, SSA, Medicaid, NAP, Hacienda) before relying on any of them.' },
  { es: 'Mantener la enumeración en persona donde las direcciones no se puedan parear, y permitir que LUCA use descripciones físicas para añadir y ubicar viviendas.', en: 'Keep in-person enumeration wherever addresses can’t be matched, and let LUCA submissions with physical descriptions add and locate housing units.' },
  { es: 'Mantener el estándar de dónde vives y duermes la mayor parte del tiempo, o explicar cómo el conteo de días trataría la migración circular.', en: 'Keep the standard of where you live and sleep most of the time, or show how the day count would treat circular migrants.' },
  { es: 'Proteger las tablas por municipio, barrio y sector censal bajo el límite de publicación de la sección 70.3.', en: 'Protect municipio, barrio, and tract tables under the § 70.3 publication limit.' },
]

export const WHO_SHOULD_COMMENT: L = {
  es: 'Tú, el ciudadano: esto nos afecta a todos. También las instituciones: el gobierno y las agencias públicas, los 78 municipios y sus alcaldes, los legisladores, los centros de investigación, las universidades y los académicos, los estudiantes, las asociaciones, las empresas y los negocios, las organizaciones sin fines de lucro y las organizaciones de base comunitaria. En fin, ¡todos los puertorriqueñ@s!',
  en: 'You, the citizen: this affects all of us. Also institutions: government and public agencies, all 78 municipios and their mayors, legislators, research centers, universities and academics, students, associations, companies and businesses, nonprofits, and community-based organizations. In short, every Puerto Rican!',
}

export const IMPACT_SOURCES: { label: string; href?: string }[] = [
  { label: 'Federal Register, Proposed Rule 2026-18481 (91 FR 57524)', href: 'https://www.federalregister.gov/d/2026-18481' },
  { label: 'Census Bureau, 2020 Post-Enumeration Survey results for Puerto Rico (2022)', href: 'https://www.census.gov/newsroom/press-releases/2022/2020-post-enumeration-survey-results-puerto-rico.html' },
  { label: 'IRS Topic 901, Is a person with income from Puerto Rico required to file a U.S. federal income tax return?', href: 'https://www.irs.gov/taxtopics/tc901' },
  { label: 'Census Bureau, Puerto Rico Community Survey overview', href: 'https://www.census.gov/content/dam/Census/programs-surveys/acs/Library/OutreachMaterials/ACSFlyers/PRCS_Overview_Flyer.pdf' },
  { label: 'Census Bureau, Federal funds distribution, FY2021 (2023)', href: 'https://www.census.gov/newsroom/press-releases/2023/decennial-census-federal-funds-distribution.html' },
  { label: 'Centro de Periodismo Investigativo, “Those Living on Unnamed Streets in Puerto Rico Are Invisible” (2024)', href: 'https://periodismoinvestigativo.com/2024/01/those-living-on-unnamed-streets-in-puerto-rico-are-invisible/' },
  { label: 'El Vocero, “La población invisible”', href: 'https://www.elvocero.com/actualidad/la-poblaci-n-invisible/article_e039fac4-ddb7-11e9-bc0a-8f29effc41a5.html' },
  { label: 'AP, “Navigating by mango trees, pink houses in rural Puerto Rico”', href: 'https://apnews.com/article/723960c28989ccfeccab55244994c384' },
  { label: 'CienciaPR, “Local Team Creates Tools to Improve Housing Addresses in Puerto Rico”', href: 'https://www.cienciapr.org/en/local-team-creates-tools-improve-housing-addresses-puerto-rico' },
  { label: 'NBC News, 2020 census overcounted people in Puerto Rico (2022)', href: 'https://www.nbcnews.com/news/latino/2020-census-overcounted-people-puerto-rico-hinting-larger-population-l-rcna43384' },
  { label: 'Accounting Today/Bloomberg, Puerto Rico’s underground economy (2017)', href: 'https://www.accountingtoday.com/articles/puerto-ricos-tax-dodgers-hide-in-plain-sight-on-every-corner' },
  { label: 'Caraballo-Cueto, J. (2026). Informal Labor Markets After Disasters: Evidence From Rural and Urban Low-Income Communities in Puerto Rico. Social Science Quarterly, 107(2), e70148' },
  { label: 'Junta Constitucional de Revisión de Distritos Electorales, Determinación Final (2022)', href: 'https://juntaconstitucionalderedistribucion.pr/determinacion/' },
  { label: 'Junta Constitucional, Principios para la revisión de distritos senatoriales y representativos (2021)', href: 'https://www.ceepur.org/redistribucionelectoral/docs/Principios-revision-distritos-senatoriales-y-representativos2021.pdf' },
  { label: 'Puerto Rico Institute of Statistics, Study on the informal economy', href: 'https://www.estadisticas.pr.gov/en-us/productos/estudio-sobre-la-economia-informal-en-puerto-rico' },
]
