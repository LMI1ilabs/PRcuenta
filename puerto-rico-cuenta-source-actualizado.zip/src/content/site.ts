// Verified facts about the proposed rule. Update here if the Census Bureau
// publishes a further extension or a final rule.
export const RULE = {
  title:
    'Decennial Census of the Population of Americans; Proposed Residence Criteria and Proposed Regulations for Demographic Questions',
  published: '2026-09-10',
  citation: '91 FR 57524',
  frDoc: '2026-18481',
  docketNo: '260903-0005',
  rin: '0607-AA75',
  regsDocket: 'USBC-2026-0628',
  extensionDoc: '2026-20328',
  // 11:59 p.m. Eastern (EST, UTC-5) on November 2, 2026.
  deadlineISO: '2026-11-03T04:59:00Z',
  mailAddress: 'U.S. Census Bureau, 4600 Silver Hill Road, Designation: ADDEMO/FRN, Washington, DC 20746',
}

export const LINKS = {
  // Opens the comment form directly.
  commentNow: 'https://www.regulations.gov/commenton/USBC-2026-0628-0001',
  docket: 'https://www.regulations.gov/docket/USBC-2026-0628',
  federalRegister: 'https://www.federalregister.gov/d/2026-18481',
  rulePdf: 'https://public-inspection.federalregister.gov/2026-18481.pdf',
  extension: 'https://www.federalregister.gov/d/2026-20328',
  handsOff: 'https://handsoffourcens.us',
  crs: 'https://www.everycrsreport.com/reports/IN12741.html',
  naco: 'https://www.naco.org/resource/proposed-rule-2030-census-what-counties-need-know',
  dataCensusPR: 'https://data.census.gov/profile/Puerto_Rico?g=040XX00US72',
  censusPR: 'https://www.census.gov/geographies/island-areas/puerto-rico.html',
  pes2020PR: 'https://www.census.gov/newsroom/press-releases/2022/2020-post-enumeration-survey-results-puerto-rico.html',
  irsPR: 'https://www.irs.gov/taxtopics/tc901',
  pria: 'https://www.regulations.gov/document/USBC-2026-0628-0002',
  censusFunds: 'https://www.census.gov/newsroom/press-releases/2023/decennial-census-federal-funds-distribution.html',
  raceVOA: 'https://www.voanews.com/a/puerto-rico-ponders-race-amid-surprising-census-results/6272219.html',
  commentTips: 'https://www.regulations.gov/commenting-guidance',
  jhuTips: 'https://federalstrategy.jhu.edu/wp-content/uploads/sites/3/Tips-for-Submitting-Effective-Comments.pdf',
}

export const SITE = {
  name: 'Puerto Rico Cuenta',
  hashtag: '#PRCuenta',
}
