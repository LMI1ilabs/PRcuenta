import type { L } from '@/lib/i18n'

export type Concern = { id: string; label: L; paragraph: L }

// Building blocks for the comment builder. Each paragraph is written to stand
// alone in a formal comment to the Census Bureau and cites the section it addresses.
export const CONCERNS: Concern[] = [
  {
    id: 'silence',
    label: { es: 'La regla no menciona a Puerto Rico', en: 'The rule is silent on Puerto Rico' },
    paragraph: {
      es: 'La propuesta no menciona a Puerto Rico ni una sola vez, aunque el Censo decenal cuenta a más de 3.2 millones de ciudadanos estadounidenses en la Isla y produce los datos con que se redibujan nuestros distritos legislativos. Las secciones 60.5 y 70.3 hablan del “stateside census” y del nivel “nacional o estatal” sin definir “Estados Unidos”. Solicito que la Oficina del Censo explique por escrito cómo aplicarían las Partes 60 y 70 en Puerto Rico y que no adopte una regla final sin hacerlo.',
      en: 'The proposed rule does not mention Puerto Rico a single time, even though the decennial census counts more than 3.2 million U.S. citizens on the island and produces the data used to redraw our legislative districts. Sections 60.5 and 70.3 refer to the “stateside census” and to the “national or state level” without defining “United States.” I ask the Census Bureau to explain in writing how Parts 60 and 70 would apply in Puerto Rico, and not to finalize any rule without doing so.',
    },
  },
  {
    id: 'ethnicity',
    label: { es: 'Eliminar “puertorriqueño” borra a la diáspora', en: 'Removing “Puerto Rican” erases the diaspora' },
    paragraph: {
      es: 'La sección 70.2(a) prohibiría la pregunta de origen hispano, que incluye el encasillado “puertorriqueño”. Hoy viven más personas de origen puertorriqueño en los estados que en Puerto Rico, y esa pregunta es la única forma en que el Censo decenal las cuenta. Sin ella, nuestras comunidades en Nueva York, Florida, Pensilvania, Massachusetts, Connecticut y otros estados desaparecerían de los datos que se usan para hacer cumplir los derechos civiles y electorales y para planificar servicios. Solicito que se elimine la sección 70.2(a).',
      en: 'Section 70.2(a) would prohibit the Hispanic-origin question, which includes the “Puerto Rican” checkbox. More people of Puerto Rican origin now live in the states than on the island, and that question is the only way the decennial census counts them. Without it, our communities in New York, Florida, Pennsylvania, Massachusetts, Connecticut, and elsewhere would disappear from the data used to enforce civil and voting rights and to plan services. I ask that Section 70.2(a) be withdrawn.',
    },
  },
  {
    id: 'hacienda',
    label: { es: 'Aclarar si se usarían las planillas de Hacienda', en: 'Clarify whether Hacienda tax returns would be used' },
    paragraph: {
      es: 'La sección 60.2(a) dice que la residencia habitual “debe ser consistente con” los récords contributivos, pero no dice cuáles. La mayoría de los residentes de Puerto Rico rinde planilla ante el Departamento de Hacienda, nuestra autoridad contributiva local, y no ante el IRS; los patronos emiten el Formulario 499R-2/W-2PR. Solicito que la Oficina del Censo aclare por escrito si aceptaría las planillas de Hacienda y el Formulario 499R-2/W-2PR como récords contributivos en Puerto Rico, y cómo los obtendría y parearía.',
      en: 'Section 60.2(a) says usual residence “should be consistent with, and evidenced by” tax records, but does not say which ones. Most Puerto Rico residents file with the Puerto Rico Department of the Treasury (Hacienda), our local tax authority, not with the IRS; employers issue Form 499R-2/W-2PR. I ask the Census Bureau to state in writing whether it would accept Hacienda returns and Form 499R-2/W-2PR as tax records in Puerto Rico, and how it would obtain and match them.',
    },
  },
  {
    id: 'taxes',
    label: { es: 'Aun con Hacienda, los récords contributivos dejan fuera a muchos', en: 'Even with Hacienda, tax records leave many out' },
    paragraph: {
      es: 'Aun si la Oficina usara las planillas de Hacienda, una prueba de residencia basada en récords contributivos dejaría fuera a muchas personas en Puerto Rico. Se estima que cerca de un tercio de la población no rinde planilla y está en la economía informal (Caraballo-Cueto), y jubilados y hogares de bajos ingresos con frecuencia no rinden ninguna. Además, preocupa que una porción sustancial de las planillas que sí se rinden use un apartado postal o una ruta rural como dirección, que no identifica la vivienda donde vive la persona. Solicito que no se haga de los récords contributivos la prueba de residencia en Puerto Rico y que se acepten la autorespuesta y la verificación en el campo.',
      en: 'Even if the Bureau used Hacienda returns, a residence test based on tax records would leave many people in Puerto Rico out. An estimated one-third of the population doesn’t file and works in the informal economy (Caraballo-Cueto), and retirees and low-income households often file no return at all. Moreover, there is concern that a substantial share of the returns that are filed list a P.O. box or rural route as the address, which does not identify the home where the person lives. I ask that tax records not be made the proof of residence in Puerto Rico, and that self-response and field verification be accepted.',
    },
  },
  {
    id: 'addresses',
    label: { es: 'Muchas direcciones en Puerto Rico no se pueden validar', en: 'Many Puerto Rico addresses can’t be validated' },
    paragraph: {
      es: 'Se estima que entre el 40% y el 60% de las estructuras en Puerto Rico no tienen una dirección física de calle y número (city-style), el estándar que usan los sistemas federales, así que no se pueden validar, parear ni ubicar en un mapa. Muchas familias reciben su correspondencia en apartados postales o rutas rurales, no donde viven, y nuestras direcciones usan el campo “Urbanización” y acentos que los sistemas nacionales no parean bien. Un récord con dirección postal no prueba dónde vive una persona. Solicito que la Oficina publique las tasas de pareo de direcciones en Puerto Rico de cada fuente administrativa y que mantenga la enumeración en persona donde las direcciones no se puedan parear.',
      en: 'An estimated 40% to 60% of structures in Puerto Rico have no physical street-and-number (city-style) address, the standard federal systems use, so they cannot be validated, matched, or placed on a map. Many families receive mail at P.O. boxes or rural routes rather than where they live, and our addresses use an “Urbanización” line and accents that national systems don’t match well. A record with a mailing address does not prove where a person lives. I ask the Bureau to publish Puerto Rico address-match rates for every administrative source and to keep in-person enumeration wherever addresses cannot be matched.',
    },
  },
  {
    id: 'migration',
    label: { es: 'La migración circular no cabe en 89 días', en: 'Circular migration doesn’t fit in 89 days' },
    paragraph: {
      es: 'La sección 60.2 sustituiría el concepto de dónde una persona vive y duerme la mayor parte del tiempo por un conteo de días entre el 3 de enero y el 1 de abril. En Puerto Rico la migración circular es común: estudiantes, trabajadores agrícolas temporeros, personas que cuidan a familiares y familias desplazadas por huracanes y terremotos. Esta regla las ubicaría en el lugar equivocado o las dejaría fuera. Solicito que se mantenga el estándar de residencia habitual usado en censos anteriores.',
      en: 'Section 60.2 would replace the long-standing concept of where a person lives and sleeps most of the time with a count of days between January 3 and April 1. Circular migration is common in Puerto Rico: students, seasonal farmworkers, people caring for relatives, and families displaced by hurricanes and earthquakes. This rule would place them in the wrong location or miss them entirely. I ask that the Bureau keep the usual-residence standard used in prior censuses.',
    },
  },
  {
    id: 'status',
    label: { es: 'Una pregunta de estatus legal reduce la respuesta', en: 'A legal-status question would suppress response' },
    paragraph: {
      es: 'La Oficina pide comentarios sobre añadir una pregunta de estatus legal al cuestionario. Me opongo. Puerto Rico tiene comunidades inmigrantes arraigadas y muchos hogares de estatus mixto en los que viven ciudadanos estadounidenses. El temor provocado por una pregunta así reduciría la respuesta de familias completas y empeoraría el subconteo de los barrios y municipios donde viven.',
      en: 'The Bureau invites comments on adding a legal-status question to the questionnaire. I oppose it. Puerto Rico has long-established immigrant communities and many mixed-status households that include U.S. citizens. The fear such a question creates would suppress response from entire households and worsen undercounts in the barrios and municipios where they live.',
    },
  },
  {
    id: 'data',
    label: { es: 'Los datos de Puerto Rico dependen del Censo', en: 'Puerto Rico’s data depend on the Census' },
    paragraph: {
      es: 'La Encuesta sobre la Comunidad de Puerto Rico y casi todas las encuestas se ajustan a estimados de población basados en el Censo decenal. La sección 70.4 dice que la ACS aún podría preguntar sobre raza y origen, pero sin esos datos en el Censo no habría punto de referencia confiable. Municipios, agencias, hospitales, universidades, organizaciones sin fines de lucro y negocios dependen de estos datos, igual que la distribución de fondos federales para salud, alimentos, educación, vivienda y recuperación de desastres. Solicito que no se adopte la Parte 70.',
      en: 'The Puerto Rico Community Survey and nearly all surveys are weighted to population estimates based on the decennial census. Section 70.4 says the ACS could still ask about race and origin, but without those data in the census there would be no reliable benchmark. Municipios, agencies, hospitals, universities, nonprofits, and businesses depend on these data, as does the distribution of federal funds for health, nutrition, education, housing, and disaster recovery. I ask that Part 70 not be adopted.',
    },
  },
  {
    id: 'districts',
    label: { es: 'Los distritos y los fondos dependen del conteo', en: 'Districts and funds depend on the count' },
    paragraph: {
      es: 'La Constitución de Puerto Rico exige revisar los 40 distritos representativos y los 8 senatoriales después de cada censo, a partir de datos por bloque y barrio. El mismo conteo es la base de fondos federales para salud, nutrición, educación, vivienda y recuperación de desastres en los 78 municipios. Si la regla deja fuera hogares o los ubica en su dirección postal, los mapas y los fondos de la próxima década se distorsionan. Solicito que la Oficina publique un análisis del efecto de la regla en la base poblacional de Puerto Rico antes de adoptarla.',
      en: 'Puerto Rico’s Constitution requires its 40 house and 8 senate districts to be revised after each census, using block- and barrio-level data. The same count is the base for federal funds for health, nutrition, education, housing, and disaster recovery in all 78 municipios. If the rule drops households or places them at a mailing address, the next decade’s maps and funding are distorted. I ask the Bureau to publish an analysis of the rule’s effect on Puerto Rico’s population base before finalizing it.',
    },
  },
  {
    id: 'process',
    label: { es: 'Se necesita más tiempo y consulta', en: 'More time and consultation are needed' },
    paragraph: {
      es: 'Estos cambios son los más profundos que se han propuesto al Censo en generaciones. El periodo de comentarios, aun extendido al 2 de noviembre de 2026, no basta para que las comunidades de Puerto Rico los evalúen. Solicito una extensión adicional, audiencias públicas en español en Puerto Rico y consulta formal con el gobierno de Puerto Rico y sus municipios.',
      en: 'These are the most sweeping changes proposed to the census in generations. Even extended to November 2, 2026, the comment period is not enough time for Puerto Rico’s communities to evaluate them. I ask for a further extension, public hearings in Spanish in Puerto Rico, and formal consultation with the Government of Puerto Rico and its municipios.',
    },
  },
]

export const ROLES: { id: string; label: L; intro: L }[] = [
  { id: 'resident', label: { es: 'Residente de Puerto Rico', en: 'Puerto Rico resident' }, intro: { es: 'Soy residente de Puerto Rico', en: 'I am a resident of Puerto Rico' } },
  { id: 'diaspora', label: { es: 'Boricua en la diáspora', en: 'Puerto Rican in the diaspora' }, intro: { es: 'Soy puertorriqueño/a y vivo en los Estados Unidos', en: 'I am Puerto Rican and live in the United States' } },
  { id: 'data', label: { es: 'Usuario/a de datos o investigador/a', en: 'Data user or researcher' }, intro: { es: 'Trabajo con datos del Censo sobre Puerto Rico', en: 'I work with Census data about Puerto Rico' } },
  { id: 'org', label: { es: 'Organización comunitaria', en: 'Community organization' }, intro: { es: 'Escribo en nombre de una organización que sirve a comunidades puertorriqueñas', en: 'I write on behalf of an organization serving Puerto Rican communities' } },
  { id: 'business', label: { es: 'Negocio o asociación empresarial', en: 'Business or business association' }, intro: { es: 'Escribo en nombre de un negocio que usa datos del Censo para tomar decisiones en Puerto Rico', en: 'I write on behalf of a business that relies on Census data to make decisions in Puerto Rico' } },
  { id: 'official', label: { es: 'Funcionario/a o municipio', en: 'Public official or municipio' }, intro: { es: 'Escribo como funcionario/a público/a en Puerto Rico', en: 'I write as a public official in Puerto Rico' } },
  { id: 'other', label: { es: 'Otro', en: 'Other' }, intro: { es: 'Me preocupa el futuro del Censo en Puerto Rico', en: 'I care about the future of the Census in Puerto Rico' } },
]
