export function Eyebrow({ children, light = false }: { children: React.ReactNode; light?: boolean }) {
  return (
    <p className={`font-mono text-xs font-semibold uppercase tracking-[0.2em] ${light ? 'text-coral' : 'text-coral-deep'}`}>
      {children}
    </p>
  )
}

export function PageHero({ eyebrow, title, lede }: { eyebrow: string; title: string; lede: string }) {
  return (
    <section className="relative overflow-hidden border-b-2 border-ink">
      <div className="halftone pointer-events-none absolute -right-20 -top-20 h-80 w-80 rounded-full opacity-25" />
      <div className="relative mx-auto max-w-7xl px-5 py-16 md:py-24">
        <Eyebrow>{eyebrow}</Eyebrow>
        <h1 className="riso-text mt-4 max-w-4xl font-display text-5xl font-extrabold leading-[0.95] tracking-tight text-ink md:text-7xl">{title}</h1>
        <p className="mt-6 max-w-2xl text-lg text-ink/85 md:text-xl">{lede}</p>
      </div>
    </section>
  )
}
