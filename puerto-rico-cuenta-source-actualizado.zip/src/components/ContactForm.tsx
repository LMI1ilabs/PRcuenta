import { CheckCircle2 } from 'lucide-react'
import { useState } from 'react'
import { useLang } from '@/lib/i18n'

const input = 'w-full border-2 border-ink bg-paper px-3 py-2.5 text-ink placeholder:text-ink/40 focus:bg-white'
const label = 'mb-1.5 block font-mono text-xs font-semibold uppercase tracking-wider text-ink'

// Submissions go to Netlify Forms; the form is registered by public/__forms.html.
export function ContactForm() {
  const { t, lang } = useLang()
  const [state, setState] = useState<'idle' | 'sending' | 'done' | 'error'>('idle')

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault()
    setState('sending')
    try {
      const body = new URLSearchParams(new FormData(e.currentTarget) as unknown as Record<string, string>).toString()
      const res = await fetch('/__forms.html', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body,
      })
      if (!res.ok) throw new Error()
      setState('done')
    } catch {
      setState('error')
    }
  }

  if (state === 'done') {
    return (
      <div className="riso-shadow border-2 border-ink bg-paper p-8 text-ink">
        <CheckCircle2 className="h-10 w-10 text-coral" />
        <p className="mt-4 font-display text-2xl font-extrabold">{t({ es: '¡Gracias! Recibimos tu mensaje.', en: 'Thank you! We got your message.' })}</p>
        <p className="mt-2 text-ink/80">{t({ es: 'Lo usaremos para mejorar estas respuestas.', en: 'We’ll use it to improve these answers.' })}</p>
      </div>
    )
  }

  return (
    <form name="contacto" method="POST" data-netlify="true" netlify-honeypot="bot-field" onSubmit={onSubmit} className="riso-shadow border-2 border-ink bg-paper p-6 text-ink md:p-8">
      <input type="hidden" name="form-name" value="contacto" />
      <input type="hidden" name="language" value={lang} />
      <p className="hidden">
        <label>
          No llenes este campo: <input name="bot-field" tabIndex={-1} autoComplete="off" />
        </label>
      </p>
      <div className="grid gap-4 sm:grid-cols-2">
        <div>
          <label htmlFor="ct-name" className={label}>{t({ es: 'Nombre (opcional)', en: 'Name (optional)' })}</label>
          <input id="ct-name" name="name" autoComplete="name" className={input} />
        </div>
        <div>
          <label htmlFor="ct-email" className={label}>{t({ es: 'Correo electrónico', en: 'Email' })}</label>
          <input id="ct-email" name="email" type="email" required autoComplete="email" className={input} />
        </div>
      </div>
      <div className="mt-4">
        <label htmlFor="ct-message" className={label}>{t({ es: 'Tu pregunta o sugerencia', en: 'Your question or suggestion' })}</label>
        <textarea id="ct-message" name="message" rows={5} required className={input} placeholder={t({ es: '¿Qué otro tema debemos abordar?', en: 'What other topic should we cover?' })} />
      </div>
      <p className="mt-3 text-xs text-ink/70">
        {t({
          es: 'Solo usamos tu correo para contestarte. No lo publicamos ni lo compartimos.',
          en: 'We only use your email to reply. We never publish or share it.',
        })}
      </p>
      <button type="submit" disabled={state === 'sending'} className="riso-shadow-ink mt-5 border-2 border-ink bg-coral px-6 py-3 font-display text-lg font-extrabold text-ink transition-transform hover:-translate-y-0.5 disabled:opacity-60">
        {state === 'sending' ? t({ es: 'Enviando…', en: 'Sending…' }) : t({ es: 'Enviar mensaje', en: 'Send message' })}
      </button>
      {state === 'error' && (
        <p className="mt-3 text-sm font-semibold text-coral-deep" role="alert">
          {t({ es: 'No pudimos enviar tu mensaje. Inténtalo de nuevo.', en: 'We couldn’t send your message. Please try again.' })}
        </p>
      )}
    </form>
  )
}
