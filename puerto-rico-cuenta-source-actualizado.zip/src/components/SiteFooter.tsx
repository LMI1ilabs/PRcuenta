import { Link } from '@tanstack/react-router'
import { LINKS, RULE, SITE } from '@/content/site'
import { useLang } from '@/lib/i18n'
import { NAV } from './SiteHeader'
import { Logo } from './Star'

export function SiteFooter() {
  const { t } = useLang()
  const official = [
    { href: LINKS.federalRegister, label: { es: 'La regla propuesta (Federal Register)', en: 'The proposed rule (Federal Register)' } },
    { href: LINKS.extension, label: { es: 'Aviso de extensión', en: 'Extension notice' } },
    { href: LINKS.docket, label: { es: 'Expediente en Regulations.gov', en: 'Docket on Regulations.gov' } },
    { href: LINKS.handsOff, label: { es: 'Hands Off Our Census (nacional)', en: 'Hands Off Our Census (national)' } },
  ]
  return (
    <footer className="mt-24 border-t-2 border-ink bg-ink text-paper">
      <div className="mx-auto grid max-w-7xl gap-12 px-5 py-16 md:grid-cols-[1.4fr_1fr_1fr]">
        <div>
          <Logo light />
          <p className="mt-5 max-w-sm text-paper/80">
            {t({
              es: 'Una iniciativa cívica, no partidista y de beneficio público para que Puerto Rico y su diáspora defiendan sus datos públicos y se hagan contar en el Censo 2030.',
              en: 'A nonpartisan, public-benefit civic initiative so Puerto Rico and its diaspora can defend their public data and be counted in the 2030 Census.',
            })}
          </p>
          <p className="mt-5 font-mono text-sm text-coral">{SITE.hashtag}</p>
        </div>
        <div>
          <h2 className="font-mono text-xs uppercase tracking-widest text-paper/60">{t({ es: 'El sitio', en: 'The site' })}</h2>
          <ul className="mt-4 space-y-2">
            {NAV.map((n) => (
              <li key={n.to}>
                <Link to={n.to} className="hover:text-coral">{t(n.label)}</Link>
              </li>
            ))}
          </ul>
        </div>
        <div>
          <h2 className="font-mono text-xs uppercase tracking-widest text-paper/60">{t({ es: 'Fuentes oficiales', en: 'Official sources' })}</h2>
          <ul className="mt-4 space-y-2">
            {official.map((o) => (
              <li key={o.href}>
                <a href={o.href} target="_blank" rel="noreferrer" className="hover:text-coral">{t(o.label)} ↗</a>
              </li>
            ))}
          </ul>
        </div>
      </div>
      <div className="border-t border-paper/20">
        <div className="mx-auto flex max-w-7xl flex-col gap-2 px-5 py-5 font-mono text-xs text-paper/60 sm:flex-row sm:justify-between">
          <span>
            Docket {RULE.docketNo} · RIN {RULE.rin} · FR Doc {RULE.frDoc} · {RULE.regsDocket}
          </span>
          <span>{t({ es: 'Esto no es asesoría legal.', en: 'This is not legal advice.' })}</span>
        </div>
      </div>
    </footer>
  )
}
