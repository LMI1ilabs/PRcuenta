import { CheckCircle2 } from 'lucide-react'
import { useState } from 'react'
import { ROLES } from '@/content/comment'
import { DIASPORA_STATES, MUNICIPIOS } from '@/content/municipios'
import { useLang } from '@/lib/i18n'
import { useTracker } from './Tracker'

const input = 'w-full border-2 border-ink bg-paper px-3 py-2.5 text-ink placeholder:text-ink/40 focus:bg-white'
const label = 'mb-1.5 block font-mono text-xs font-semibold uppercase tracking-wider text-ink'

export function PledgeForm({ defaultStatus = 'pledged' }: { defaultStatus?: 'pledged' | 'commented' }) {
  const { t, lang } = useLang()
  const { setStats } = useTracker()
  const [status, setStatus] = useState(defaultStatus)
  const [state, setState] = useState<'idle' | 'sending' | 'done' | 'error'>('idle')

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault()
    const f = new FormData(e.currentTarget)
    setState('sending')
    try {
      const res = await fetch('/api/pledges', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: String(f.get('name') ?? ''),
          email: String(f.get('email') ?? ''),
          place: String(f.get('place') ?? ''),
          role: String(f.get('role') ?? ''),
          status,
          language: lang,
          contactOk: f.get('contactOk') === 'on',
          website: String(f.get('website') ?? ''),
        }),
      })
      if (!res.ok) throw new Error()
      setStats(await res.json())
      setState('done')
    } catch {
      setState('error')
    }
  }

  if (state === 'done') {
    return (
      <div className="riso-shadow border-2 border-ink bg-paper p-8 text-ink">
        <CheckCircle2 className="h-10 w-10 text-coral" />
        <p className="mt-4 font-display text-3xl font-extrabold">
          {status === 'commented'
            ? t({ es: '¡Gracias! Tu voz ya está en el récord.', en: 'Thank you! Your voice is on the record.' })
            : t({ es: '¡Cuentas con nosotros! Ahora escribe tu comentario.', en: 'You’re in! Now write your comment.' })}
        </p>
        <p className="mt-3 text-ink/80">
          {t({
            es: 'Comparte este sitio con tu familia, tu iglesia, tu equipo de trabajo o tu grupo de WhatsApp. Cada persona que comenta cuenta.',
            en: 'Share this site with your family, congregation, coworkers, or WhatsApp group. Every person who comments counts.',
          })}
        </p>
      </div>
    )
  }

  return (
    <form onSubmit={onSubmit} className="riso-shadow border-2 border-ink bg-paper p-6 text-ink md:p-8">
      <fieldset>
        <legend className={label}>{t({ es: 'Estoy aquí para…', en: 'I’m here to…' })}</legend>
        <div className="grid grid-cols-2 gap-2">
          {(
            [
              ['pledged', { es: 'Me comprometo a comentar', en: 'Pledge to comment' }],
              ['commented', { es: 'Ya envié mi comentario', en: 'I already commented' }],
            ] as const
          ).map(([v, l]) => (
            <button
              key={v}
              type="button"
              onClick={() => setStatus(v)}
              aria-pressed={status === v}
              className={`border-2 border-ink px-3 py-3 text-left text-sm font-semibold transition-colors ${status === v ? 'bg-ink text-paper' : 'bg-paper hover:bg-paper-deep'}`}
            >
              {t(l)}
            </button>
          ))}
        </div>
      </fieldset>

      <div className="mt-5 grid gap-4 sm:grid-cols-2">
        <div>
          <label htmlFor="pf-place" className={label}>{t({ es: '¿Dónde vives?', en: 'Where do you live?' })} *</label>
          <select id="pf-place" name="place" required className={input} defaultValue="">
            <option value="" disabled>{t({ es: 'Escoge tu municipio o estado', en: 'Choose your municipio or state' })}</option>
            <optgroup label={t({ es: 'Municipios de Puerto Rico', en: 'Puerto Rico municipios' })}>
              {MUNICIPIOS.map((m) => <option key={m} value={m}>{m}</option>)}
            </optgroup>
            <optgroup label={t({ es: 'Diáspora: estados', en: 'Diaspora: states' })}>
              {DIASPORA_STATES.map((s) => <option key={s} value={`diaspora:${s}`}>{s}</option>)}
            </optgroup>
          </select>
        </div>
        <div>
          <label htmlFor="pf-role" className={label}>{t({ es: 'Soy…', en: 'I am…' })} *</label>
          <select id="pf-role" name="role" required className={input} defaultValue="resident">
            {ROLES.map((r) => <option key={r.id} value={r.id}>{t(r.label)}</option>)}
          </select>
        </div>
        <div>
          <label htmlFor="pf-name" className={label}>{t({ es: 'Nombre (opcional)', en: 'Name (optional)' })}</label>
          <input id="pf-name" name="name" maxLength={120} className={input} autoComplete="given-name" />
        </div>
        <div>
          <label htmlFor="pf-email" className={label}>{t({ es: 'Email (opcional)', en: 'Email (optional)' })}</label>
          <input id="pf-email" name="email" type="email" maxLength={200} className={input} autoComplete="email" />
        </div>
      </div>

      {/* Honeypot for bots; hidden from people and assistive tech. */}
      <div className="hidden" aria-hidden="true">
        <label>Website <input name="website" tabIndex={-1} autoComplete="off" /></label>
      </div>

      <label className="mt-4 flex items-start gap-2.5 text-sm">
        <input type="checkbox" name="contactOk" className="mt-0.5 h-4 w-4 accent-[var(--color-coral-deep)]" />
        <span>{t({ es: 'Pueden escribirme con recordatorios y próximos pasos de la campaña.', en: 'You may email me reminders and next steps for the campaign.' })}</span>
      </label>

      <button
        type="submit"
        disabled={state === 'sending'}
        className="riso-shadow-ink mt-6 w-full border-2 border-ink bg-coral px-5 py-3.5 font-display text-lg font-extrabold text-ink transition-transform hover:-translate-y-0.5 disabled:opacity-60"
      >
        {state === 'sending' ? t({ es: 'Enviando…', en: 'Sending…' }) : t({ es: 'Súmame al contador', en: 'Add me to the tracker' })}
      </button>
      {state === 'error' && (
        <p className="mt-3 text-sm font-semibold text-coral-deep" role="alert">
          {t({ es: 'No pudimos guardar tu registro. Inténtalo otra vez.', en: 'We couldn’t save your entry. Please try again.' })}
        </p>
      )}
      <p className="mt-4 text-xs text-ink/70">
        {t({
          es: 'Solo publicamos totales por municipio o estado. Nunca mostramos ni compartimos tu nombre o email. Este registro no sustituye tu comentario oficial en Regulations.gov.',
          en: 'We only publish totals by municipio or state. We never display or share your name or email. This tracker does not replace your official comment on Regulations.gov.',
        })}
      </p>
    </form>
  )
}
