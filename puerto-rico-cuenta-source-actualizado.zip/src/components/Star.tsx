export function Star({ className = '' }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true" className={className} fill="currentColor">
      <path d="M12 1.5l3.09 7.26 7.86.68-5.96 5.17 1.79 7.69L12 18.27 5.22 22.3l1.79-7.69L1.05 9.44l7.86-.68z" />
    </svg>
  )
}

/** Wordmark: a flag-style triangle with a star, followed by the campaign name. */
export function Logo({ light = false }: { light?: boolean }) {
  return (
    <span className="flex items-center gap-2.5">
      <svg viewBox="0 0 40 32" className="h-8 w-10 shrink-0" aria-hidden="true">
        <rect x="0" y="0" width="40" height="32" fill="var(--color-coral)" />
        <rect x="0" y="8" width="40" height="5" fill="var(--color-paper)" />
        <rect x="0" y="19" width="40" height="5" fill="var(--color-paper)" />
        <path d="M0 0 L22 16 L0 32 Z" fill="var(--color-ink)" />
        <path transform="translate(2.2 10.5) scale(0.46)" fill="var(--color-paper)" d="M12 1.5l3.09 7.26 7.86.68-5.96 5.17 1.79 7.69L12 18.27 5.22 22.3l1.79-7.69L1.05 9.44l7.86-.68z" />
      </svg>
      <span className={`font-display text-xl font-extrabold leading-none tracking-tight ${light ? 'text-paper' : 'text-ink'}`}>
        Puerto Rico <span className="text-coral">Cuenta</span>
      </span>
    </span>
  )
}
