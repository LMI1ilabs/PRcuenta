import { createContext, useContext, useEffect, useState } from 'react'
import { MUNICIPIOS } from '@/content/municipios'
import { useLang } from '@/lib/i18n'
import type { TrackerStats } from '@/routes/api/pledges'

type Ctx = { stats: TrackerStats | null; setStats: (s: TrackerStats) => void }
const TrackerContext = createContext<Ctx>({ stats: null, setStats: () => {} })

/** Shares live tracker numbers between the pledge form and the tracker display. */
export function TrackerProvider({ children }: { children: React.ReactNode }) {
  const [stats, setStats] = useState<TrackerStats | null>(null)
  useEffect(() => {
    fetch('/api/pledges')
      .then((r) => (r.ok ? r.json() : null))
      .then((s) => s && setStats(s))
      .catch(() => {})
  }, [])
  return <TrackerContext.Provider value={{ stats, setStats }}>{children}</TrackerContext.Provider>
}

export const useTracker = () => useContext(TrackerContext)

const fmt = (n: number | undefined) => (n === undefined ? '—' : n.toLocaleString('es-PR'))

export function TrackerNumbers({ dark = false }: { dark?: boolean }) {
  const { t } = useLang()
  const { stats } = useTracker()
  const items = [
    { v: stats?.total, l: { es: 'personas en el contador', en: 'people on the tracker' } },
    { v: stats?.commented, l: { es: 'ya enviaron su comentario', en: 'have already commented' } },
    { v: stats ? stats.municipiosReached : undefined, suffix: ' / 78', l: { es: 'municipios presentes', en: 'municipios represented' } },
    { v: stats?.diaspora, l: { es: 'desde la diáspora', en: 'from the diaspora' } },
  ]
  return (
    <dl className="grid grid-cols-2 gap-px border-2 border-ink bg-ink md:grid-cols-4">
      {items.map((i) => (
        <div key={i.l.en} className={`${dark ? 'bg-ink-deep text-paper' : 'bg-paper text-ink'} p-5`}>
          <dt className="sr-only">{t(i.l)}</dt>
          <dd className="font-display text-4xl font-extrabold tabular-nums md:text-5xl">
            {fmt(i.v)}
            {i.suffix && <span className="text-xl opacity-60">{i.suffix}</span>}
          </dd>
          <dd className="mt-1 text-sm opacity-80">{t(i.l)}</dd>
        </div>
      ))}
    </dl>
  )
}

// Four-step single-hue scale (paper → ink) so the grid reads as "more is darker".
const STEPS = [
  { min: 0, cls: 'bg-paper text-ink/50 border-ink/25' },
  { min: 1, cls: 'bg-sky/40 text-ink border-ink/40' },
  { min: 5, cls: 'bg-sky text-ink-deep border-ink/60' },
  { min: 20, cls: 'bg-ink text-paper border-ink' },
]
const stepFor = (n: number) => [...STEPS].reverse().find((s) => n >= s.min)!

export function MunicipioGrid() {
  const { t } = useLang()
  const { stats } = useTracker()
  const counts = new Map(stats?.byPlace.map((p) => [p.place, p.total]) ?? [])
  const diaspora = (stats?.byPlace ?? []).filter((p) => p.place.startsWith('diaspora:')).slice(0, 8)

  return (
    <div>
      <div className="mb-4 flex flex-wrap items-center gap-4 font-mono text-xs text-ink">
        <span>{t({ es: 'Personas por municipio', en: 'People per municipio' })}:</span>
        {[
          { s: STEPS[0], l: '0' },
          { s: STEPS[1], l: '1–4' },
          { s: STEPS[2], l: '5–19' },
          { s: STEPS[3], l: '20+' },
        ].map(({ s, l }) => (
          <span key={l} className="flex items-center gap-1.5">
            <span className={`inline-block h-3.5 w-5 border ${s.cls}`} />
            {l}
          </span>
        ))}
      </div>
      <ul className="grid grid-cols-3 gap-1 sm:grid-cols-6 lg:grid-cols-9 xl:grid-cols-13">
        {MUNICIPIOS.map((m) => {
          const n = counts.get(m) ?? 0
          return (
            <li
              key={m}
              title={`${m}: ${n}`}
              className={`flex min-h-[3.25rem] flex-col justify-between border px-1.5 py-1 text-[0.68rem] leading-tight ${stepFor(n).cls}`}
            >
              <span className="font-semibold">{m}</span>
              <span className="font-mono tabular-nums">{n}</span>
            </li>
          )
        })}
      </ul>
      {diaspora.length > 0 && (
        <div className="mt-6">
          <h3 className="font-mono text-xs uppercase tracking-widest text-ink/70">{t({ es: 'La diáspora presente', en: 'The diaspora, present' })}</h3>
          <ul className="mt-2 flex flex-wrap gap-2">
            {diaspora.map((d) => (
              <li key={d.place} className="border-2 border-ink bg-coral/20 px-2.5 py-1 text-sm">
                {d.place.replace('diaspora:', '')} <span className="font-mono font-semibold">{d.total}</span>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  )
}
