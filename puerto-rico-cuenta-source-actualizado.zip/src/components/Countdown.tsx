import { useEffect, useState } from 'react'
import { RULE } from '@/content/site'
import { useLang } from '@/lib/i18n'

function remaining() {
  const ms = new Date(RULE.deadlineISO).getTime() - Date.now()
  if (ms <= 0) return null
  return {
    days: Math.floor(ms / 86_400_000),
    hours: Math.floor((ms / 3_600_000) % 24),
    minutes: Math.floor((ms / 60_000) % 60),
  }
}

// Rendered only after mount so server and client markup always match.
export function useCountdown() {
  const [left, setLeft] = useState<ReturnType<typeof remaining> | undefined>(undefined)
  useEffect(() => {
    setLeft(remaining())
    const id = window.setInterval(() => setLeft(remaining()), 30_000)
    return () => window.clearInterval(id)
  }, [])
  return left
}

export function CountdownTiles({ tone = 'light' }: { tone?: 'light' | 'dark' }) {
  const { t } = useLang()
  const left = useCountdown()
  const units = [
    { v: left?.days, l: { es: 'días', en: 'days' } },
    { v: left?.hours, l: { es: 'horas', en: 'hours' } },
    { v: left?.minutes, l: { es: 'minutos', en: 'minutes' } },
  ]
  if (left === null) {
    return <p className="font-display text-2xl font-bold">{t({ es: 'El periodo de comentarios cerró.', en: 'The comment period has closed.' })}</p>
  }
  const box = tone === 'dark' ? 'bg-ink text-paper border-ink' : 'bg-paper text-ink border-ink'
  return (
    <div className="flex gap-3" aria-live="polite">
      {units.map((u) => (
        <div key={u.l.en} className={`border-2 ${box} px-3 py-2 text-center min-w-[4.5rem]`}>
          <div className="font-display text-3xl font-extrabold tabular-nums leading-none">
            {u.v === undefined ? '—' : String(u.v).padStart(2, '0')}
          </div>
          <div className="mt-1 font-mono text-[0.65rem] uppercase tracking-widest">{t(u.l)}</div>
        </div>
      ))}
    </div>
  )
}
