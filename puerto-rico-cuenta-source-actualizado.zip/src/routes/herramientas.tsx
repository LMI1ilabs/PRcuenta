import { createFileRoute } from '@tanstack/react-router'
import { Check, Copy, Download } from 'lucide-react'
import { useEffect, useState } from 'react'
import { Eyebrow, PageHero } from '@/components/ui'
import { LINKS, SITE } from '@/content/site'
import { useCountdown } from '@/components/Countdown'
import { DAYS_TOKEN, OFFICIAL_LETTER, ORGANIZE_STEPS, SOCIAL_GROUPS, TALKING_POINTS } from '@/content/toolkit'
import { useLang } from '@/lib/i18n'
import { cdn } from '@/lib/img'

export const Route = createFileRoute('/herramientas')({
  component: ToolkitPage,
  head: () => ({ meta: [{ title: 'Herramientas · Puerto Rico Cuenta' }] }),
})

function CopyButton({ text }: { text: string }) {
  const { t } = useLang()
  const [done, setDone] = useState(false)
  return (
    <button
      type="button"
      onClick={async () => {
        await navigator.clipboard.writeText(text)
        setDone(true)
        window.setTimeout(() => setDone(false), 2000)
      }}
      className="flex items-center gap-1.5 border-2 border-ink bg-paper px-3 py-1.5 text-sm font-semibold text-ink hover:bg-paper-deep"
    >
      {done ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
      {done ? t({ es: 'Copiado', en: 'Copied' }) : t({ es: 'Copiar', en: 'Copy' })}
    </button>
  )
}

function ToolkitPage() {
  const { t } = useLang()
  const shareText = t({
    es: 'La regla propuesta del Censo 2030 afecta a Puerto Rico y a la diáspora. Entiéndela y comenta antes del 2 de noviembre:',
    en: 'The proposed 2030 Census rule affects Puerto Rico and the diaspora. Understand it and comment before Nov 2:',
  })
  // Read the origin after mount so server and client render the same href.
  const [url, setUrl] = useState('')
  useEffect(() => setUrl(window.location.origin), [])
  const whatsapp = `https://wa.me/?text=${encodeURIComponent(`${shareText} ${url} ${SITE.hashtag}`)}`
  const left = useCountdown()
  const fill = (text: string) => text.replace(DAYS_TOKEN, left ? String(left.days) : '[X]')
  const letter = t(OFFICIAL_LETTER)

  function downloadLetter() {
    const href = URL.createObjectURL(new Blob([letter], { type: 'text/plain;charset=utf-8' }))
    const a = Object.assign(document.createElement('a'), { href, download: 'carta-oficial-electo-censo-2030.txt' })
    a.click()
    URL.revokeObjectURL(href)
  }

  return (
    <>
      <PageHero
        eyebrow={t({ es: 'Herramientas para organizar', en: 'Organizing toolkit' })}
        title={t({ es: 'Una persona comenta. Una comunidad mueve el récord.', en: 'One person comments. A community moves the record.' })}
        lede={t({
          es: 'Mensajes clave, publicaciones listas para compartir y una guía para convocar a tu barrio, tu congregación, tu salón de clases o tu organización.',
          en: 'Key messages, ready-to-share posts, and a guide to rally your barrio, congregation, classroom, or organization.',
        })}
      />

      <section className="mx-auto max-w-7xl px-5 py-16">
        <Eyebrow>{t({ es: 'Mensajes clave', en: 'Talking points' })}</Eyebrow>
        <h2 className="mt-3 font-display text-4xl font-extrabold text-ink">{t({ es: 'Siete cosas que todo el mundo debe saber', en: 'Seven things everyone should know' })}</h2>
        <ol className="mt-10 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
          {TALKING_POINTS.map((p, i) => (
            <li key={p.en} className="border-2 border-ink bg-paper p-5">
              <span className="font-display text-3xl font-extrabold text-coral">{String(i + 1).padStart(2, '0')}</span>
              <p className="mt-2 text-lg font-medium text-ink">{t(p)}</p>
            </li>
          ))}
        </ol>
      </section>

      <section className="border-y-2 border-ink bg-paper-deep">
        <div className="mx-auto grid max-w-7xl gap-12 px-5 py-16 lg:grid-cols-[1.4fr_1fr]">
          <div>
            <Eyebrow>{t({ es: 'Para redes sociales', en: 'For social media' })}</Eyebrow>
            <h2 className="mt-3 font-display text-4xl font-extrabold text-ink">{t({ es: 'Copia, pega, comparte', en: 'Copy, paste, share' })}</h2>
            <p className="mt-3 text-ink/80">
              {t({
                es: 'Todas caben en X. Adáptalas a tu voz: los mensajes parecidos pero no idénticos llegan más lejos.',
                en: 'All of them fit on X. Adapt them to your voice: similar but not identical messages travel further.',
              })}
            </p>
            <div className="mt-8 space-y-10">
              {SOCIAL_GROUPS.map((g) => (
                <div key={g.title.en}>
                  <h3 className="font-mono text-xs font-semibold uppercase tracking-widest text-coral-deep">{t(g.title)}</h3>
                  <ul className="mt-3 space-y-4">
                    {g.posts.map((p) => (
                      <li key={p.en} className="border-2 border-ink bg-white p-5">
                        <p className="text-ink">{fill(t(p))}</p>
                        <div className="mt-4 flex justify-end"><CopyButton text={fill(t(p))} /></div>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
            <a href={whatsapp} target="_blank" rel="noreferrer" className="riso-shadow-ink mt-8 inline-block border-2 border-ink bg-coral px-6 py-3 font-display text-lg font-extrabold text-ink">
              {t({ es: 'Compartir por WhatsApp ↗', en: 'Share on WhatsApp ↗' })}
            </a>
          </div>
          <figure className="self-start lg:sticky lg:top-36">
            <img src={cdn('island.png', 800)} alt={t({ es: 'Ilustración: manos sostienen un formulario frente a las montañas de Puerto Rico.', en: 'Illustration: hands hold up a form in front of Puerto Rico’s mountains.' })} width={1024} height={1024} loading="lazy" className="riso-shadow block w-full border-2 border-ink" />
            <figcaption className="mt-4 font-mono text-xs text-ink/70">
              {t({ es: 'Puedes usar esta ilustración en tus publicaciones y hojas sueltas.', en: 'Feel free to use this illustration in your posts and flyers.' })}{' '}
              <a href="/img/island.png" download className="font-semibold underline">{t({ es: 'Descargar', en: 'Download' })}</a>
            </figcaption>
          </figure>
        </div>
      </section>

      <section id="carta" className="scroll-mt-40 mx-auto max-w-7xl px-5 py-16">
        <div className="grid gap-10 lg:grid-cols-[1fr_1.5fr]">
          <div>
            <Eyebrow>{t({ es: 'Carta a oficiales electos', en: 'Letter to elected officials' })}</Eyebrow>
            <h2 className="mt-3 font-display text-4xl font-extrabold text-ink">{t({ es: 'Pide una reunión antes del 2 de noviembre', en: 'Ask for a meeting before November 2' })}</h2>
            <p className="mt-4 text-lg text-ink/85">
              {t({
                es: 'Usa esta carta para pedirle a tu legislador, alcalde o jefe de agencia que el Gobierno de Puerto Rico, PRFAA, el Instituto de Estadísticas, la Junta de Planificación y los municipios sometan comentarios formales.',
                en: 'Use this letter to ask your legislator, mayor, or agency head to have the Government of Puerto Rico, PRFAA, the Institute of Statistics, the Planning Board, and the municipios file formal comments.',
              })}
            </p>
            <ol className="mt-6 space-y-2 text-ink/85">
              {[
                { es: 'Llena cada campo entre [corchetes].', en: 'Fill in every [bracketed] field.' },
                { es: 'Añade a tu organización co-firmante y a quienes endosan.', en: 'Add your co-signing organization and endorsers.' },
                { es: 'Envíala por correo electrónico y da seguimiento por teléfono.', en: 'Send it by email and follow up by phone.' },
              ].map((s, i) => (
                <li key={s.en} className="flex gap-3"><span className="font-display font-extrabold text-coral-deep">{i + 1}.</span>{t(s)}</li>
              ))}
            </ol>
          </div>
          <div className="riso-shadow border-2 border-ink bg-white">
            <div className="flex items-center justify-between gap-3 border-b-2 border-ink bg-paper-deep px-4 py-2">
              <span className="font-mono text-xs font-semibold uppercase tracking-wider text-ink">{t({ es: 'Borrador de solicitud de reunión', en: 'Meeting request draft' })}</span>
              <div className="flex gap-2">
                <CopyButton text={letter} />
                <button type="button" onClick={downloadLetter} className="flex items-center gap-1.5 border-2 border-ink bg-paper px-3 py-1.5 text-sm font-semibold text-ink hover:bg-paper-deep">
                  <Download className="h-4 w-4" />.txt
                </button>
              </div>
            </div>
            <textarea
              readOnly
              value={letter}
              aria-label={t({ es: 'Carta a oficiales electos', en: 'Letter to elected officials' })}
              className="block h-[30rem] w-full resize-none bg-white p-4 font-mono text-[0.8rem] leading-relaxed text-ink-deep"
            />
          </div>
        </div>
      </section>

      <section className="border-t-2 border-ink mx-auto max-w-7xl px-5 py-16">
        <Eyebrow>{t({ es: 'Organiza', en: 'Organize' })}</Eyebrow>
        <h2 className="mt-3 font-display text-4xl font-extrabold text-ink">{t({ es: 'Cómo hacer un “comment-a-thon”', en: 'How to run a comment-a-thon' })}</h2>
        <ol className="mt-10 grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          {ORGANIZE_STEPS.map((s, i) => (
            <li key={s.title.en} className="relative border-2 border-ink p-6 pt-10">
              <span className="absolute -top-5 left-6 flex h-10 w-10 items-center justify-center border-2 border-ink bg-coral font-display text-xl font-extrabold text-ink">{i + 1}</span>
              <h3 className="font-display text-xl font-extrabold text-ink">{t(s.title)}</h3>
              <p className="mt-2 text-ink/85">{t(s.body)}</p>
            </li>
          ))}
        </ol>

        <div className="mt-16 grid gap-6 md:grid-cols-2">
          <div className="border-2 border-ink bg-ink p-6 text-paper">
            <p className="font-mono text-xs uppercase tracking-widest text-coral">{t({ es: 'Lectura recomendada', en: 'Further reading' })}</p>
            <ul className="mt-4 space-y-3">
              <li><a href={LINKS.crs} target="_blank" rel="noreferrer" className="underline decoration-coral underline-offset-4">Congressional Research Service: Citizenship and Residence Criteria for the 2030 Census ↗</a></li>
              <li><a href={LINKS.naco} target="_blank" rel="noreferrer" className="underline decoration-coral underline-offset-4">NACo: Proposed Rule on the 2030 Census — What Counties Need to Know ↗</a></li>
              <li><a href={LINKS.handsOff} target="_blank" rel="noreferrer" className="underline decoration-coral underline-offset-4">Hands Off Our Census ↗</a></li>
              <li><a href={LINKS.commentTips} target="_blank" rel="noreferrer" className="underline decoration-coral underline-offset-4">{t({ es: 'Regulations.gov: cómo escribir un comentario efectivo ↗', en: 'Regulations.gov: tips for effective comments ↗' })}</a></li>
              <li><a href={LINKS.pria} target="_blank" rel="noreferrer" className="underline decoration-coral underline-offset-4">{t({ es: 'Análisis preliminar de impacto regulatorio (PRIA) ↗', en: 'Preliminary Regulatory Impact Analysis (PRIA) ↗' })}</a></li>
            </ul>
          </div>
          <div className="border-2 border-ink p-6">
            <p className="font-mono text-xs uppercase tracking-widest text-coral-deep">{t({ es: 'Datos abiertos', en: 'Open data' })}</p>
            <p className="mt-3 text-lg text-ink">
              {t({
                es: 'Los datos del Censo son gratuitos y abiertos en data.census.gov. Periodistas, estudiantes y organizaciones: úsenlos para mostrar lo que se perdería en su municipio sin datos de origen y raza.',
                en: 'Census data are free and open at data.census.gov. Journalists, students, and organizations: use them to show what your municipio would lose without origin and race data.',
              })}
            </p>
            <div className="mt-4 flex flex-wrap gap-x-6 gap-y-2">
              <a href={LINKS.dataCensusPR} target="_blank" rel="noreferrer" className="font-semibold text-ink underline decoration-coral decoration-2 underline-offset-4">{t({ es: 'Perfil de Puerto Rico en data.census.gov ↗', en: 'Puerto Rico profile on data.census.gov ↗' })}</a>
              <a href={LINKS.censusPR} target="_blank" rel="noreferrer" className="font-semibold text-ink underline decoration-coral decoration-2 underline-offset-4">{t({ es: 'Página de Puerto Rico de la Oficina del Censo ↗', en: 'Census Bureau Puerto Rico page ↗' })}</a>
            </div>
          </div>
        </div>
      </section>
    </>
  )
}
