import { Link, createFileRoute } from '@tanstack/react-router'
import { ArrowRight } from 'lucide-react'
import { CountdownTiles } from '@/components/Countdown'
import { PledgeForm } from '@/components/PledgeForm'
import { Star } from '@/components/Star'
import { MunicipioGrid, TrackerNumbers, TrackerProvider } from '@/components/Tracker'
import { Eyebrow } from '@/components/ui'
import { FAQ } from '@/content/faq'
import { LINKS, RULE } from '@/content/site'
import { type L, useLang } from '@/lib/i18n'
import { cdn } from '@/lib/img'

export const Route = createFileRoute('/')({ component: Home })

const CHANGES: { n: string; part: string; title: L; body: L; anchor: string }[] = [
  {
    n: '01',
    part: 'Parte 60 · § 60.2',
    title: { es: 'Dónde te cuentan', en: 'Where you’re counted' },
    body: {
      es: 'Tu “residencia habitual” sería el lugar donde pasaste legalmente más días entre el 3 de enero y el 1 de abril, y debe ser consistente con tus récords contributivos, aunque muchas personas en Puerto Rico no rinden planilla federal y muchas reciben correo en un apartado o una ruta rural. Se asume que usarían las planillas de Hacienda, pero la regla no lo dice. ¿Y si no rindes planilla… no cuentas?',
      en: 'Your “usual residence” would be wherever you lawfully spent the most days between January 3 and April 1, and it should be consistent with your tax records, even though many people in Puerto Rico don’t file a federal return and many get mail at a P.O. box or rural route. The assumption is that Hacienda returns would be used, but the rule doesn’t say so. So if you don’t file… you don’t count?',
    },
    anchor: 'residencia',
  },
  {
    n: '02',
    part: 'Parte 60 · § 60.4–60.5',
    title: { es: 'A quién cuentan', en: 'Who gets counted' },
    body: {
      es: 'Excluiría de la distribución de escaños a muchas personas que no son ciudadanas y abre la puerta a una pregunta de estatus legal. Y cuando habla de “fuera de los Estados Unidos”, nunca dice dónde queda Puerto Rico.',
      en: 'It would exclude many non-citizens from apportionment and opens the door to a legal-status question. And when it says “outside the United States,” it never says where Puerto Rico stands.',
    },
    anchor: 'fuera',
  },
  {
    n: '03',
    part: 'Parte 70 · § 70.2',
    title: { es: 'Raza y etnicidad', en: 'Race and ethnicity' },
    body: {
      es: 'Prohibiría preguntar raza y etnicidad en el Censo, incluido el encasillado “puertorriqueño”. Es la única forma en que el Censo identifica a los boricuas, en los estados y en Puerto Rico.',
      en: 'It would ban race and ethnicity questions on the Census, including the “Puerto Rican” checkbox. That checkbox is the only way the Census identifies Puerto Ricans, in the states and in Puerto Rico.',
    },
    anchor: 'etnicidad',
  },
]

const AT_RISK: { h: L; b: L }[] = [
  { h: { es: 'Salud', en: 'Health' }, b: { es: 'Asignaciones de Medicaid y PAN (NAP) para la cobertura de familias de bajos ingresos y la sostenibilidad de los hospitales.', en: 'Medicaid and NAP allocations that cover low-income families and keep hospitals running.' } },
  { h: { es: 'Educación y niñez', en: 'Education and children' }, b: { es: 'Fondos para escuelas públicas bajo el Título I y centros Head Start.', en: 'Title I funds for public schools, and Head Start centers.' } },
  { h: { es: 'Vivienda', en: 'Housing' }, b: { es: 'Vales de Sección 8 y desarrollo comunitario (CDBG).', en: 'Section 8 vouchers and community development (CDBG).' } },
  { h: { es: 'Infraestructura y desastres', en: 'Infrastructure and disasters' }, b: { es: 'Fondos federales de carreteras y fórmulas para la recuperación tras desastres.', en: 'Federal highway funds and disaster-recovery formulas.' } },
]

const SECTORS: { h: L; b: L }[] = [
  { h: { es: 'Gobiernos y entidades públicas', en: 'Governments and public bodies' }, b: { es: 'Municipios, agencias, seguridad pública (Policía, Bomberos, Manejo de Emergencias) y distritos electorales.', en: 'Municipios, agencies, public safety (police, fire, emergency management), and electoral districts.' } },
  { h: { es: 'Salud y bienestar social', en: 'Health and social welfare' }, b: { es: 'Hospitales, centros de salud comunitaria (CDT), égidas, centros de cuido y organizaciones sin fines de lucro.', en: 'Hospitals, community health centers, elder-care homes, child-care centers, and nonprofits.' } },
  { h: { es: 'Educación y academia', en: 'Education and academia' }, b: { es: 'Escuelas públicas y privadas, centros Head Start, universidades y centros de investigación.', en: 'Public and private schools, Head Start centers, universities, and research centers.' } },
  { h: { es: 'Sector privado', en: 'Private sector' }, b: { es: 'PyMEs, comercio al detal, alimentos y suministros, bienes raíces, construcción, banca, seguros y turismo.', en: 'Small and midsize businesses, retail, food and supply, real estate, construction, banking, insurance, and tourism.' } },
]

const STATS: { v: string; l: L }[] = [
  { v: '0', l: { es: 'veces que la regla menciona a Puerto Rico', en: 'times the rule mentions Puerto Rico' } },
  { v: '3,285,874', l: { es: 'personas contadas en Puerto Rico en el Censo 2020', en: 'people counted in Puerto Rico in the 2020 Census' } },
  { v: '5.8M+', l: { es: 'boricuas en los estados, identificados solo por la pregunta de origen hispano', en: 'Puerto Ricans in the states, identified only by the Hispanic-origin question' } },
  { v: '78', l: { es: 'municipios que planifican con datos del Censo', en: 'municipios that plan with Census data' } },
]

const MARQUEE = ['15 CFR Parte 60', '15 CFR Parte 70', `Docket ${RULE.regsDocket}`, '2 nov 2026', '#PRCuenta', 'Datos abiertos', 'Que nos cuenten a todos']

function Home() {
  const { t } = useLang()
  return (
    <TrackerProvider>
      {/* Hero */}
      <section className="relative border-b-2 border-ink">
        <div className="mx-auto grid max-w-7xl items-center gap-10 px-5 pb-14 pt-12 lg:grid-cols-[1.05fr_1fr] lg:pt-16">
          <div>
            <Eyebrow>{t({ es: 'Censo 2030 · Regla propuesta · 15 CFR Partes 60 y 70', en: '2030 Census · Proposed rule · 15 CFR Parts 60 & 70' })}</Eyebrow>
            <h1 className="riso-text mt-5 font-display text-[3.2rem] font-extrabold leading-[0.92] tracking-tight text-ink sm:text-7xl xl:text-[5.5rem]">
              {t({ es: 'Que no nos borren del Censo.', en: 'Don’t let them erase us from the Census.' })}
            </h1>
            <p className="mt-6 max-w-xl text-lg text-ink/85 md:text-xl">
              {t({
                es: 'La Oficina del Censo propone cambiar a quién cuenta, dónde lo cuenta, cómo lo cuenta y qué puede preguntar. Esas reglas definirían el Censo 2030 y los datos públicos de Puerto Rico por una década, y esos datos son la base de cómo se distribuyen miles de millones de dólares federales a Puerto Rico. Tenemos hasta el 2 de noviembre para decir algo.',
                en: 'The Census Bureau proposes to change who it counts, where and how it counts them, and what it may ask. Those rules would shape the 2030 Census and Puerto Rico’s public data for a decade, and those data drive how billions of federal dollars reach Puerto Rico. We have until November 2 to speak up.',
              })}
            </p>
            <div className="mt-6 max-w-xl border-l-4 border-coral pl-4">
              <p className="font-mono text-xs font-semibold uppercase tracking-widest text-coral-deep">{t({ es: 'Si el conteo sale mal, está en riesgo', en: 'If the count goes wrong, at risk are' })}</p>
              <ul className="mt-2 space-y-1.5 text-ink/85">
                {AT_RISK.map((r) => (
                  <li key={r.h.en}><span className="font-bold text-ink">{t(r.h)}:</span> {t(r.b)}</li>
                ))}
              </ul>
            </div>
            <div className="mt-8 flex flex-wrap gap-4">
              <Link to="/comenta" className="riso-shadow-ink inline-flex items-center gap-2 border-2 border-ink bg-coral px-6 py-3.5 font-display text-lg font-extrabold text-ink transition-transform hover:-translate-y-0.5">
                {t({ es: 'Escribe tu comentario', en: 'Write your comment' })} <ArrowRight className="h-5 w-5" />
              </Link>
              <Link to="/la-regla" className="inline-flex items-center gap-2 border-2 border-ink bg-paper px-6 py-3.5 font-display text-lg font-bold text-ink hover:bg-paper-deep">
                {t({ es: 'Entiende la regla', en: 'Understand the rule' })}
              </Link>
            </div>
            <div className="mt-10">
              <p className="mb-2 font-mono text-xs uppercase tracking-widest text-ink/70">{t({ es: 'Tiempo para comentar', en: 'Time left to comment' })}</p>
              <CountdownTiles />
            </div>
          </div>
          <figure className="riso-shadow relative border-2 border-ink bg-paper">
            <img
              src={cdn('hero.png', 1100)}
              srcSet={`${cdn('hero.png', 700)} 700w, ${cdn('hero.png', 1100)} 1100w, ${cdn('hero.png', 1500)} 1500w`}
              sizes="(min-width: 1024px) 45vw, 100vw"
              alt={t({ es: 'Ilustración: vecinos en una calle de Puerto Rico conversan con una voluntaria del Censo.', en: 'Illustration: neighbors on a Puerto Rico street talk with a census volunteer.' })}
              width={1376}
              height={768}
              className="block h-auto w-full"
            />
            <figcaption className="absolute -bottom-5 left-5 border-2 border-ink bg-ink px-3 py-1.5 font-mono text-xs text-paper">
              {t({ es: 'Contar a todos: una vez y en el lugar correcto', en: 'Count everyone: once, and in the right place' })}
            </figcaption>
          </figure>
        </div>
      </section>

      {/* Marquee */}
      <div className="overflow-hidden border-b-2 border-ink bg-coral py-3" aria-hidden="true">
        <div className="marquee-track flex w-max gap-8 whitespace-nowrap font-display text-xl font-extrabold uppercase text-ink">
          {[...MARQUEE, ...MARQUEE].map((m, i) => (
            <span key={i} className="flex items-center gap-8">
              {m} <Star className="h-4 w-4" />
            </span>
          ))}
        </div>
      </div>

      {/* What changes */}
      <section className="mx-auto max-w-7xl px-5 py-20">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <div>
            <Eyebrow>{t({ es: 'Lo que quieren cambiar', en: 'What they want to change' })}</Eyebrow>
            <h2 className="mt-3 max-w-3xl font-display text-4xl font-extrabold leading-tight text-ink md:text-5xl">
              {t({ es: 'Tres cambios. Ninguno piensa en Puerto Rico.', en: 'Three changes. None of them considers Puerto Rico.' })}
            </h2>
          </div>
          <Link to="/la-regla" className="font-semibold text-ink underline decoration-coral decoration-2 underline-offset-4">
            {t({ es: 'Lee la explicación completa →', en: 'Read the full explainer →' })}
          </Link>
        </div>
        <div className="mt-12 grid gap-6 md:grid-cols-3">
          {CHANGES.map((c) => (
            <Link
              key={c.n}
              to="/la-regla"
              hash={c.anchor}
              className="group flex flex-col border-2 border-ink bg-paper p-6 transition-all hover:-translate-x-1 hover:-translate-y-1 hover:shadow-[8px_8px_0_0_var(--color-coral)]"
            >
              <span className="font-display text-6xl font-extrabold text-coral">{c.n}</span>
              <span className="mt-4 font-mono text-xs uppercase tracking-wider text-ink/60">{c.part}</span>
              <h3 className="mt-2 font-display text-2xl font-extrabold text-ink">{t(c.title)}</h3>
              <p className="mt-3 flex-1 text-ink/85">{t(c.body)}</p>
              <span className="mt-6 font-semibold text-ink group-hover:text-coral-deep">{t({ es: 'Qué significa →', en: 'What it means →' })}</span>
            </Link>
          ))}
        </div>
      </section>

      {/* Why Puerto Rico */}
      <section className="border-y-2 border-ink bg-ink text-paper">
        <div className="mx-auto grid max-w-7xl gap-12 px-5 py-20 lg:grid-cols-[1fr_1.15fr]">
          <div>
            <Eyebrow light>{t({ es: 'Por qué importa en Puerto Rico', en: 'Why it matters for Puerto Rico' })}</Eyebrow>
            <h2 className="mt-3 font-display text-4xl font-extrabold leading-tight md:text-5xl">
              {t({ es: 'Si no nos cuentan, no existimos en los datos.', en: 'If we’re not counted, we don’t exist in the data.' })}
            </h2>
            <p className="mt-6 text-lg text-paper/85">
              {t({
                es: 'Con los datos del Censo se demarcan los distritos electorales de Puerto Rico, se ajusta la Encuesta sobre la Comunidad y se reparten miles de millones de dólares en fondos federales para salud, alimentos, educación y recuperación de desastres. Lo que el Censo deje de preguntar en 2030 no lo vamos a poder recuperar. Todos los sectores se afectan:',
                en: 'Census data are used to draw Puerto Rico’s electoral districts, weight the Puerto Rico Community Survey, and distribute billions in federal funds for health, nutrition, education, and disaster recovery. Whatever the Census stops asking in 2030, we won’t get back. Every sector is affected:',
              })}
            </p>
            <dl className="mt-6 space-y-4">
              {SECTORS.map((s) => (
                <div key={s.h.en} className="border-l-2 border-coral pl-4">
                  <dt className="font-display text-lg font-bold text-paper">{t(s.h)}</dt>
                  <dd className="text-paper/80">{t(s.b)}</dd>
                </div>
              ))}
            </dl>
            <Link to="/impacto" className="mt-8 inline-block font-semibold text-coral underline decoration-2 underline-offset-4">
              {t({ es: 'Mira el impacto en Puerto Rico →', en: 'See the impact on Puerto Rico →' })}
            </Link>
            <img
              src={cdn('island.png', 640)}
              alt={t({ es: 'Ilustración: manos sostienen un formulario frente a las montañas de Puerto Rico.', en: 'Illustration: hands hold up a form in front of Puerto Rico’s mountains.' })}
              width={1024}
              height={1024}
              loading="lazy"
              className="mt-10 hidden w-72 border-2 border-paper lg:block"
            />
          </div>
          <dl className="grid content-start gap-px self-start border-2 border-paper/30 bg-paper/30 sm:grid-cols-2">
            {STATS.map((s) => (
              <div key={s.v} className="bg-ink p-7">
                <dt className="sr-only">{t(s.l)}</dt>
                <dd className="font-display text-5xl font-extrabold tabular-nums text-coral md:text-6xl">{s.v}</dd>
                <dd className="mt-3 text-paper/85">{t(s.l)}</dd>
              </div>
            ))}
            <div className="bg-ink p-7 sm:col-span-2">
              <p className="font-mono text-xs text-paper/60">
                {t({
                  es: 'Fuentes: texto de FR Doc 2026-18481; Censo 2020 (población residente de Puerto Rico); estimados de la Encuesta sobre la Comunidad para la población de origen puertorriqueño en los 50 estados y D.C.',
                  en: 'Sources: text of FR Doc 2026-18481; 2020 Census (Puerto Rico resident population); American Community Survey estimates of the Puerto Rican-origin population in the 50 states and D.C.',
                })}
              </p>
            </div>
          </dl>
        </div>
      </section>

      {/* Three steps */}
      <section className="mx-auto max-w-7xl px-5 py-20">
        <Eyebrow>{t({ es: 'Cómo actuar', en: 'How to act' })}</Eyebrow>
        <h2 className="mt-3 font-display text-4xl font-extrabold text-ink md:text-5xl">{t({ es: 'Quince minutos. Tres pasos.', en: 'Fifteen minutes. Three steps.' })}</h2>
        <ol className="mt-12 grid gap-6 md:grid-cols-3">
          {[
            { to: '/la-regla', h: { es: 'Entiende', en: 'Understand' }, b: { es: 'Lee en lenguaje sencillo lo que dicen las Partes 60 y 70 y cómo afectan a Puerto Rico.', en: 'Read in plain language what Parts 60 and 70 say and how they affect Puerto Rico.' } },
            { to: '/comenta', h: { es: 'Escribe', en: 'Write' }, b: { es: 'Usa nuestro generador para preparar un comentario formal, añade tu propia historia y envíalo.', en: 'Use our builder to prepare a formal comment, add your own story, and submit it.' } },
            { to: '/herramientas', h: { es: 'Multiplica', en: 'Multiply' }, b: { es: 'Comparte el mensaje, organiza un “comment-a-thon” y súmate al contador.', en: 'Share the message, host a comment-a-thon, and join the tracker.' } },
          ].map((s, i) => (
            <li key={s.to} className="relative border-2 border-ink p-6 pt-10">
              <span className="absolute -top-5 left-6 flex h-10 w-10 items-center justify-center border-2 border-ink bg-coral font-display text-xl font-extrabold text-ink">{i + 1}</span>
              <h3 className="font-display text-2xl font-extrabold text-ink">{t(s.h)}</h3>
              <p className="mt-2 text-ink/85">{t(s.b)}</p>
              <Link to={s.to} className="mt-4 inline-block font-semibold text-ink underline decoration-coral decoration-2 underline-offset-4">{t({ es: 'Ir →', en: 'Go →' })}</Link>
            </li>
          ))}
        </ol>
      </section>

      {/* Tracker */}
      <section id="contador" className="border-y-2 border-ink bg-paper-deep">
        <div className="mx-auto max-w-7xl px-5 py-20">
          <div className="grid gap-12 lg:grid-cols-[1.25fr_1fr]">
            <div>
              <Eyebrow>{t({ es: 'El contador', en: 'The tracker' })}</Eyebrow>
              <h2 className="mt-3 font-display text-4xl font-extrabold text-ink md:text-5xl">
                {t({ es: 'Que se vean los 78 municipios.', en: 'Let all 78 municipios show up.' })}
              </h2>
              <p className="mt-4 max-w-xl text-lg text-ink/85">
                {t({
                  es: 'Cada persona que se compromete o ya comentó ilumina su municipio o su estado. Ayúdanos a llenar el mapa antes del 2 de noviembre.',
                  en: 'Everyone who pledges or has already commented lights up their municipio or state. Help us fill the map before November 2.',
                })}
              </p>
              <div className="mt-8">
                <TrackerNumbers />
              </div>
              <div className="mt-8">
                <MunicipioGrid />
              </div>
            </div>
            <div className="lg:pt-24">
              <PledgeForm />
            </div>
          </div>
        </div>
      </section>

      {/* FAQ teaser */}
      <section className="mx-auto max-w-7xl px-5 py-20">
        <div className="grid gap-12 lg:grid-cols-[1fr_1.4fr]">
          <div>
            <Eyebrow>{t({ es: 'Preguntas frecuentes', en: 'Frequently asked' })}</Eyebrow>
            <h2 className="mt-3 font-display text-4xl font-extrabold text-ink">{t({ es: 'Lo que más nos preguntan', en: 'What people ask most' })}</h2>
            <p className="mt-4 text-ink/85">
              {t({
                es: 'Esta campaña se inspira en Hands Off Our Census, el esfuerzo nacional de organizaciones de datos y derechos civiles, y se enfoca en Puerto Rico y su diáspora.',
                en: 'This campaign is inspired by Hands Off Our Census, the national effort by data and civil rights organizations, and focuses on Puerto Rico and its diaspora.',
              })}{' '}
              <a href={LINKS.handsOff} target="_blank" rel="noreferrer" className="font-semibold underline decoration-coral decoration-2 underline-offset-4">handsoffourcens.us ↗</a>
            </p>
            <Link to="/preguntas" className="mt-6 inline-block border-2 border-ink px-5 py-3 font-bold text-ink hover:bg-paper-deep">
              {t({ es: 'Todas las preguntas', en: 'All questions' })}
            </Link>
          </div>
          <div className="divide-y-2 divide-ink border-y-2 border-ink">
            {FAQ.slice(1, 4).map((f) => (
              <details key={f.q.en} className="group py-5">
                <summary className="flex cursor-pointer list-none items-start justify-between gap-4 font-display text-xl font-bold text-ink">
                  {t(f.q)}
                  <span className="mt-1 text-coral transition-transform group-open:rotate-45">+</span>
                </summary>
                <p className="mt-3 text-ink/85">{t(f.a)}</p>
              </details>
            ))}
          </div>
        </div>
      </section>
    </TrackerProvider>
  )
}
