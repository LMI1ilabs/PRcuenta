import { Link, createFileRoute } from '@tanstack/react-router'
import { FileText } from 'lucide-react'
import { Eyebrow, PageHero } from '@/components/ui'
import { RULE_CHANGES } from '@/content/rule'
import { LINKS, RULE } from '@/content/site'
import { useLang } from '@/lib/i18n'

export const Route = createFileRoute('/la-regla')({
  component: RulePage,
  head: () => ({ meta: [{ title: 'La regla: Partes 60 y 70 · Puerto Rico Cuenta' }] }),
})

const PARTS = [
  {
    part: '60' as const,
    title: { es: 'Parte 60: Criterios de residencia', en: 'Part 60: Residence criteria' },
    sub: { es: 'A quién se cuenta y dónde', en: 'Who is counted, and where' },
  },
  {
    part: '70' as const,
    title: { es: 'Parte 70: Restricciones a las preguntas demográficas', en: 'Part 70: Restrictions on demographic questions' },
    sub: { es: 'Lo que el Censo puede preguntar', en: 'What the Census may ask' },
  },
]

function RulePage() {
  const { t } = useLang()
  const docs = [
    ['Federal Register', `${RULE.citation} · FR Doc ${RULE.frDoc}`, LINKS.federalRegister],
    [t({ es: 'Texto completo (PDF)', en: 'Full text (PDF)' }), t({ es: 'Versión de inspección pública', en: 'Public inspection version' }), LINKS.rulePdf],
    [t({ es: 'Extensión del plazo', en: 'Deadline extension' }), `FR Doc ${RULE.extensionDoc}`, LINKS.extension],
    ['Regulations.gov', `Docket ${RULE.regsDocket}`, LINKS.docket],
  ]
  return (
    <>
      <PageHero
        eyebrow={t({ es: 'La regla propuesta, en lenguaje sencillo', en: 'The proposed rule, in plain language' })}
        title={t({ es: 'Lo que dicen las Partes 60 y 70, y lo que callan sobre Puerto Rico.', en: 'What Parts 60 and 70 say, and what they leave unsaid about Puerto Rico.' })}
        lede={t({
          es: `El 10 de septiembre de 2026 la Oficina del Censo publicó “${RULE.title}”. Propone añadir dos partes nuevas al Título 15 del Código de Regulaciones Federales que regirían el Censo 2030 y los siguientes.`,
          en: `On September 10, 2026, the Census Bureau published “${RULE.title}.” It proposes two new parts of Title 15 of the Code of Federal Regulations that would govern the 2030 Census and beyond.`,
        })}
      />

      <div className="mx-auto grid max-w-7xl gap-12 px-5 py-16 lg:grid-cols-[16rem_1fr]">
        <aside className="lg:sticky lg:top-36 lg:self-start">
          <nav aria-label={t({ es: 'En esta página', en: 'On this page' })}>
            <p className="font-mono text-xs uppercase tracking-widest text-ink/60">{t({ es: 'En esta página', en: 'On this page' })}</p>
            <ul className="mt-3 space-y-1.5 border-l-2 border-ink pl-4 text-sm">
              {RULE_CHANGES.map((c) => (
                <li key={c.id}>
                  <a href={`#${c.id}`} className="text-ink hover:text-coral-deep">
                    <span className="font-mono text-xs text-ink/60">{c.section}</span> {t(c.title)}
                  </a>
                </li>
              ))}
              <li><a href="#silencio" className="font-semibold text-ink hover:text-coral-deep">{t({ es: 'Lo que la regla no dice', en: 'What the rule doesn’t say' })}</a></li>
            </ul>
          </nav>
          <div className="mt-8 border-2 border-ink bg-paper-deep p-4">
            <p className="font-mono text-xs uppercase tracking-widest text-ink/70">{t({ es: 'Documentos oficiales', en: 'Official documents' })}</p>
            <ul className="mt-3 space-y-3">
              {docs.map(([name, meta, href]) => (
                <li key={href}>
                  <a href={href} target="_blank" rel="noreferrer" className="flex gap-2 text-sm text-ink hover:text-coral-deep">
                    <FileText className="mt-0.5 h-4 w-4 shrink-0" />
                    <span><span className="font-semibold">{name}</span><br /><span className="font-mono text-xs text-ink/60">{meta}</span></span>
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </aside>

        <div className="space-y-20">
          {PARTS.map((p) => (
            <section key={p.part}>
              <div className="border-b-2 border-ink pb-4">
                <Eyebrow>{t(p.sub)}</Eyebrow>
                <h2 className="mt-2 font-display text-4xl font-extrabold text-ink">{t(p.title)}</h2>
              </div>
              <div className="mt-8 space-y-10">
                {RULE_CHANGES.filter((c) => c.part === p.part).map((c) => (
                  <article key={c.id} id={c.id} className="scroll-mt-40">
                    <div className="flex items-baseline gap-3">
                      <span className="border-2 border-ink bg-coral px-2 py-0.5 font-mono text-xs font-semibold text-ink">{c.section}</span>
                      <h3 className="font-display text-2xl font-extrabold text-ink md:text-3xl">{t(c.title)}</h3>
                    </div>
                    <p className="mt-4 text-lg text-ink/90">{t(c.plain)}</p>
                    {c.example && (
                      <p className="mt-4 border-2 border-dashed border-ink/40 px-5 py-4 text-ink/90">
                        <span className="font-mono text-xs font-semibold uppercase tracking-widest text-coral">{t({ es: 'Por ejemplo', en: 'For example' })}</span>
                        <br />
                        {t(c.example)}
                      </p>
                    )}
                    <blockquote className="mt-5 border-l-4 border-coral bg-white/60 px-5 py-4 font-mono text-sm leading-relaxed text-ink/80">
                      {c.quote}
                      <footer className="mt-2 text-xs text-ink/60">{t({ es: 'Texto propuesto', en: 'Proposed text' })}, 15 CFR {c.section}</footer>
                    </blockquote>
                    <div className="riso-shadow mt-5 border-2 border-ink bg-ink p-5 text-paper">
                      <p className="font-mono text-xs font-semibold uppercase tracking-widest text-coral">{t({ es: 'Para Puerto Rico', en: 'For Puerto Rico' })}</p>
                      <p className="mt-2 text-paper/90">{t(c.prImpact)}</p>
                    </div>
                  </article>
                ))}
              </div>
            </section>
          ))}

          <section id="silencio" className="scroll-mt-40 border-2 border-ink bg-paper-deep p-8">
            <Eyebrow>{t({ es: 'Lo que la regla no dice', en: 'What the rule doesn’t say' })}</Eyebrow>
            <h2 className="mt-2 font-display text-3xl font-extrabold text-ink">{t({ es: 'Preguntas que la Oficina del Censo debe contestar', en: 'Questions the Census Bureau must answer' })}</h2>
            <ul className="mt-6 space-y-3 text-ink/90">
              {[
                { es: '¿Aplican las Partes 60 y 70 al conteo de Puerto Rico? ¿Cómo?', en: 'Do Parts 60 and 70 apply to the count in Puerto Rico? How?' },
                { es: '¿Qué “récords contributivos” se usarían para quienes rinden planilla solo ante Hacienda, o no rinden ninguna?', en: 'Which “tax records” would be used for people who file only with Hacienda, or don’t file at all?' },
                { es: '¿Se considera a Puerto Rico “fuera de los Estados Unidos” bajo la sección 60.5?', en: 'Is Puerto Rico “outside the United States” under Section 60.5?' },
                { es: '¿Cómo se ajustaría la Encuesta sobre la Comunidad de Puerto Rico sin datos de raza y origen del Censo?', en: 'How would the Puerto Rico Community Survey be weighted without Census race and origin data?' },
                { es: '¿Habrá audiencias públicas y materiales en español para Puerto Rico?', en: 'Will there be public hearings and Spanish-language materials for Puerto Rico?' },
              ].map((q) => (
                <li key={q.en} className="flex gap-3"><span className="font-display text-xl font-extrabold text-coral-deep">?</span><span>{t(q)}</span></li>
              ))}
            </ul>
            <Link to="/comenta" className="riso-shadow-ink mt-8 inline-block border-2 border-ink bg-coral px-6 py-3 font-display text-lg font-extrabold text-ink">
              {t({ es: 'Haz estas preguntas en tu comentario →', en: 'Ask these questions in your comment →' })}
            </Link>
          </section>
        </div>
      </div>
    </>
  )
}
