import { Link, createFileRoute } from '@tanstack/react-router'
import { Eyebrow, PageHero } from '@/components/ui'
import { DIASPORA_BLOCKS, HISPANIC_QUESTION, RACE_POINTS, RACE_SHIFT, SPD15 } from '@/content/diaspora'
import { LINKS } from '@/content/site'
import { useLang } from '@/lib/i18n'

export const Route = createFileRoute('/quienes-somos')({
  component: WhoWeArePage,
  head: () => ({ meta: [{ title: 'Raza y etnicidad: Parte 70 y la diáspora · Puerto Rico Cuenta' }] }),
})

// Chart series colors, validated for CVD separation and 3:1 contrast on paper.
const C2010 = '#5b78c7'
const C2020 = '#e0563c'

const fmt = (n: number) => (n >= 1_000_000 ? `${(n / 1_000_000).toFixed(2).replace(/0$/, '')}M` : `${Math.round(n / 1000)}K`)

function HispanicQuestion() {
  const q = HISPANIC_QUESTION
  return (
    <figure className="riso-shadow border-2 border-ink bg-white">
      <figcaption className="border-b-2 border-ink bg-paper-deep px-4 py-2 font-mono text-xs font-semibold uppercase tracking-wider text-ink">
        Censo 2020 · Pregunta 6 / 2020 Census · Question 6
      </figcaption>
      <div className="p-5" lang="en">
        <p className="text-sm font-semibold text-ink/80">→ {q.note}</p>
        <p className="mt-4 font-display text-xl font-extrabold text-ink"><span className="mr-2">6.</span>{q.question}</p>
        <ul className="mt-4 space-y-2.5">
          {q.options.map((o, i) => {
            const on = i === q.highlight
            return (
              <li key={o} className={`flex items-start gap-3 px-2 py-1 ${on ? 'bg-coral/25 outline outline-2 outline-ink' : ''}`}>
                <span className={`mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center border-2 border-ink font-bold leading-none ${on ? 'bg-ink text-paper' : 'bg-white'}`} aria-hidden="true">{on ? '✓' : ''}</span>
                <span className={on ? 'font-bold text-ink' : 'text-ink/85'}>{o}</span>
              </li>
            )
          })}
        </ul>
      </div>
    </figure>
  )
}

// Figure 1 of SPD 15, recreated in the site's style. Text stays in English, as on the federal form.
function CombinedQuestion() {
  const { t } = useLang()
  const f = SPD15
  const Box = ({ on = false }: { on?: boolean }) => (
    <span className={`mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center border-2 border-ink text-[10px] font-bold leading-none ${on ? 'bg-ink text-paper' : 'bg-white'}`} aria-hidden="true">
      {on ? '✓' : ''}
    </span>
  )
  return (
    <figure className="riso-shadow self-start border-2 border-ink bg-white">
      <figcaption className="flex flex-wrap items-baseline justify-between gap-2 border-b-2 border-ink bg-paper-deep px-4 py-2 font-mono text-xs font-semibold uppercase tracking-wider text-ink">
        <span>{t({ es: 'SPD 15 · Figura 1', en: 'SPD 15 · Figure 1' })}</span>
        <span className="normal-case tracking-normal text-ink/70">{t({ es: 'Pregunta combinada', en: 'Combined question' })}</span>
      </figcaption>
      <div className="p-5" lang="en">
        <p className="font-display text-xl font-extrabold text-ink">{f.question}</p>
        <p className="mt-1 text-sm text-ink/80">
          <span className="font-semibold underline">Select all that apply</span> {f.instruction}
        </p>
        <ul className="mt-5 space-y-5">
          {f.categories.map((c) => {
            const hot = c.name === f.highlight.category
            return (
              <li key={c.name} className={hot ? '-mx-2 bg-coral/15 px-2 py-2 outline outline-2 outline-ink' : ''}>
                <p className="flex items-start gap-2 text-sm">
                  <Box on={hot} />
                  <span>
                    <span className="font-bold text-ink">{c.name}</span>
                    <span className="italic text-ink/70"> – {c.details.length ? 'Provide details below.' : c.example}</span>
                  </span>
                </p>
                {c.details.length > 0 && (
                  <>
                    <ul className="mt-2 grid grid-cols-2 gap-x-3 gap-y-1 pl-6 text-sm sm:grid-cols-3">
                      {c.details.map((d) => {
                        const on = hot && d === f.highlight.detail
                        return (
                          <li key={d} className={`flex items-start gap-2 ${on ? 'font-bold text-ink' : 'text-ink/85'}`}>
                            <Box on={on} />
                            <span className={on ? 'bg-coral/40 px-0.5' : ''}>{d}</span>
                          </li>
                        )
                      })}
                    </ul>
                    <p className="mt-1 pl-6 text-xs italic text-ink/60">{c.example}</p>
                  </>
                )}
                <div className="ml-6 mt-1.5 h-7 rounded-sm border-2 border-ink/70 bg-white" aria-hidden="true" />
              </li>
            )
          })}
        </ul>
      </div>
      <div className="border-t-2 border-ink bg-coral px-4 py-3 font-display text-base font-extrabold text-ink">
        {t({ es: '§ 70.2: toda esta pregunta desaparecería del Censo decenal.', en: '§ 70.2: this entire question would disappear from the decennial census.' })}
      </div>
      <p className="border-t-2 border-ink px-4 py-3 text-xs text-ink/70">
        {t({
          es: 'Recreación de la Figura 1 de SPD 15 (OMB, 2024): pregunta de raza y etnicidad con categorías mínimas, casillas detalladas y espacios para escribir. Marcado como ejemplo: “Puerto Rican”.',
          en: 'Recreation of SPD 15 Figure 1 (OMB, 2024): race and ethnicity question with minimum categories, detailed checkboxes, and write-in areas. Marked as an example: “Puerto Rican.”',
        })}{' '}
        <a href={f.pageUrl} target="_blank" rel="noreferrer" className="underline decoration-coral underline-offset-4">{t({ es: 'Ver original', en: 'See original' })} ↗</a>
      </p>
    </figure>
  )
}

function RaceChart() {
  const { t } = useLang()
  const max = Math.max(...RACE_SHIFT.flatMap((r) => [r.y2010, r.y2020]))
  return (
    <figure className="border-2 border-ink bg-white p-5">
      <figcaption>
        <p className="font-display text-xl font-extrabold text-ink">
          {t({ es: 'Cómo se identificó Puerto Rico por raza, 2010 y 2020', en: 'How Puerto Rico identified by race, 2010 and 2020' })}
        </p>
        <p className="text-sm text-ink/70">{t({ es: 'Personas por categoría de raza, cifras redondeadas', en: 'People by race category, rounded' })}</p>
        <div className="mt-3 flex gap-5 text-sm text-ink">
          <span className="flex items-center gap-2"><span className="h-3 w-3 rounded-sm" style={{ background: C2010 }} aria-hidden="true" />2010</span>
          <span className="flex items-center gap-2"><span className="h-3 w-3 rounded-sm" style={{ background: C2020 }} aria-hidden="true" />2020</span>
        </div>
      </figcaption>
      <table className="mt-5 w-full border-separate border-spacing-y-3">
        <caption className="sr-only">{t({ es: 'Personas por categoría de raza en Puerto Rico, Censo 2010 y 2020', en: 'People by race category in Puerto Rico, 2010 and 2020 Census' })}</caption>
        <thead className="sr-only">
          <tr><th scope="col">{t({ es: 'Categoría', en: 'Category' })}</th><th scope="col">2010</th><th scope="col">2020</th></tr>
        </thead>
        <tbody>
          {RACE_SHIFT.map((r) => (
            <tr key={r.label.en}>
              <th scope="row" className="w-36 pr-3 text-left align-middle text-sm font-semibold text-ink sm:w-44">{t(r.label)}</th>
              <td className="sr-only">{fmt(r.y2010)}</td>
              <td className="sr-only">{fmt(r.y2020)}</td>
              <td aria-hidden="true" className="space-y-[2px]">
                {(
                  [
                    ['2010', r.y2010, C2010],
                    ['2020', r.y2020, C2020],
                  ] as const
                ).map(([y, v, c]) => (
                  <div key={y} className="flex items-center gap-2" title={`${t(r.label)} · ${y}: ${fmt(v)}`}>
                    <div className="h-4 rounded-r-[4px]" style={{ width: `${Math.max((v / max) * 80, 1)}%`, background: c }} />
                    <span className="font-mono text-xs tabular-nums text-ink/80">{fmt(v)}</span>
                  </div>
                ))}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <p className="mt-2 font-mono text-xs text-ink/60">
        {t({ es: 'Fuente: AP vía VOA (octubre de 2021), con cifras de los Censos 2010 y 2020.', en: 'Source: AP via VOA (October 2021), reporting 2010 and 2020 Census counts.' })}{' '}
        <a href={LINKS.raceVOA} target="_blank" rel="noreferrer" className="underline">↗</a>
      </p>
    </figure>
  )
}

function WhoWeArePage() {
  const { t } = useLang()
  return (
    <>
      <PageHero
        eyebrow={t({ es: 'Raza y etnicidad · Parte 70', en: 'Race and ethnicity · Part 70' })}
        title={t({ es: 'Sin el encasillado, el ser “Puertorriqueño” desaparece de los datos.', en: 'Without the checkbox, being “Puerto Rican” disappears from the data.' })}
        lede={t({
          es: 'La regla propuesta sugiere eliminar las preguntas de raza y origen hispano, donde aparece la casilla “Puerto Rican”. Sin ellas, perderíamos la capacidad de identificar estadísticamente a la diáspora completa, sobre todo a las generaciones nacidas en los estados.',
          en: 'The proposed rule would eliminate the race and Hispanic-origin questions, where the “Puerto Rican” box appears. Without them, we would lose the ability to statistically identify the whole diaspora, especially the generations born in the states.',
        })}
      />

      <section className="mx-auto grid max-w-7xl gap-12 px-5 py-16 lg:grid-cols-[1fr_1.1fr]">
        <div>
          <Eyebrow>{t({ es: 'Lo que se perdería', en: 'What would be lost' })}</Eyebrow>
          <h2 className="mt-3 font-display text-4xl font-extrabold text-ink">{t({ es: 'Una casilla que nos cuenta', en: 'One box that counts us' })}</h2>
          <p className="mt-4 text-lg text-ink/85">
            {t({
              es: 'La sección 70.2 prohibiría cualquier pregunta de raza o etnicidad en los cuestionarios usados para contar a la población. Esta es la pregunta que desaparecería. Es la herramienta principal para mantener visible a la comunidad puertorriqueña en las estadísticas oficiales de Estados Unidos.',
              en: 'Section 70.2 would ban any race or ethnicity question on questionnaires used to count the population. This is the question that would disappear. It is the main tool that keeps the Puerto Rican community visible in official U.S. statistics.',
            })}
          </p>
          <div className="mt-8 grid grid-cols-2 gap-px border-2 border-ink bg-ink">
            <div className="bg-ink p-5 text-paper">
              <p className="font-display text-4xl font-extrabold text-coral">5.8M+</p>
              <p className="mt-1 text-sm text-paper/85">{t({ es: 'puertorriqueños en los estados', en: 'Puerto Ricans in the states' })}</p>
            </div>
            <div className="bg-ink p-5 text-paper">
              <p className="font-display text-4xl font-extrabold text-coral">~1M</p>
              <p className="mt-1 text-sm text-paper/85">{t({ es: 'de ellos nacieron en Puerto Rico', en: 'of them were born in Puerto Rico' })}</p>
            </div>
          </div>
          <p className="mt-2 font-mono text-xs text-ink/60">{t({ es: 'Estimados de la Encuesta sobre la Comunidad (ACS), redondeados.', en: 'American Community Survey estimates, rounded.' })}</p>
        </div>
        <HispanicQuestion />
      </section>

      <section className="border-y-2 border-ink bg-paper-deep">
        <div className="mx-auto grid max-w-7xl gap-6 px-5 py-16 lg:grid-cols-3">
          {DIASPORA_BLOCKS.map((b, i) => (
            <article key={b.title.en} className="border-2 border-ink bg-paper p-6">
              <span className="font-display text-4xl font-extrabold text-coral">{i + 1}</span>
              <h3 className="mt-2 font-display text-xl font-extrabold text-ink">{t(b.title)}</h3>
              <ul className="mt-3 space-y-3">
                {b.points.map((p) => (
                  <li key={p.en} className="flex gap-2 text-ink/85">
                    <span className="mt-2 h-1.5 w-1.5 shrink-0 bg-ink" aria-hidden="true" />
                    <span>{t(p)}</span>
                  </li>
                ))}
              </ul>
            </article>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-5 py-16">
        <Eyebrow>{t({ es: 'El estándar federal: SPD 15', en: 'The federal standard: SPD 15' })}</Eyebrow>
        <h2 className="mt-3 max-w-4xl font-display text-4xl font-extrabold text-ink">
          {t({ es: 'El Censo iba a mejorar la pregunta, no a eliminarla', en: 'The Census was set to improve the question, not remove it' })}
        </h2>
        <div className="mt-8 grid gap-12 lg:grid-cols-[1fr_1.1fr]">
          <div className="space-y-4 text-lg text-ink/85">
            {SPD15.background.map((p) => (
              <p key={p.en}>{t(p)}</p>
            ))}
            <div className="border-2 border-ink bg-paper-deep p-5 text-base">
              <p className="font-mono text-xs font-semibold uppercase tracking-widest text-coral-deep">{t({ es: 'Cómo se ve en un formulario', en: 'How it looks on a form' })}</p>
              <ul className="mt-3 space-y-3">
                {SPD15.howItLooks.map((p) => (
                  <li key={p.en} className="flex gap-3 text-ink/90">
                    <span className="mt-2 h-2 w-2 shrink-0 bg-coral" aria-hidden="true" />
                    <span>{t(p)}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div className="riso-shadow border-2 border-ink bg-ink p-5 text-base text-paper">
              <p className="font-display text-2xl font-extrabold text-coral">{t(SPD15.atRisk.title)}</p>
              <p className="mt-2 text-paper/90">{t(SPD15.atRisk.body)}</p>
            </div>
          </div>
          <CombinedQuestion />
        </div>
      </section>

      <section className="mx-auto grid max-w-7xl gap-12 border-t-2 border-ink px-5 py-16 lg:grid-cols-[1fr_1.1fr]">
        <div>
          <Eyebrow>{t({ es: 'Y en Puerto Rico', en: 'And in Puerto Rico' })}</Eyebrow>
          <h2 className="mt-3 font-display text-4xl font-extrabold text-ink">{t({ es: 'Nuestra única medida completa de quiénes somos', en: 'Our only full measure of who we are' })}</h2>
          <ul className="mt-6 space-y-4">
            {RACE_POINTS.map((p) => (
              <li key={p.en} className="text-lg text-ink/85">{t(p)}</li>
            ))}
          </ul>
          <Link to="/comenta" className="riso-shadow-ink mt-8 inline-block border-2 border-ink bg-coral px-6 py-3 font-display text-lg font-extrabold text-ink">
            {t({ es: 'Pide que se mantenga la pregunta →', en: 'Ask them to keep the question →' })}
          </Link>
        </div>
        <RaceChart />
      </section>
    </>
  )
}
