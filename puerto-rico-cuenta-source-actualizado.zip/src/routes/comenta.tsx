import { createFileRoute } from '@tanstack/react-router'
import { CommentBuilder } from '@/components/CommentBuilder'
import { PledgeForm } from '@/components/PledgeForm'
import { TrackerNumbers, TrackerProvider } from '@/components/Tracker'
import { Eyebrow, PageHero } from '@/components/ui'
import { LINKS, RULE } from '@/content/site'
import { useLang } from '@/lib/i18n'

export const Route = createFileRoute('/comenta')({
  component: CommentPage,
  head: () => ({ meta: [{ title: 'Escribe tu comentario · Puerto Rico Cuenta' }] }),
})

function CommentPage() {
  const { t } = useLang()
  const steps = [
    { es: `Abre la regla en Regulations.gov (expediente ${RULE.regsDocket}) y pulsa “Comment”.`, en: `Open the rule on Regulations.gov (docket ${RULE.regsDocket}) and click “Comment.”` },
    { es: 'Pega tu borrador en el cuadro de texto o adjúntalo como archivo.', en: 'Paste your draft into the text box or attach it as a file.' },
    { es: 'Llena los campos requeridos. Para comentar de forma anónima, escribe “N/A”.', en: 'Fill in the required fields. To stay anonymous, enter “N/A.”' },
    { es: 'Envía y guarda tu número de confirmación (tracking number).', en: 'Submit and save your tracking number.' },
  ]
  return (
    <TrackerProvider>
      <PageHero
        eyebrow={t({ es: 'Generador de comentarios', en: 'Comment builder' })}
        title={t({ es: 'Tu comentario, en 15 minutos.', en: 'Your comment, in 15 minutes.' })}
        lede={t({
          es: 'Escoge lo que te preocupa, añade tu historia y genera un comentario formal en inglés, en español o en ambos. Luego lo pegas en Regulations.gov. Nada de lo que escribas aquí se guarda ni se envía.',
          en: 'Pick what concerns you, add your story, and generate a formal comment in English, Spanish, or both. Then paste it on Regulations.gov. Nothing you type here is saved or sent.',
        })}
      />
      <section className="mx-auto max-w-7xl px-5 py-16">
        <CommentBuilder />
      </section>

      <section className="border-y-2 border-ink bg-ink text-paper">
        <div className="mx-auto grid max-w-7xl gap-10 px-5 py-16 md:grid-cols-[1fr_1.5fr]">
          <div>
            <Eyebrow light>{t({ es: 'Cómo enviarlo', en: 'How to submit' })}</Eyebrow>
            <h2 className="mt-3 font-display text-4xl font-extrabold">{t({ es: 'Cuatro pasos en Regulations.gov', en: 'Four steps on Regulations.gov' })}</h2>
            <p className="mt-4 text-paper/80">
              {t({ es: '¿Prefieres correo postal? Envíalo a:', en: 'Prefer postal mail? Send it to:' })}
              <span className="mt-2 block font-mono text-sm text-paper">{RULE.mailAddress}</span>
            </p>
          </div>
          <ol className="space-y-4">
            {steps.map((s, i) => (
              <li key={s.en} className="flex gap-4 border-b border-paper/20 pb-4">
                <span className="font-display text-4xl font-extrabold text-coral">{i + 1}</span>
                <span className="pt-2 text-lg">{t(s)}</span>
              </li>
            ))}
            <li>
              <a href={LINKS.commentNow} target="_blank" rel="noreferrer" className="inline-block border-2 border-paper bg-coral px-6 py-3 font-display text-lg font-extrabold text-ink">
                {t({ es: 'Abrir Regulations.gov ↗', en: 'Open Regulations.gov ↗' })}
              </a>
            </li>
          </ol>
        </div>
      </section>

      <section className="mx-auto grid max-w-7xl gap-12 px-5 py-16 lg:grid-cols-2">
        <div>
          <Eyebrow>{t({ es: '¿Ya lo enviaste?', en: 'Already submitted?' })}</Eyebrow>
          <h2 className="mt-3 font-display text-4xl font-extrabold text-ink">{t({ es: 'Pon tu municipio en el mapa.', en: 'Put your municipio on the map.' })}</h2>
          <p className="mt-4 text-lg text-ink/85">
            {t({
              es: 'Regístrate en el contador para que se vea que Puerto Rico participó. Solo publicamos totales.',
              en: 'Sign the tracker so everyone can see Puerto Rico took part. We only publish totals.',
            })}
          </p>
          <div className="mt-8"><TrackerNumbers /></div>
        </div>
        <PledgeForm defaultStatus="commented" />
      </section>
    </TrackerProvider>
  )
}
