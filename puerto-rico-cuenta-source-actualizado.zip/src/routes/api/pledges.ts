import { createFileRoute } from '@tanstack/react-router'
import { count, desc, eq, sql } from 'drizzle-orm'
import { z } from 'zod'
import { db } from '../../../db/index.js'
import { pledges } from '../../../db/schema.js'
import { PLACES } from '@/content/municipios'

const PledgeInput = z.object({
  name: z.string().trim().max(120).optional(),
  email: z.union([z.literal(''), z.email().max(200)]).optional(),
  place: z.string().refine((p) => PLACES.has(p), 'Unknown place'),
  role: z.enum(['resident', 'diaspora', 'data', 'org', 'business', 'official', 'other']),
  status: z.enum(['pledged', 'commented']),
  language: z.enum(['es', 'en']).default('es'),
  contactOk: z.boolean().default(false),
  // Honeypot: real visitors never fill this hidden field.
  website: z.string().max(0).optional(),
})

export type TrackerStats = {
  total: number
  commented: number
  municipiosReached: number
  diaspora: number
  byPlace: { place: string; total: number }[]
}

// Public view is aggregate-only: no names or emails ever leave the database.
async function getStats(): Promise<TrackerStats> {
  const [totals] = await db
    .select({
      total: count(),
      commented: sql<number>`count(*) filter (where ${pledges.status} = 'commented')`.mapWith(Number),
      diaspora: sql<number>`count(*) filter (where ${pledges.place} like 'diaspora:%')`.mapWith(Number),
    })
    .from(pledges)

  const byPlace = await db
    .select({ place: pledges.place, total: count() })
    .from(pledges)
    .groupBy(pledges.place)
    .orderBy(desc(count()))

  return {
    total: totals?.total ?? 0,
    commented: totals?.commented ?? 0,
    diaspora: totals?.diaspora ?? 0,
    municipiosReached: byPlace.filter((p) => !p.place.startsWith('diaspora:')).length,
    byPlace,
  }
}

export const Route = createFileRoute('/api/pledges')({
  server: {
    handlers: {
      GET: async () => {
        const stats = await getStats()
        return Response.json(stats, { headers: { 'Cache-Control': 'public, max-age=30' } })
      },
      POST: async ({ request }) => {
        let body: unknown
        try {
          body = await request.json()
        } catch {
          return Response.json({ error: 'Invalid JSON' }, { status: 400 })
        }
        const parsed = PledgeInput.safeParse(body)
        if (!parsed.success) {
          return Response.json({ error: 'Invalid submission' }, { status: 400 })
        }
        const { website, email, name, ...rest } = parsed.data
        void website

        // One row per email: a repeat sign-up (e.g. "pledged" → "commented")
        // updates the earlier entry instead of counting the person twice.
        if (email) {
          const [existing] = await db
            .select({ id: pledges.id })
            .from(pledges)
            .where(eq(pledges.email, email.toLowerCase()))
            .limit(1)
          if (existing) {
            await db.update(pledges).set({ ...rest, name: name || null }).where(eq(pledges.id, existing.id))
            return Response.json(await getStats())
          }
        }

        await db.insert(pledges).values({
          ...rest,
          name: name || null,
          email: email ? email.toLowerCase() : null,
        })
        return Response.json(await getStats(), { status: 201 })
      },
    },
  },
})
