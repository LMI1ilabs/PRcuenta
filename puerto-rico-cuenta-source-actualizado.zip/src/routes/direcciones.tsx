import { Link, createFileRoute } from '@tanstack/react-router'
import { Eyebrow, PageHero } from '@/components/ui'
import { ADDRESS_ASKS, ADDRESS_CHAIN, ADDRESS_ISSUES, ADDRESS_SOURCES, CITY_STYLE } from '@/content/addresses'
import { ADDRESS_STATS } from '@/content/impact'
import { useLang } from '@/lib/i18n'

export const Route = createFileRoute('/direcciones')({
  component: AddressesPage,
  head: () => ({ meta: [{ title: 'Direcciones · Puerto Rico Cuenta' }] }),
})

function SectionHead({ eyebrow, title }: { eyebrow: string; title: string }) {
  return (
    <div className="border-b-2 border-ink pb-4">
      <Eyebrow>{eyebrow}</Eyebrow>
      <h2 className="mt-2 font-display text-3xl font-extrabold text-ink md:text-4xl">{title}</h2>
    </div>
  )
}

function AddressesPage() {
  const { t } = useLang()
  return (
    <>
      <PageHero
        eyebrow={t({ es: 'Direcciones', en: 'Addresses' })}
        title={t({ es: 'Un sistema que no te ubica, no te cuenta.', en: 'A system that can’t locate you can’t count you.' })}
        lede={t({
          es: 'Se estima que más de la mitad de las viviendas en Puerto Rico no tienen nombre de calle o número de casa (una dirección “city-style”). Si la regla usa récords contributivos para verificar dónde vives, hacen falta métodos de validación adaptados a cómo son las direcciones aquí. Sin eso, muchos residentes y ciudadanos estadounidenses en Puerto Rico podrían quedar fuera del conteo.',
          en: 'It has been estimated that over half of Puerto Rico’s housing units lack a street name or house number (a “city-style” address). If the rule uses tax records to verify where you live, it needs address validation methods adapted to how addresses work here. Without them, many residents and U.S. citizens in Puerto Rico could be left out of the count.',
        })}
      />

      <div className="mx-auto max-w-7xl space-y-20 px-5 py-16">
        {/* Stats */}
        <section>
          <dl className="grid gap-px border-2 border-ink bg-ink sm:grid-cols-2 lg:grid-cols-4">
            {ADDRESS_STATS.map((s) => (
              <div key={s.v} className="bg-ink p-6 text-paper">
                <dt className="sr-only">{t(s.l)}</dt>
                <dd className="font-display text-5xl font-extrabold tabular-nums text-coral">{s.v}</dd>
                <dd className="mt-2 text-paper/85">{t(s.l)}</dd>
              </div>
            ))}
          </dl>
          <p className="mt-3 font-mono text-xs text-ink/70">
            {t({
              es: 'Fuente: estudio de la Initiative for Civic Address Systems Assessment in Puerto Rico (iCasaPR), la única organización sin fines de lucro de Puerto Rico dedicada a la infraestructura de direcciones.',
              en: 'Source: study by the Initiative for Civic Address Systems Assessment in Puerto Rico (iCasaPR), Puerto Rico’s only nonprofit focused on address infrastructure.',
            })}
          </p>
        </section>

        {/* Issues */}
        <section>
          <SectionHead eyebrow={t({ es: 'Lo que hay que considerar', en: 'What has to be considered' })} title={t({ es: 'Por qué nuestras direcciones no cuadran', en: 'Why our addresses don’t match' })} />
          <div className="mt-8 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {ADDRESS_ISSUES.map((p) => (
              <article key={p.title.en} className="border-2 border-ink bg-paper p-6">
                <h3 className="font-display text-xl font-extrabold text-ink">{t(p.title)}</h3>
                <p className="mt-2 text-ink/85">{t(p.body)}</p>
              </article>
            ))}
          </div>
          <div className="riso-shadow mt-8 border-2 border-ink bg-ink p-6 text-paper md:p-8">
            <p className="font-display text-2xl font-extrabold text-coral md:text-3xl">{t({ es: 'Un PO Box no es una dirección para propósitos del Censo.', en: 'A P.O. box is not an address for Census purposes.' })}</p>
            <p className="mt-3 text-paper/90">
              {t({
                es: 'La Oficina del Censo no acepta apartados postales (PO Box), rutas rurales (RR) ni “highway contracts” (HC) como direcciones residenciales.',
                en: 'The Census Bureau does not accept P.O. boxes, rural routes (RR), or highway contract (HC) box designations as residential addresses.',
              })}
            </p>
            <div className="mt-6 grid gap-6 md:grid-cols-2">
              {[
                {
                  h: { es: 'Por qué', en: 'Why' },
                  items: [
                    {
                      es: 'El Censo cuenta a la gente donde vive. Cada persona tiene que quedar ubicada en un punto del mapa (un bloque censal) para repartir representación, dibujar distritos y distribuir fondos.',
                      en: 'The Census counts people where they live. Each person has to be tied to a point on the map (a census block) to apportion representation, draw districts, and distribute funds.',
                    },
                    {
                      es: 'Un PO Box solo identifica un buzón dentro del correo, no una casa.',
                      en: 'A P.O. box only identifies a mailbox inside a post office, not a home.',
                    },
                  ],
                },
                {
                  h: { es: 'Cómo afecta a Puerto Rico', en: 'How it affects Puerto Rico' },
                  items: [
                    {
                      es: 'Se estima que entre el 40% y el 60% de las direcciones en Puerto Rico son PO Box, Ruta Rural (RR) o Highway Contract (HC), no una dirección “city-style” (calle y número).',
                      en: 'An estimated 40% to 60% of addresses in Puerto Rico are P.O. boxes, Rural Routes (RR), or Highway Contract (HC) routes, not a “city-style” street-and-number address.',
                    },
                    {
                      es: 'Si la regla verifica residencia con récords como las planillas de Hacienda, y la planilla tiene un PO Box, el sistema no puede ubicar ese récord en el mapa.',
                      en: 'If the rule verifies residence with records like Hacienda tax returns, and the return lists a P.O. box, the system can’t place that record on the map.',
                    },
                    {
                      es: 'Sin procesos de validación adaptados a Puerto Rico, más de un millón de residentes podrían quedar sin validación de sus direcciones para el conteo decenal.',
                      en: 'Without validation processes adapted to Puerto Rico, more than a million residents could be left without their addresses validated for the decennial count.',
                    },
                  ],
                },
              ].map((col) => (
                <div key={col.h.en}>
                  <p className="font-mono text-xs font-semibold uppercase tracking-widest text-coral">{t(col.h)}</p>
                  <ul className="mt-3 space-y-3">
                    {col.items.map((it) => (
                      <li key={it.en} className="flex gap-3 text-paper/90">
                        <span className="mt-2 h-2 w-2 shrink-0 bg-coral" aria-hidden="true" />
                        <span>{t(it)}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* City-style */}
        <section>
          <SectionHead eyebrow={t({ es: 'El estándar federal', en: 'The federal standard' })} title={t({ es: '¿Qué es una dirección “city-style”?', en: 'What is a “city-style” address?' })} />
          <div className="mt-8 grid gap-6 md:grid-cols-2">
            {CITY_STYLE.map((c, i) => (
              <article key={c.title.en} className={`border-2 border-ink p-6 ${i === 0 ? 'bg-paper' : 'riso-shadow bg-ink text-paper'}`}>
                <h3 className={`font-display text-xl font-extrabold ${i === 0 ? 'text-ink' : 'text-coral'}`}>{t(c.title)}</h3>
                <p className={`mt-2 ${i === 0 ? 'text-ink/85' : 'text-paper/90'}`}>{t(c.body)}</p>
              </article>
            ))}
          </div>
        </section>

        {/* From tax return to address */}
        <section>
          <SectionHead eyebrow={t({ es: 'De la planilla a la dirección', en: 'From tax return to address' })} title={t({ es: 'Aun con las planillas de Hacienda, el problema sigue', en: 'Even with Hacienda returns, the problem remains' })} />
          <ol className="mt-8 grid gap-6 md:grid-cols-2 lg:grid-cols-4">
            {ADDRESS_CHAIN.map((p, i) => (
              <li key={p.title.en} className="border-2 border-ink bg-paper p-6">
                <span className="font-display text-4xl font-extrabold text-coral">{String(i + 1).padStart(2, '0')}</span>
                <h3 className="mt-2 font-display text-xl font-extrabold text-ink">{t(p.title)}</h3>
                <p className="mt-2 text-ink/85">{t(p.body)}</p>
              </li>
            ))}
          </ol>
        </section>


        {/* Asks */}
        <section className="border-2 border-ink bg-paper-deep p-8">
          <Eyebrow>{t({ es: 'Qué pedir en tu comentario', en: 'What to ask for in your comment' })}</Eyebrow>
          <h2 className="mt-2 font-display text-3xl font-extrabold text-ink">{t({ es: 'Lo que pedimos sobre las direcciones', en: 'What we ask about addresses' })}</h2>
          <ol className="mt-6 grid gap-4 md:grid-cols-2">
            {ADDRESS_ASKS.map((a, i) => (
              <li key={a.en} className="flex gap-3 border-2 border-ink bg-paper p-4">
                <span className="font-display text-2xl font-extrabold text-coral-deep">{i + 1}</span>
                <span className="text-ink/90">{t(a)}</span>
              </li>
            ))}
          </ol>
          <Link to="/comenta" className="riso-shadow-ink mt-8 inline-block border-2 border-ink bg-coral px-6 py-3 font-display text-lg font-extrabold text-ink">
            {t({ es: 'Escribe tu comentario →', en: 'Write your comment →' })}
          </Link>
        </section>

        <section>
          <p className="font-mono text-xs uppercase tracking-widest text-ink/60">{t({ es: 'Fuentes', en: 'Sources' })}</p>
          <ul className="mt-4 grid gap-2 text-sm md:grid-cols-2">
            {ADDRESS_SOURCES.map((s) => (
              <li key={s.label} className="text-ink/85">
                {s.href ? (
                  <a href={s.href} target="_blank" rel="noreferrer" className="underline decoration-coral underline-offset-4 hover:text-coral-deep">{s.label} ↗</a>
                ) : (
                  s.label
                )}
              </li>
            ))}
          </ul>
        </section>
      </div>
    </>
  )
}
