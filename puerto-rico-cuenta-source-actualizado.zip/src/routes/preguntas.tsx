import { Link, createFileRoute } from '@tanstack/react-router'
import { ContactForm } from '@/components/ContactForm'
import { Eyebrow, PageHero } from '@/components/ui'
import { FAQ } from '@/content/faq'
import { useLang } from '@/lib/i18n'

export const Route = createFileRoute('/preguntas')({
  component: FaqPage,
  head: () => ({ meta: [{ title: 'Preguntas frecuentes · Puerto Rico Cuenta' }] }),
})

function FaqPage() {
  const { t } = useLang()
  return (
    <>
      <PageHero
        eyebrow={t({ es: 'Preguntas frecuentes', en: 'Frequently asked questions' })}
        title={t({ es: 'Respuestas claras, sin jerga.', en: 'Clear answers, no jargon.' })}
        lede={t({ es: 'Lo básico sobre la regla propuesta, el proceso de comentarios y por qué importa para Puerto Rico.', en: 'The basics on the proposed rule, the comment process, and why it matters for Puerto Rico.' })}
      />
      <section className="mx-auto max-w-4xl px-5 py-16">
        <div className="divide-y-2 divide-ink border-y-2 border-ink">
          {FAQ.map((f, i) => (
            <details key={f.q.en} className="group py-6" open={i === 0}>
              <summary className="flex cursor-pointer list-none items-start justify-between gap-4 font-display text-2xl font-bold text-ink">
                {t(f.q)}
                <span className="mt-1 text-coral transition-transform group-open:rotate-45">+</span>
              </summary>
              <p className="mt-4 text-lg leading-relaxed text-ink/85">{t(f.a)}</p>
            </details>
          ))}
        </div>
        <div id="contacto" className="mt-16 scroll-mt-40">
          <Eyebrow>{t({ es: 'Contáctanos', en: 'Contact us' })}</Eyebrow>
          <h2 className="mt-3 font-display text-3xl font-extrabold text-ink">{t({ es: '¿Tienes más preguntas?', en: 'Have more questions?' })}</h2>
          <p className="mt-3 text-lg text-ink/85">
            {t({
              es: 'Envíanos un mensaje y sugiere qué otros temas importantes debemos abordar.',
              en: 'Send us a message and suggest other important topics we should cover.',
            })}
          </p>
          <div className="mt-6"><ContactForm /></div>
        </div>
        <div className="mt-12 flex flex-wrap gap-4">
          <Link to="/comenta" className="riso-shadow-ink border-2 border-ink bg-coral px-6 py-3 font-display text-lg font-extrabold text-ink">{t({ es: 'Escribe tu comentario', en: 'Write your comment' })}</Link>
          <Link to="/la-regla" className="border-2 border-ink px-6 py-3 font-display text-lg font-bold text-ink hover:bg-paper-deep">{t({ es: 'Lee la regla', en: 'Read the rule' })}</Link>
        </div>
      </section>
    </>
  )
}
