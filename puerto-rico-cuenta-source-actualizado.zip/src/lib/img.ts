// Serve generated artwork through the Netlify Image CDN instead of the full-size originals.
export const cdn = (file: string, w: number) => `/.netlify/images?url=/img/${file}&w=${w}&fm=webp&q=80`
