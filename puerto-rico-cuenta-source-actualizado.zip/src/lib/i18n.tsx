import { createContext, useContext, useEffect, useState } from 'react'

export type Lang = 'es' | 'en'
/** A piece of copy in both campaign languages. */
export type L = { es: string; en: string }

type Ctx = { lang: Lang; setLang: (l: Lang) => void; t: (copy: L) => string }

const LangContext = createContext<Ctx>({
  lang: 'es',
  setLang: () => {},
  t: (c) => c.es,
})

const STORAGE_KEY = 'prcuenta-lang'

// Spanish is the default (and what the server renders); the visitor's choice
// is restored from localStorage after hydration.
export function LangProvider({ children }: { children: React.ReactNode }) {
  const [lang, setLangState] = useState<Lang>('es')

  useEffect(() => {
    const saved = window.localStorage.getItem(STORAGE_KEY)
    if (saved === 'es' || saved === 'en') setLangState(saved)
  }, [])

  useEffect(() => {
    document.documentElement.lang = lang
  }, [lang])

  const setLang = (l: Lang) => {
    setLangState(l)
    window.localStorage.setItem(STORAGE_KEY, l)
  }

  return (
    <LangContext.Provider value={{ lang, setLang, t: (c) => c[lang] }}>
      {children}
    </LangContext.Provider>
  )
}

export const useLang = () => useContext(LangContext)
