CREATE TABLE "pledges" (
	"id" serial PRIMARY KEY,
	"name" text,
	"email" text,
	"place" text NOT NULL,
	"role" text NOT NULL,
	"status" text NOT NULL,
	"language" text DEFAULT 'es' NOT NULL,
	"contact_ok" boolean DEFAULT false NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE INDEX "pledges_place_idx" ON "pledges" ("place");