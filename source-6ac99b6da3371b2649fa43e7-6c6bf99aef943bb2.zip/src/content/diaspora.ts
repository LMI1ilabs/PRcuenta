import type { L } from '@/lib/i18n'

// Copy for /quienes-somos: what Part 70 would mean for identifying Puerto Ricans,
// in the states and in Puerto Rico.

// The 2020 Census Hispanic-origin question (Question 6), as printed on the form.
export const HISPANIC_QUESTION = {
  note: 'NOTE: Please answer BOTH Question 6 about Hispanic origin and Question 7 about race. For this census, Hispanic origins are not races.',
  question: 'Is this person of Hispanic, Latino, or Spanish origin?',
  options: [
    'No, not of Hispanic, Latino, or Spanish origin',
    'Yes, Mexican, Mexican Am., Chicano',
    'Yes, Puerto Rican',
    'Yes, Cuban',
    'Yes, another Hispanic, Latino, or Spanish origin',
  ],
  highlight: 2,
}

export const DIASPORA_BLOCKS: { title: L; points: L[] }[] = [
  {
    title: { es: '¿Qué información sí quedaría?', en: 'What information would remain?' },
    points: [
      {
        es: 'Solo se podría rastrear a la primera generación, las personas nacidas en Puerto Rico que se mudaron a los estados, mediante la pregunta de lugar de nacimiento. Esa pregunta está en encuestas como la ACS, no en el cuestionario corto del Censo decenal.',
        en: 'Only the first generation, people born in Puerto Rico who moved to the states, could be tracked, through the place-of-birth question. That question is on surveys like the ACS, not on the decennial short form.',
      },
      {
        es: 'Se invisibilizaría a la segunda, tercera y futuras generaciones. Un hijo o nieto de puertorriqueños nacido en Orlando o Filadelfia aparecería simplemente como nacido en “Florida” o “Pennsylvania”, sin nada que identifique su origen boricua.',
        en: 'The second, third, and later generations would become invisible. A child or grandchild of Puerto Ricans born in Orlando or Philadelphia would simply appear as born in “Florida” or “Pennsylvania,” with nothing to identify their Puerto Rican origin.',
      },
    ],
  },
  {
    title: { es: '¿Qué pasaría con los datos de la diáspora?', en: 'What would happen to diaspora data?' },
    points: [
      {
        es: 'Pérdida drástica en las cifras: la mayoría de los más de 5.8 millones de puertorriqueños en los estados nació allá. Sin la pregunta de origen, la cifra oficial caería artificialmente a poco más del millón que nació en Puerto Rico.',
        en: 'A drastic drop in the numbers: most of the more than 5.8 million Puerto Ricans in the states were born there. Without the origin question, the official figure would fall artificially to the little over one million born in Puerto Rico.',
      },
      {
        es: 'Derechos civiles y electorales: el gobierno federal y las organizaciones comunitarias usan estos datos bajo la Ley de Derecho al Voto (Voting Rights Act) para asegurar representación justa en la redistribución de distritos.',
        en: 'Civil and voting rights: the federal government and community organizations use these data under the Voting Rights Act to secure fair representation in redistricting.',
      },
      {
        es: 'Fondos y servicios: condados y ciudades usan los datos demográficos para justificar presupuestos de educación bilingüe, programas de salud comunitaria y servicios para la población hispana y puertorriqueña local.',
        en: 'Funds and services: counties and cities use demographic data to justify budgets for bilingual education, community health programs, and services for local Hispanic and Puerto Rican populations.',
      },
    ],
  },
  {
    title: { es: 'Métodos alternativos, e imperfectos', en: 'Alternative, and imperfect, methods' },
    points: [
      {
        es: 'Análisis de apellidos: algoritmos que identifican apellidos hispanos, pero no distinguen nacionalidades. Un Rodríguez puede ser boricua, dominicano o mexicano.',
        en: 'Surname analysis: algorithms that flag Hispanic surnames but can’t tell nationalities apart. A Rodríguez could be Puerto Rican, Dominican, or Mexican.',
      },
      {
        es: 'Datos administrativos cruzados: récords escolares, licencias de conducir o cambios de dirección del correo (USPS). Ninguno registra la identidad étnica.',
        en: 'Linked administrative data: school records, driver’s licenses, or USPS change-of-address files. None of them record ethnic identity.',
      },
      {
        es: 'Encuestas privadas e independientes: estudios de universidades, como el Centro de Estudios Puertorriqueños de CUNY, o de firmas como Pew Research Center, con muestras mucho más pequeñas y sin el alcance obligatorio del Censo.',
        en: 'Private and independent surveys: studies by universities, such as CUNY’s Center for Puerto Rican Studies, or firms like Pew Research Center, with much smaller samples and without the Census’s mandatory reach.',
      },
    ],
  },
]

// People by race category in Puerto Rico, 2010 vs 2020 Census (rounded), as reported by AP via VOA (Oct. 2021).
export const RACE_SHIFT: { label: L; y2010: number; y2020: number }[] = [
  { label: { es: 'Blanca sola', en: 'White alone' }, y2010: 2_800_000, y2020: 561_000 },
  { label: { es: 'Dos o más razas', en: 'Two or more races' }, y2010: 122_000, y2020: 1_600_000 },
  { label: { es: 'Alguna otra raza sola', en: 'Some other race alone' }, y2010: 290_000, y2020: 838_000 },
  { label: { es: 'Negra sola', en: 'Black alone' }, y2010: 461_000, y2020: 229_000 },
]

export const RACE_POINTS: L[] = [
  {
    es: 'La pregunta de raza no se hizo en el censo de Puerto Rico de 1960 a 1990 y regresó en 2000 con categorías que muchos criticaron por no reflejar el contexto local. Entre 2010 y 2020 las respuestas cambiaron mucho, en parte por cambios en la redacción y la codificación de la pregunta.',
    en: 'The race question was left off Puerto Rico’s census from 1960 to 1990 and returned in 2000 with categories many said didn’t fit the local context. Between 2010 and 2020 the answers shifted sharply, partly because of changes in question wording and coding.',
  },
  {
    es: 'Ese cambio, y la visibilidad de la identidad afropuertorriqueña, son hallazgos importantes. Investigadores de salud, agencias de derechos civiles y grupos comunitarios los usan para estudiar desigualdades por color y ascendencia en una población que es cerca de 99% hispana.',
    en: 'That shift, and the visibility of Afro-Puerto Rican identity, are important findings. Health researchers, civil-rights agencies, and community groups use them to study disparities by color and ancestry in a population that is about 99% Hispanic.',
  },
  {
    es: 'Sin la pregunta en el Censo, no habría un punto de referencia para todo Puerto Rico con el cual comparar 2030, ni una serie consistente. El propio análisis de impacto de la Oficina reconoce que no existe un reemplazo igual de preciso y completo.',
    en: 'Without the question on the Census, there would be no island-wide benchmark to compare 2030 against, and no consistent series at all. The Bureau’s own impact analysis acknowledges there is no comparably accurate, comprehensive replacement.',
  },
]
