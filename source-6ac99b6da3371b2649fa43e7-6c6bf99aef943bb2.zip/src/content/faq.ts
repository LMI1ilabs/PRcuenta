import type { L } from '@/lib/i18n'

export const FAQ: { q: L; a: L }[] = [
  {
    q: { es: '¿Qué son las Partes 60 y 70?', en: 'What are Parts 60 and 70?' },
    a: {
      es: 'Son dos partes nuevas que la Oficina del Censo propone añadir al Título 15 del Código de Regulaciones Federales (15 CFR). La Parte 60 fija los criterios de residencia: a quién se cuenta y dónde. La Parte 70 restringe las preguntas demográficas del Censo decenal y prohíbe preguntar raza, etnicidad u orientación sexual. Hasta ahora, estos criterios se fijaban antes de cada censo y no se convertían en regulación permanente.',
      en: 'They are two new parts the Census Bureau proposes to add to Title 15 of the Code of Federal Regulations (15 CFR). Part 60 sets residence criteria: who is counted and where. Part 70 restricts demographic questions on the decennial census and bans questions on race, ethnicity, and sexual orientation. Until now, these criteria were set before each census and were not made into permanent regulation.',
    },
  },
  {
    q: { es: '¿Cuándo vence el periodo de comentarios?', en: 'When is the comment deadline?' },
    a: {
      es: 'El 2 de noviembre de 2026 a las 11:59 p.m. (hora del Este). La fecha original era el 13 de octubre; la Oficina del Censo la extendió el 5 de octubre de 2026.',
      en: 'November 2, 2026 at 11:59 p.m. Eastern. The original deadline was October 13; the Census Bureau extended it on October 5, 2026.',
    },
  },
  {
    q: { es: 'Puerto Rico no tiene representación con voto en el Congreso. ¿Por qué nos afecta?', en: 'Puerto Rico has no voting seat in Congress. Why does this affect us?' },
    a: {
      es: 'El Censo hace mucho más que repartir escaños en la Cámara. Sus datos se usan para redibujar los distritos senatoriales y representativos de Puerto Rico, distribuir fondos federales, ajustar la Encuesta sobre la Comunidad de Puerto Rico y planificar escuelas, hospitales y la respuesta a desastres. La Parte 70 aplicaría a cualquier cuestionario usado para contar a la población, y, a menos que se aclare lo contrario, eso incluiría el de Puerto Rico. Y la diáspora, que vive en los estados, sí cuenta para la distribución de escaños.',
      en: 'The Census does far more than apportion House seats. Its data are used to redraw Puerto Rico’s senate and house districts, distribute federal funds, weight the Puerto Rico Community Survey, and plan schools, hospitals, and disaster response. Part 70 would apply to any questionnaire used to enumerate the population, which, absent clarification, would include Puerto Rico’s. And the diaspora, living in the states, is counted for apportionment.',
    },
  },
  {
    q: { es: '¿Puedo comentar en español?', en: 'Can I comment in Spanish?' },
    a: {
      es: 'La regla no exige un idioma, y cualquier persona puede comentar, sin importar su ciudadanía ni dónde viva. Para que el personal federal lo lea sin traducción, recomendamos comentar en inglés o en ambos idiomas. Nuestro generador de comentarios produce la versión que prefieras.',
      en: 'The rule sets no language requirement, and anyone can comment regardless of citizenship or where they live. So federal staff can read it without translation, we recommend commenting in English or in both languages. Our comment builder produces whichever version you prefer.',
    },
  },
  {
    q: { es: '¿Cómo afecta esto los distritos electorales de Puerto Rico?', en: 'How does this affect Puerto Rico’s electoral districts?' },
    a: {
      es: 'La Constitución de Puerto Rico (Artículo III, Sección 4) exige revisar los distritos después de cada censo decenal. La población que reporta el Censo se divide entre los 40 distritos representativos y los 8 senatoriales para fijar la población ideal de cada uno, y las fronteras se ajustan con datos por bloque censal y barrio. Si la regla deja fuera hogares cuyos récords no cuadran, o los ubica en su dirección postal y no donde viven, los mapas que salgan de ese conteo también estarían equivocados.',
      en: 'Puerto Rico’s Constitution (Article III, Section 4) requires districts to be revised after each decennial census. The population the Census reports is divided among the 40 house and 8 senate districts to set each one’s ideal population, and boundaries are adjusted with census block and barrio data. If the rule drops households whose records don’t match, or places them at a mailing address instead of where they live, the maps drawn from that count would be wrong too.',
    },
  },
  {
    q: { es: '¿Por qué importan tanto las direcciones?', en: 'Why do addresses matter so much?' },
    a: {
      es: 'Una regla que verifica la residencia con récords solo funciona si la dirección del récord se puede parear con una vivienda real. Se estima que entre el 40% y el 60% de las estructuras en Puerto Rico no tienen una dirección que se pueda ubicar en un mapa: muchas familias usan apartados postales, rutas rurales o descripciones como “Carr. 2, km 14.3”. Además, el campo “Urbanización”, los acentos y los dos apellidos confunden a los sistemas nacionales. Lee más en la página Impacto en PR.',
      en: 'A rule that verifies residence with records only works if the record’s address can be matched to a real home. An estimated 40% to 60% of structures in Puerto Rico have no mappable address: many families use P.O. boxes, rural routes, or descriptions like “Road 2, km 14.3.” The “Urbanización” line, accents, and two surnames also confuse national systems. Read more on the Impact on PR page.',
    },
  },
  {
    q: { es: '¿Mi comentario será público?', en: 'Will my comment be public?' },
    a: {
      es: 'Sí. Todo lo que envíes, incluyendo nombre y dirección, se publica en Regulations.gov. Puedes comentar de forma anónima escribiendo “N/A” en los campos requeridos. No incluyas información sensible.',
      en: 'Yes. Everything you submit, including name and address, is posted on Regulations.gov. You can comment anonymously by entering “N/A” in the required fields. Don’t include sensitive information.',
    },
  },
  {
    q: { es: '¿Sirve de algo comentar?', en: 'Does commenting actually matter?' },
    a: {
      es: 'Sí. La ley obliga a la agencia a considerar los comentarios relevantes antes de adoptar una regla final y a responder a los argumentos importantes. Esos comentarios también forman el récord que los tribunales revisan si la regla se impugna. Los comentarios originales, específicos y basados en tu experiencia pesan más que las cartas idénticas.',
      en: 'Yes. By law, the agency must consider relevant comments before finalizing a rule and respond to significant arguments. Those comments also form the record courts review if the rule is challenged. Original, specific comments grounded in your experience carry more weight than identical form letters.',
    },
  },
  {
    q: { es: '¿Qué tiene que ver esto con los datos abiertos?', en: 'What does this have to do with open data?' },
    a: {
      es: 'Los datos del Censo son el bien público de datos más grande de la nación: gratuitos, abiertos y la base de casi todas las demás estadísticas. Cuando el Censo deja de recoger un dato, ese dato se pierde para todo el mundo: legisladores, periodistas, municipios, investigadores, emprendedores, empresarios, académicos, organizaciones y comunidades. Defender el Censo es defender los datos abiertos. El público es dueño de sus datos.',
      en: 'Census data are the nation’s largest public data good: free, open, and the foundation of nearly every other statistic. When the Census stops collecting something, it is lost to everyone: lawmakers, journalists, municipios, researchers, entrepreneurs, business owners, academics, organizations, and communities. Defending the Census is defending open data. The public owns its data.',
    },
  },
  {
    q: { es: '¿Esta campaña es partidista?', en: 'Is this campaign partisan?' },
    a: {
      es: 'No. Puerto Rico Cuenta no apoya partidos, candidatos ni posiciones sobre el estatus político. Nos une algo más básico: que todas las personas sean contadas, una vez y en el lugar correcto.',
      en: 'No. Puerto Rico Cuenta does not support parties, candidates, or positions on political status. We share something more basic: that everyone be counted, once, and in the right place.',
    },
  },
]
