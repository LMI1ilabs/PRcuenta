import type { L } from '@/lib/i18n'

// Puerto Rico-specific analysis behind the /impacto page. Figures are attributed
// to their source; anything that is reasoning from the rule's design is phrased
// as a risk, not a measured result.

export const COMPARE: { topic: L; rule: L; reality: L; risk: L }[] = [
  {
    topic: { es: 'Residencia', en: 'Residence' },
    rule: { es: 'Exige que la residencia sea consistente con planillas federales (IRS / W-2).', en: 'Residence should be consistent with federal tax records (IRS / W-2).' },
    reality: { es: 'Rendimos en Hacienda (Formulario 499R-2/W-2PR) o no estamos obligados a radicar planilla federal.', en: 'We file with Hacienda (Form 499R-2/W-2PR) or aren’t required to file a federal return.' },
    risk: { es: 'Un conteo incompleto que reduce la base para fondos de Medicaid, PAN y WIC.', en: 'An incomplete count that shrinks the base for Medicaid, NAP, and WIC funds.' },
  },
  {
    topic: { es: 'Dirección', en: 'Address' },
    rule: { es: 'Valida viviendas con récords postales y bases de datos administrativas.', en: 'Validates dwellings against postal and administrative records.' },
    reality: { es: 'Entre el 40% y el 60% de las estructuras no tienen una dirección que se pueda ubicar en un mapa: rutas rurales, apartados o descripciones físicas.', en: 'An estimated 40–60% of structures have no mappable address: rural routes, P.O. boxes, or physical descriptions.' },
    risk: { es: 'El sistema no ubica la casa y se pierden datos del barrio y del municipio.', en: 'The system can’t locate the home, and barrio and municipio data are lost.' },
  },
  {
    topic: { es: 'Conteo', en: 'Count' },
    rule: { es: 'Cuenta los días presentes entre el 3 de enero y el 1 de abril.', en: 'Counts days present between January 3 and April 1.' },
    reality: { es: 'Migración circular constante: familias que van y vienen entre Puerto Rico y los estados.', en: 'Constant circular migration: families moving back and forth between Puerto Rico and the states.' },
    risk: { es: 'Confusión sobre dónde se cuenta a cada persona: en el lugar equivocado, dos veces o ninguna.', en: 'Confusion over where each person is counted: in the wrong place, twice, or not at all.' },
  },
  {
    topic: { es: 'Identidad', en: 'Identity' },
    rule: { es: 'Prohíbe preguntar raza y origen hispano.', en: 'Bans race and Hispanic-origin questions.' },
    reality: { es: 'Es la única medida completa de cómo se identifica Puerto Rico, y el encasillado “puertorriqueño” identifica a la diáspora.', en: 'It is Puerto Rico’s only full-count measure of identity, and the “Puerto Rican” checkbox identifies the diaspora.' },
    risk: { es: 'Sin punto de referencia para estudiar desigualdades ni para contar a los boricuas en los estados.', en: 'No benchmark to study disparities or to count Puerto Ricans in the states.' },
  },
]

export const ADDRESS_STATS: { v: string; l: L }[] = [
  { v: '40–60%', l: { es: 'de las estructuras en Puerto Rico no tienen una dirección que se pueda ubicar en un mapa', en: 'of structures in Puerto Rico have no mappable address' } },
  { v: '1M+', l: { es: 'residentes sin una dirección convencional de calle y número', en: 'residents without a conventional street-and-number address' } },
  { v: '24 de 78', l: { es: 'municipios donde más del 60% de las residencias no tienen una dirección convencional verificable', en: 'municipios where more than 60% of residences lack a verifiable conventional address' } },
  { v: '48%', l: { es: 'de las direcciones de calle necesitan el campo “Urbanización”, que no se usa en los estados', en: 'of street addresses need an “Urbanización” line, which isn’t used in the states' } },
]

export const ADDRESS_POINTS: { title: L; body: L }[] = [
  {
    title: { es: 'Un apartado no es una casa', en: 'A P.O. box isn’t a home' },
    body: {
      es: 'Muchas familias reciben la correspondencia en un apartado postal, una ruta rural (RR) o un “highway contract” (HC). Esas designaciones no identifican la vivienda donde duermes. Los récords contributivos y de beneficios usan la dirección postal, que en Puerto Rico muchas veces no es donde vive la familia, así que el récord puede apuntar al bloque o al municipio equivocado.',
      en: 'Many families get mail at a P.O. box, a rural route (RR), or a highway contract (HC) route. None of those identify the home where you sleep. Tax and benefit records carry the mailing address, which in Puerto Rico is often not where the family lives, so the record can point to the wrong block or municipio.',
    },
  },
  {
    title: { es: 'Formatos que los sistemas nacionales no esperan', en: 'Formats national systems don’t expect' },
    body: {
      es: 'Puerto Rico es la única jurisdicción de EE. UU. que usa una dirección de tres líneas con el campo “Urbanización”, además de acentos y la letra ñ. Aun las direcciones de calle y número tienen que validarse, estandarizarse y geocodificarse según esas convenciones locales para que coincidan.',
      en: 'Puerto Rico is the only U.S. jurisdiction that uses a three-line address with an “Urbanización” field, plus accents and the letter ñ. Even street-and-number addresses must be validated, standardized, and geocoded under those local conventions to match.',
    },
  },
  {
    title: { es: 'Ya pasó con FEMA y las vacunas', en: 'It already happened with FEMA and vaccines' },
    body: {
      es: 'Después del huracán María, según reportes, muchas direcciones sometidas en el campo de una sola línea de FEMA no se pudieron procesar para la asistencia individual. En 2021, durante la distribución de vacunas del COVID-19 por el programa federal de farmacias, se reportó que residentes con direcciones RR o HC no pudieron registrarse porque se exigía una dirección de calle.',
      en: 'After Hurricane Maria, many addresses entered in FEMA’s single-line address field reportedly could not be processed for individual assistance. In 2021, during COVID-19 vaccine distribution through the Federal Retail Pharmacy Program, residents with RR or HC addresses were reportedly unable to register because a street address was required.',
    },
  },
  {
    title: { es: 'LUCA no puede corregirlo todo', en: 'LUCA can’t fix it all' },
    body: {
      es: 'El programa de Actualización Local de Direcciones del Censo (LUCA) es la herramienta principal de los municipios para corregir la lista de direcciones. Pero sus guías no usan récords que solo tienen información “non-city-style” para parear o añadir direcciones. La Oficina del Censo reporta que el 16.6% de las direcciones de Puerto Rico en su Archivo Maestro son de ese tipo, frente a cerca del 0.6% a nivel nacional.',
      en: 'The Local Update of Census Addresses (LUCA) program is municipios’ main tool for fixing the address list. But its guidelines don’t use records with only non-city-style information to match or add addresses. The Census Bureau reports that 16.6% of Puerto Rico addresses in its Master Address File are non-city-style, against about 0.6% nationally.',
    },
  },
]

// One person, as different agencies might record them.
export const NAME_VARIANTS: { source: L; name: string }[] = [
  { source: { es: 'Nombre completo', en: 'Full name' }, name: 'Juan Carlos Rivera Rodríguez' },
  { source: { es: 'Agencia A (p. ej., Seguro Social)', en: 'Agency A (e.g., Social Security)' }, name: 'Juan C. Rivera' },
  { source: { es: 'Agencia B (p. ej., licencia de conducir)', en: 'Agency B (e.g., driver’s license)' }, name: 'Juan Carlos RiveraRodriguez' },
  { source: { es: 'Agencia C (p. ej., formulario del Censo)', en: 'Agency C (e.g., Census form)' }, name: 'Juan Carlos Rivera-Rodríguez' },
]

export const NAME_POINTS: L[] = [
  {
    es: 'El “segundo nombre” que no es: si un sistema procesa “Sofía Torres Morales”, puede tomar “Torres” como segundo nombre y “Morales” como apellido. Otro archivo que sí tiene a Torres como apellido paterno vería a dos personas distintas en la misma dirección.',
    en: 'The “middle name” that isn’t: a system that reads “Sofía Torres Morales” may take “Torres” as a middle name and “Morales” as the surname. Another file that correctly lists Torres as the paternal surname would see two different people at the same address.',
  },
  {
    es: 'Las mujeres en Puerto Rico no cambian legalmente sus apellidos al casarse, pero algunos récords federales o financieros añaden el apellido del esposo o un “de”.',
    en: 'Women in Puerto Rico don’t legally change their surnames at marriage, but some federal or financial records append the husband’s surname or a “de.”',
  },
  {
    es: 'Apellidos como García, Rodríguez y Martínez son muy comunes. Si el récord pierde el apellido materno, el sistema no puede distinguir entre un padre, un hijo o un inquilino anterior con el mismo nombre.',
    en: 'Surnames like García, Rodríguez, and Martínez are very common. If a record drops the maternal surname, the system can’t tell a father from a son, or from a previous tenant with the same name.',
  },
  {
    es: 'Cuando los nombres no cuadran, el récord no puede “evidenciar” la residencia. El resultado son verificaciones fallidas que requieren intervención manual, imputación estadística o una visita en persona.',
    en: 'When names don’t match, the record can’t “evidence” residence. The result is failed verifications that require manual review, statistical imputation, or an in-person visit.',
  },
]

export const TAX_POINTS: { title: L; body: L }[] = [
  {
    title: { es: 'La mayoría está fuera del archivo federal, por diseño', en: 'Most residents are outside the federal tax file, by design' },
    body: {
      es: 'Los residentes bona fide de Puerto Rico pagan contribución sobre ingresos a Hacienda por su ingreso de fuentes de Puerto Rico y, en general, no tienen que radicar el Formulario 1040 federal por ese ingreso. Los patronos emiten el 499R-2/W-2PR. Más familias empezaron a radicar en 2021 por el Crédito Tributario por Hijos expandido, pero la cobertura sigue siendo parcial.',
      en: 'Bona fide residents of Puerto Rico pay income tax to Hacienda on Puerto Rico-source income and generally don’t have to file a federal Form 1040 for it. Employers issue Form 499R-2/W-2PR. More families began filing in 2021 because of the expanded Child Tax Credit, but coverage remains partial.',
    },
  },
  {
    title: { es: 'Una economía informal grande', en: 'A large informal economy' },
    body: {
      es: 'Los estimados varían, pero los estudios coinciden en que la economía informal es grande: Bloomberg reportó estimados de cerca de un tercio del producto nacional bruto. En comunidades de bajos ingresos de San Juan, el economista José Caraballo-Cueto encontró una diferencia de 28 puntos porcentuales entre quienes dijeron estar empleados en la Encuesta sobre la Comunidad y en su encuesta. Quien cobra en efectivo, trabaja por su cuenta o vive de transferencias deja poco rastro contributivo.',
      en: 'Estimates vary, but studies agree the informal economy is large: Bloomberg reported estimates of about a third of gross national product. In low-income San Juan communities, economist José Caraballo-Cueto found a 28-percentage-point gap between the share who reported being employed in the Community Survey and in his own survey. People paid in cash, self-employed, or living on transfers leave little tax trace.',
    },
  },
  {
    title: { es: 'Quiénes corren más riesgo', en: 'Who is most at risk' },
    body: {
      es: 'Si la Oficina trata un récord contributivo ausente o que no cuadra como evidencia débil de residencia, las personas con más riesgo de quedar fuera o mal ubicadas serían trabajadores informales, adultos mayores, personas que reciben asistencia pública y jóvenes que viven con su familia. Son también las personas a quienes sirven los programas federales.',
      en: 'If the Bureau treats a missing or mismatched tax record as weak evidence of residence, those most likely to be dropped or misplaced would be informal workers, older adults, people on public assistance, and young adults living with family. They are also the people federal programs serve.',
    },
  },
]

export const FUNDING_PROGRAMS: { area: L; programs: L }[] = [
  { area: { es: 'Salud', en: 'Health' }, programs: { es: 'Medicaid, centros de salud comunitaria (CDT)', en: 'Medicaid, community health centers' } },
  { area: { es: 'Nutrición', en: 'Nutrition' }, programs: { es: 'PAN (NAP), WIC y programas para adultos mayores', en: 'NAP, WIC, and senior programs' } },
  { area: { es: 'Educación y niñez', en: 'Education and children' }, programs: { es: 'Título I y Head Start', en: 'Title I and Head Start' } },
  { area: { es: 'Vivienda e infraestructura', en: 'Housing and infrastructure' }, programs: { es: 'Sección 8, CDBG, carreteras y fondos de resiliencia ante desastres', en: 'Section 8, CDBG, highways, and disaster-resilience grants' } },
]

export const FUNDING_SCENARIO = {
  population: '3.2M',
  undercountShare: '40%',
  uncounted: '1.28M',
  perCapita: { es: '$1,500–$3,000', en: '$1,500–$3,000' },
  annual: { es: '$1.9–$3.8 mil millones', en: '$1.9–$3.8 billion' },
  decade: { es: '$19–$38 mil millones', en: '$19–$38 billion' },
}

export const DISTRICT_POINTS: { title: L; body: L }[] = [
  {
    title: { es: 'La base constitucional', en: 'The constitutional basis' },
    body: {
      es: 'La Constitución de Puerto Rico (Artículo III, Sección 4) dispone que, después de cada censo decenal, se revisen los distritos senatoriales y representativos para mantener una representación equitativa según los cambios en la población.',
      en: 'Puerto Rico’s Constitution (Article III, Section 4) provides that after each decennial census, senate and house districts are revised to keep representation fair as the population changes.',
    },
  },
  {
    title: { es: 'Un ciudadano, un voto', en: 'One person, one vote' },
    body: {
      es: 'Se toma la población total que reporta el Censo y se divide entre los 40 distritos representativos y los 8 senatoriales para fijar la población ideal de cada distrito. Ningún distrito debe alejarse mucho de esa cifra, para que el voto en un municipio menos poblado no valga más que en uno denso.',
      en: 'The total population reported by the Census is divided among the 40 house districts and 8 senate districts to set each district’s ideal population. No district should stray far from that figure, so a vote in a less populated municipio doesn’t count more than one in a dense area.',
    },
  },
  {
    title: { es: 'Bloque por bloque', en: 'Block by block' },
    body: {
      es: 'La Junta de Redistribución trabaja con la cartografía y los datos del Censo a nivel de bloques censales y barrios, para mover fronteras dentro de un municipio o entre municipios y balancear los números, procurando la contigüidad y evitar dividir municipios salvo cuando la densidad lo hace necesario, como en San Juan, Bayamón o Ponce.',
      en: 'The redistricting board works with Census maps and data at the census block and barrio level to move boundaries within or between municipios and balance the numbers, aiming for contiguity and avoiding splitting municipios unless density requires it, as in San Juan, Bayamón, or Ponce.',
    },
  },
  {
    title: { es: 'Lo que la regla pone en riesgo', en: 'What the rule puts at risk' },
    body: {
      es: 'Si la regla deja fuera a hogares cuyos récords no cuadran, o los ubica en la dirección postal y no donde viven, la población de cada bloque y barrio cambia, y con ella los mapas de 2032 en adelante. Es una inferencia del diseño de la regla, pero los mapas solo pueden ser tan buenos como el conteo.',
      en: 'If the rule drops households whose records don’t match, or places them at a mailing address instead of where they live, the population of each block and barrio shifts, and so do the maps from 2032 on. That is an inference from the rule’s design, but the maps can only be as good as the count.',
    },
  },
]

export const ASKS: L[] = [
  { es: 'Aclarar cómo aplica la Parte 60 al conteo de Puerto Rico y qué criterios rigen los productos estadísticos y las fórmulas de fondos que dependen de él.', en: 'State how Part 60 applies to Puerto Rico’s count, and which criteria govern the statistical products and funding formulas that depend on it.' },
  { es: 'No hacer de las planillas federales la prueba de residencia en Puerto Rico. Aceptar la autorespuesta, la verificación en el campo y récords de Puerto Rico como las planillas de Hacienda y el 499R-2/W-2PR.', en: 'Not make federal tax records the proof of residence in Puerto Rico. Accept self-response, field verification, and Puerto Rico records such as Hacienda returns and Form 499R-2/W-2PR.' },
  { es: 'Publicar la cobertura y las tasas de pareo de direcciones en Puerto Rico de cada fuente administrativa (IRS, Seguro Social, Medicaid, PAN, Hacienda) antes de usarlas.', en: 'Publish Puerto Rico coverage and address-match rates for every administrative source (IRS, SSA, Medicaid, NAP, Hacienda) before relying on any of them.' },
  { es: 'Mantener la enumeración en persona donde las direcciones no se puedan parear, y permitir que LUCA use descripciones físicas para añadir y ubicar viviendas.', en: 'Keep in-person enumeration wherever addresses can’t be matched, and let LUCA submissions with physical descriptions add and locate housing units.' },
  { es: 'Mantener el 1 de abril como fecha de referencia, o explicar cómo el conteo de días trataría la migración circular.', en: 'Keep April 1 as the reference date, or show how the day count would treat circular migrants.' },
  { es: 'Mantener las preguntas de raza y origen hispano en Puerto Rico, con categorías probadas localmente.', en: 'Keep race and Hispanic-origin questions in Puerto Rico, with categories tested locally.' },
  { es: 'Proteger las tablas por municipio, barrio y sector censal bajo el límite de publicación de la sección 70.3.', en: 'Protect municipio, barrio, and tract tables under the § 70.3 publication limit.' },
  { es: 'Publicar un análisis del efecto de la regla en la base poblacional de Puerto Rico, la Encuesta sobre la Comunidad y los fondos federales antes de adoptarla.', en: 'Publish an analysis of the rule’s effect on Puerto Rico’s population base, the Community Survey, and federal funding before finalizing it.' },
]

export const WHO_SHOULD_COMMENT: L = {
  es: 'La Fortaleza, PRFAA, el Instituto de Estadísticas, la Junta de Planificación, los 78 municipios, la Asociación y la Federación de Alcaldes, la Liga de Ciudades, la oficina del Comisionado Residente, centros de investigación como el Centro para una Nueva Economía y Espacios Abiertos, universidades, organizaciones de salud y comunitarias, la Cámara de Comercio, la Asociación de Industriales y otras asociaciones de negocios, y cada persona que vive aquí.',
  en: 'La Fortaleza, PRFAA, the Puerto Rico Institute of Statistics, the Planning Board, all 78 municipios, the mayors’ associations, the League of Cities, the Resident Commissioner’s office, think tanks such as the Center for a New Economy and Espacios Abiertos, universities, health and community organizations, the Chamber of Commerce, the Manufacturers Association and other business groups, and every person who lives here.',
}

export const IMPACT_SOURCES: { label: string; href?: string }[] = [
  { label: 'Federal Register, Proposed Rule 2026-18481 (91 FR 57524)', href: 'https://www.federalregister.gov/d/2026-18481' },
  { label: 'Census Bureau, 2020 Post-Enumeration Survey results for Puerto Rico (2022)', href: 'https://www.census.gov/newsroom/press-releases/2022/2020-post-enumeration-survey-results-puerto-rico.html' },
  { label: 'IRS Topic 901, Is a person with income from Puerto Rico required to file a U.S. federal income tax return?', href: 'https://www.irs.gov/taxtopics/tc901' },
  { label: 'Census Bureau, Puerto Rico Community Survey overview', href: 'https://www.census.gov/content/dam/Census/programs-surveys/acs/Library/OutreachMaterials/ACSFlyers/PRCS_Overview_Flyer.pdf' },
  { label: 'Census Bureau, Federal funds distribution, FY2021 (2023)', href: 'https://www.census.gov/newsroom/press-releases/2023/decennial-census-federal-funds-distribution.html' },
  { label: 'Centro de Periodismo Investigativo, “Those Living on Unnamed Streets in Puerto Rico Are Invisible” (2024)', href: 'https://periodismoinvestigativo.com/2024/01/those-living-on-unnamed-streets-in-puerto-rico-are-invisible/' },
  { label: 'El Vocero, “La población invisible”', href: 'https://www.elvocero.com/actualidad/la-poblaci-n-invisible/article_e039fac4-ddb7-11e9-bc0a-8f29effc41a5.html' },
  { label: 'AP, “Navigating by mango trees, pink houses in rural Puerto Rico”', href: 'https://apnews.com/article/723960c28989ccfeccab55244994c384' },
  { label: 'CienciaPR, “Local Team Creates Tools to Improve Housing Addresses in Puerto Rico”', href: 'https://www.cienciapr.org/en/local-team-creates-tools-improve-housing-addresses-puerto-rico' },
  { label: 'NBC News, 2020 census overcounted people in Puerto Rico (2022)', href: 'https://www.nbcnews.com/news/latino/2020-census-overcounted-people-puerto-rico-hinting-larger-population-l-rcna43384' },
  { label: 'Accounting Today/Bloomberg, Puerto Rico’s underground economy (2017)', href: 'https://www.accountingtoday.com/articles/puerto-ricos-tax-dodgers-hide-in-plain-sight-on-every-corner' },
  { label: 'Caraballo-Cueto, J. (2026). Informal Labor Markets After Disasters. Social Science Quarterly, 107(2), e70148' },
  { label: 'Puerto Rico Institute of Statistics, Study on the informal economy', href: 'https://www.estadisticas.pr.gov/en-us/productos/estudio-sobre-la-economia-informal-en-puerto-rico' },
]
