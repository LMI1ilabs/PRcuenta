import type { L } from '@/lib/i18n'

export type RuleChange = {
  id: string
  part: '60' | '70'
  section: string
  title: L
  plain: L
  quote: string
  prImpact: L
}

// Plain-language summary of each provision, with the verbatim regulatory text
// from FR Doc 2026-18481 and what it would mean for Puerto Rico.
export const RULE_CHANGES: RuleChange[] = [
  {
    id: 'residencia',
    part: '60',
    section: '§ 60.2',
    title: { es: 'Tu residencia se define contando días', en: 'Your residence is defined by counting days' },
    plain: {
      es: 'Tu “residencia habitual” sería el lugar donde pasaste legalmente más días entre el 3 de enero y el 1 de abril del año censal. Basta una hora en un lugar para que cuente como un día allí, y la residencia “debe ser consistente con” tus récords contributivos (planillas, W-2).',
      en: 'Your “usual residence” would be wherever you lawfully spent the most days between January 3 and April 1 of the census year. One hour somewhere counts as a day there, and residence “should be consistent with” your tax records (returns, W-2s).',
    },
    quote:
      '“A person’s ‘usual residence’ is the residence at which they have lawfully spent the greatest number of days during the census enumeration period. A person’s ‘usual residence’ should be consistent with, and evidenced by, their tax records (e.g., tax returns, W-2 forms).”',
    prImpact: {
      es: 'Muchas personas en Puerto Rico no rinden planilla federal: si su ingreso es de fuentes locales de Puerto Rico, rinden ante Hacienda (SURI) y sus patronos emiten el Formulario 499R-2/W-2PR. Jubilados y hogares de bajos ingresos a menudo no rinden ninguna. La regla no dice si esos récords cuentan. Y entre el 40% y el 60% de las estructuras en Puerto Rico no tienen una dirección que se pueda ubicar en un mapa, así que un récord con apartado postal o ruta rural no prueba dónde vives.',
      en: 'Many people in Puerto Rico don’t file a federal return; if their income is from Puerto Rico sources, they file with Hacienda (SURI), and employers issue Form 499R-2/W-2PR. Retirees and low-income households often file none at all. The rule never says whether those records count. And an estimated 40% to 60% of structures in Puerto Rico have no mappable address, so a record with a P.O. box or rural route doesn’t prove where you live.',
    },
  },
  {
    id: 'periodo',
    part: '60',
    section: '§ 60.2(c)',
    title: { es: 'Un nuevo “periodo de enumeración”', en: 'A new “enumeration period”' },
    plain: {
      es: 'Por primera vez, el Censo dejaría de preguntar dónde vives y duermes la mayor parte del tiempo. En su lugar contaría días dentro de una ventana fija de 89 días.',
      en: 'For the first time, the Census would stop asking where you live and sleep most of the time. Instead it would count days within a fixed 89-day window.',
    },
    quote: '“The census enumeration period runs from January 3 to April 1 during decennial census years.”',
    prImpact: {
      es: 'La migración circular es parte de la vida boricua: estudiantes, trabajadores agrícolas temporeros, cuidadores que van y vienen y familias desplazadas por huracanes y terremotos. Una ventana de enero a abril puede ubicarlos donde no viven.',
      en: 'Circular migration is part of Puerto Rican life: students, seasonal farmworkers, caregivers who go back and forth, and families displaced by hurricanes and earthquakes. A January–April window can place them where they don’t live.',
    },
  },
  {
    id: 'extranjeros',
    part: '60',
    section: '§ 60.4',
    title: { es: 'Excluye a muchos residentes que no son ciudadanos', en: 'Many non-citizen residents are excluded' },
    plain: {
      es: 'Solo los ciudadanos estadounidenses y los residentes permanentes legales se contarían para la distribución de escaños. Quedarían fuera las personas con visa de estudiante o de trabajo, solicitantes de asilo, beneficiarios de TPS y DACA, y otras. Además, la Oficina pide comentarios sobre añadir una pregunta de estatus legal.',
      en: 'Only U.S. citizens and lawful permanent residents would be counted for apportionment. People on student or work visas, asylum seekers, TPS and DACA recipients, and others would be left out. The Bureau also asks for comments on adding a legal-status question.',
    },
    quote:
      '“All other citizens of foreign countries as of April 1 of a decennial census year. Not counted for apportionment.”',
    prImpact: {
      es: 'Puerto Rico tiene comunidades inmigrantes arraigadas, sobre todo dominicanas, y muchos hogares de estatus mixto. Una pregunta sobre estatus legal puede espantar a familias enteras del Censo, y eso reduce el conteo de barrios y municipios.',
      en: 'Puerto Rico has deep-rooted immigrant communities, especially Dominican, and many mixed-status households. A legal-status question could scare whole families away from the Census, shrinking the counts for barrios and municipios.',
    },
  },
  {
    id: 'fuera',
    part: '60',
    section: '§ 60.5',
    title: { es: '¿Quién está “fuera de los Estados Unidos”?', en: 'Who is “outside the United States”?' },
    plain: {
      es: 'Las personas que vivan fuera de los Estados Unidos el Día del Censo “no se cuentan en el censo de los estados”. La regla nunca define “Estados Unidos” ni menciona a Puerto Rico.',
      en: 'People living outside the United States on Census Day are “not counted in the stateside census.” The rule never defines “United States” or mentions Puerto Rico.',
    },
    quote:
      '“Persons living outside the United States on Census Day who are not military or civilian employees of the U.S. government … Not counted in the stateside census.”',
    prImpact: {
      es: 'El texto completo de la propuesta no menciona a Puerto Rico ni una vez. Más de 3.2 millones de ciudadanos estadounidenses merecen que el Censo diga claramente cómo se les aplicarán estas reglas.',
      en: 'The full text of the rule doesn’t mention Puerto Rico even once. More than 3.2 million U.S. citizens deserve a clear statement of how these rules would apply to them.',
    },
  },
  {
    id: 'etnicidad',
    part: '70',
    section: '§ 70.2',
    title: { es: 'Prohíbe las preguntas de raza y etnicidad', en: 'Race and ethnicity questions are banned' },
    plain: {
      es: 'Ningún cuestionario usado para contar a la población podría preguntar raza, etnicidad u orientación sexual. Solo se permitirían sexo biológico, fecha de nacimiento y relación con el hogar.',
      en: 'No questionnaire used to count the population could ask about race, ethnicity, or sexual orientation. Only biological sex, date of birth, and household relationship would be allowed.',
    },
    quote:
      '“No question about race, ethnicity, or sexual orientation shall appear on the short form decennial census questionnaire or any questionnaire used for the enumeration of the population.”',
    prImpact: {
      es: 'La pregunta de origen hispano, con su encasillado “puertorriqueño”, es la única forma en que el Censo cuenta a la diáspora. Hoy viven más boricuas en los estados que en Puerto Rico. Sin esa pregunta, desaparecen de los datos oficiales.',
      en: 'The Hispanic-origin question, with its “Puerto Rican” checkbox, is the only way the Census counts the diaspora. More Puerto Ricans now live in the states than in Puerto Rico. Without that question, they vanish from the official data.',
    },
  },
  {
    id: 'divulgacion',
    part: '70',
    section: '§ 70.3–70.4',
    title: { es: 'Menos datos demográficos publicados', en: 'Less demographic data published' },
    plain: {
      es: 'El Censo no publicaría datos demográficos si hacerlo requiere añadir incertidumbre al conteo “a nivel nacional o estatal”. La regla dice que la Encuesta sobre la Comunidad (ACS) y otras encuestas aún podrían preguntar.',
      en: 'The Bureau would not publish demographic data if doing so requires adding uncertainty to counts “at either the national or the state level.” The rule says the American Community Survey and other surveys could still ask.',
    },
    quote:
      '“The Census Bureau shall not disclose or publish any individual demographic data if such disclosure or publication necessitates introducing uncertainty into the population count data, at either the national or the state level.”',
    prImpact: {
      es: 'La Encuesta sobre la Comunidad de Puerto Rico (PRCS) se ajusta a estimados de población que parten del Censo decenal. Sin datos de raza y origen en esa base, las estadísticas que usan municipios, hospitales, escuelas y planificadores pierden su punto de referencia.',
      en: 'The Puerto Rico Community Survey (PRCS) is weighted to population estimates built on the decennial census. Without race and origin data in that base, the statistics municipios, hospitals, schools, and planners rely on lose their benchmark.',
    },
  },
]
