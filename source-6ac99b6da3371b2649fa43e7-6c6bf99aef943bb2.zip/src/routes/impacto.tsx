import { Link, createFileRoute } from '@tanstack/react-router'
import { Eyebrow, PageHero } from '@/components/ui'
import {
  ADDRESS_POINTS,
  ADDRESS_STATS,
  ASKS,
  COMPARE,
  DISTRICT_POINTS,
  FUNDING_PROGRAMS,
  FUNDING_SCENARIO,
  IMPACT_SOURCES,
  NAME_POINTS,
  NAME_VARIANTS,
  TAX_POINTS,
  WHO_SHOULD_COMMENT,
} from '@/content/impact'
import { useLang } from '@/lib/i18n'

export const Route = createFileRoute('/impacto')({
  component: ImpactPage,
  head: () => ({ meta: [{ title: 'Impacto en Puerto Rico · Puerto Rico Cuenta' }] }),
})

const SECTIONS = [
  { id: 'resumen', label: { es: 'Regla vs. realidad', en: 'Rule vs. reality' } },
  { id: 'direcciones', label: { es: 'Direcciones', en: 'Addresses' } },
  { id: 'nombres', label: { es: 'Nombres y apellidos', en: 'Names and surnames' } },
  { id: 'planillas', label: { es: 'Planillas y economía informal', en: 'Taxes and the informal economy' } },
  { id: 'fondos', label: { es: 'Fondos federales', en: 'Federal funds' } },
  { id: 'distritos', label: { es: 'Distritos electorales', en: 'Electoral districts' } },
  { id: 'pedidos', label: { es: 'Lo que pedimos', en: 'What we ask' } },
]

function SectionHead({ eyebrow, title }: { eyebrow: string; title: string }) {
  return (
    <div className="border-b-2 border-ink pb-4">
      <Eyebrow>{eyebrow}</Eyebrow>
      <h2 className="mt-2 font-display text-3xl font-extrabold text-ink md:text-4xl">{title}</h2>
    </div>
  )
}

function ImpactPage() {
  const { t } = useLang()
  return (
    <>
      <PageHero
        eyebrow={t({ es: 'Impacto en Puerto Rico', en: 'Impact on Puerto Rico' })}
        title={t({ es: 'Una regla escrita para los estados, aplicada a nuestra realidad.', en: 'A rule written for the states, applied to our reality.' })}
        lede={t({
          es: 'El conteo de Puerto Rico se hace bajo la misma autoridad del Título 13, así que la residencia por días y la evidencia contributiva de la Parte 60 regirían cómo se cuenta a 3.2 millones de personas. Los récords en los que se apoya la regla son justamente los que peor cubren a Puerto Rico.',
          en: 'Puerto Rico’s count is taken under the same Title 13 authority, so Part 60’s day-count residence test and tax-record evidence would govern how 3.2 million people are counted. The records the rule leans on are exactly the ones that cover Puerto Rico least well.',
        })}
      />

      <nav aria-label={t({ es: 'En esta página', en: 'On this page' })} className="border-b-2 border-ink bg-paper-deep">
        <ul className="mx-auto flex max-w-7xl flex-wrap gap-2 px-5 py-4">
          {SECTIONS.map((s) => (
            <li key={s.id}>
              <a href={`#${s.id}`} className="inline-block border-2 border-ink bg-paper px-3 py-1.5 text-sm font-semibold text-ink hover:bg-coral">{t(s.label)}</a>
            </li>
          ))}
        </ul>
      </nav>

      <div className="mx-auto max-w-7xl space-y-20 px-5 py-16">
        {/* Rule vs reality */}
        <section id="resumen" className="scroll-mt-40">
          <SectionHead eyebrow={t({ es: 'Qué significa para ti', en: 'What it means for you' })} title={t({ es: 'La regla propuesta frente a la realidad de Puerto Rico', en: 'The proposed rule against Puerto Rico’s reality' })} />
          <div className="mt-8 overflow-x-auto">
            <table className="w-full min-w-[44rem] border-2 border-ink text-left">
              <thead className="bg-ink text-paper">
                <tr>
                  <th scope="col" className="w-32 px-4 py-3 font-mono text-xs uppercase tracking-wider"><span className="sr-only">{t({ es: 'Tema', en: 'Topic' })}</span></th>
                  <th scope="col" className="px-4 py-3 font-mono text-xs uppercase tracking-wider">{t({ es: 'Regla propuesta', en: 'Proposed rule' })}</th>
                  <th scope="col" className="px-4 py-3 font-mono text-xs uppercase tracking-wider">{t({ es: 'La realidad de Puerto Rico', en: 'Puerto Rico’s reality' })}</th>
                  <th scope="col" className="px-4 py-3 font-mono text-xs uppercase tracking-wider text-coral">{t({ es: 'El riesgo', en: 'The risk' })}</th>
                </tr>
              </thead>
              <tbody className="divide-y-2 divide-ink">
                {COMPARE.map((r) => (
                  <tr key={r.topic.en} className="align-top">
                    <th scope="row" className="bg-coral px-4 py-4 font-display text-lg font-extrabold text-ink">{t(r.topic)}</th>
                    <td className="bg-paper px-4 py-4 text-ink/85">{t(r.rule)}</td>
                    <td className="bg-white px-4 py-4 font-medium text-ink">{t(r.reality)}</td>
                    <td className="bg-paper-deep px-4 py-4 text-ink/85">{t(r.risk)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        {/* Addresses */}
        <section id="direcciones" className="scroll-mt-40">
          <SectionHead eyebrow={t({ es: 'La importancia de las direcciones', en: 'Why addresses matter' })} title={t({ es: 'Si el sistema no encuentra tu casa, no te encuentra a ti.', en: 'If the system can’t find your home, it can’t find you.' })} />
          <p className="mt-6 max-w-3xl text-lg text-ink/90">
            {t({
              es: 'Una prueba de residencia basada en récords solo funciona si la dirección del récord se puede parear con una vivienda real. Se ha estimado que más de la mitad de las viviendas en Puerto Rico no tienen nombre de calle o número. Sin procesos adaptados a cómo nos ubicamos aquí, el pareo de direcciones podría dejar fuera del conteo a muchos residentes y ciudadanos estadounidenses.',
              en: 'A records-based residence test only works if the record’s address can be matched to a real home. It has been estimated that over half of Puerto Rico’s housing units lack a street name or house number. Without processes adapted to how we find each other here, address matching could leave many residents and U.S. citizens out of the count.',
            })}
          </p>
          <dl className="mt-8 grid gap-px border-2 border-ink bg-ink sm:grid-cols-2 lg:grid-cols-4">
            {ADDRESS_STATS.map((s) => (
              <div key={s.v} className="bg-ink p-6 text-paper">
                <dt className="sr-only">{t(s.l)}</dt>
                <dd className="font-display text-5xl font-extrabold tabular-nums text-coral">{s.v}</dd>
                <dd className="mt-2 text-paper/85">{t(s.l)}</dd>
              </div>
            ))}
          </dl>
          <p className="mt-3 font-mono text-xs text-ink/70">
            {t({
              es: 'Fuente: estudio de la Initiative for Civic Address Systems Assessment in Puerto Rico (iCasaPR), la única organización sin fines de lucro de Puerto Rico dedicada a la infraestructura de direcciones.',
              en: 'Source: study by the Initiative for Civic Address Systems Assessment in Puerto Rico (iCasaPR), Puerto Rico’s only nonprofit focused on address infrastructure.',
            })}
          </p>
          <div className="mt-10 grid gap-6 md:grid-cols-2">
            {ADDRESS_POINTS.map((p) => (
              <article key={p.title.en} className="border-2 border-ink bg-paper p-6">
                <h3 className="font-display text-xl font-extrabold text-ink">{t(p.title)}</h3>
                <p className="mt-2 text-ink/85">{t(p.body)}</p>
              </article>
            ))}
          </div>
          <div className="riso-shadow mt-8 border-2 border-ink bg-ink p-6 text-paper">
            <p className="font-mono text-xs font-semibold uppercase tracking-widest text-coral">{t({ es: 'Lo que mostró 2020', en: 'What 2020 showed' })}</p>
            <p className="mt-2 text-paper/90">
              {t({
                es: 'La Encuesta Post-Enumeración de 2020 estimó un sobreconteo neto de 5.7% en Puerto Rico (cerca de 174,000 personas) y enumeraciones erróneas de 9.8%, mayormente duplicados. El problema no fue que faltaran récords, sino que no cuadraban. Una regla que depende aún más de esos récords podría inclinar el error hacia el otro lado: hogares reales que quedan fuera o en el lugar equivocado.',
                en: 'The 2020 Post-Enumeration Survey estimated a net overcount of 5.7% in Puerto Rico (about 174,000 people) and erroneous enumerations of 9.8%, mostly duplicates. The problem wasn’t too few records; it was records that didn’t line up. A rule that leans even harder on those records could tip the error the other way: real households left out or placed in the wrong spot.',
              })}
            </p>
          </div>
        </section>

        {/* Names */}
        <section id="nombres" className="scroll-mt-40">
          <SectionHead eyebrow={t({ es: 'Un problema único de Puerto Rico', en: 'A problem unique to Puerto Rico' })} title={t({ es: 'Dos apellidos, tres récords, ninguna coincidencia', en: 'Two surnames, three records, no match' })} />
          <p className="mt-6 max-w-3xl text-lg text-ink/90">
            {t({
              es: 'Para verificar quién vive en una dirección, los sistemas federales comparan nombres entre récords. Esos sistemas esperan nombre, segundo nombre y un apellido. Nuestro sistema de apellido paterno y materno se registra de formas distintas en cada agencia, y el algoritmo ve personas diferentes donde hay una sola.',
              en: 'To verify who lives at an address, federal systems compare names across records. Those systems expect a first name, a middle name, and one surname. Our paternal-plus-maternal surname system is recorded differently by each agency, and the algorithm sees different people where there is only one.',
            })}
          </p>
          <div className="mt-8 grid gap-8 lg:grid-cols-[1fr_1.2fr]">
            <div className="riso-shadow border-2 border-ink bg-white">
              <p className="border-b-2 border-ink bg-paper-deep px-4 py-2 font-mono text-xs font-semibold uppercase tracking-wider text-ink">{t({ es: 'Una persona, cuatro récords', en: 'One person, four records' })}</p>
              <ul className="divide-y divide-ink/20">
                {NAME_VARIANTS.map((v, i) => (
                  <li key={v.name} className="flex flex-wrap items-baseline justify-between gap-2 px-4 py-3">
                    <span className="text-sm text-ink/70">{t(v.source)}</span>
                    <span className={`font-mono text-sm ${i === 0 ? 'font-semibold text-ink' : 'text-coral-deep'}`}>{v.name}</span>
                  </li>
                ))}
              </ul>
              <p className="border-t-2 border-ink px-4 py-3 text-sm text-ink/80">
                {t({
                  es: 'Al comparar la Agencia A con la B, “Rivera” y “RiveraRodriguez” no coinciden: el sistema marca un posible duplicado o no logra ubicar al residente.',
                  en: 'Comparing Agency A with Agency B, “Rivera” and “RiveraRodriguez” don’t match: the system flags a possible duplicate or fails to place the resident.',
                })}
              </p>
            </div>
            <ul className="space-y-4">
              {NAME_POINTS.map((p) => (
                <li key={p.en} className="flex gap-3 text-ink/90">
                  <span className="mt-2 h-2 w-2 shrink-0 bg-coral" aria-hidden="true" />
                  <span>{t(p)}</span>
                </li>
              ))}
            </ul>
          </div>
        </section>

        {/* Taxes */}
        <section id="planillas" className="scroll-mt-40">
          <SectionHead eyebrow={t({ es: 'Récords contributivos', en: 'Tax records' })} title={t({ es: 'Dos huecos que se suman', en: 'Two gaps that stack' })} />
          <div className="mt-8 grid gap-6 md:grid-cols-3">
            {TAX_POINTS.map((p, i) => (
              <article key={p.title.en} className="border-2 border-ink bg-paper p-6">
                <span className="font-display text-4xl font-extrabold text-coral">{String(i + 1).padStart(2, '0')}</span>
                <h3 className="mt-2 font-display text-xl font-extrabold text-ink">{t(p.title)}</h3>
                <p className="mt-2 text-ink/85">{t(p.body)}</p>
              </article>
            ))}
          </div>
        </section>

        {/* Funding */}
        <section id="fondos" className="scroll-mt-40">
          <SectionHead eyebrow={t({ es: 'Fondos federales', en: 'Federal funds' })} title={t({ es: 'Lo que cuesta no contarnos', en: 'What it costs not to count us' })} />
          <p className="mt-6 max-w-3xl text-lg text-ink/90">
            {t({
              es: 'Puerto Rico no participa en la distribución de escaños, pero el conteo decenal es la base estadística de las fórmulas de fondos federales y de las encuestas de hogares. Si la verificación con récords reduce la población oficial, se reduce la base con la que se asignan y justifican esos fondos durante una década.',
              en: 'Puerto Rico isn’t part of apportionment, but the decennial count is the statistical base for federal funding formulas and household surveys. If records-based verification shrinks the official population, it shrinks the base those funds are allocated and justified on for a decade.',
            })}
          </p>
          <div className="mt-8 grid gap-8 lg:grid-cols-[1fr_1.1fr]">
            <ul className="divide-y-2 divide-ink border-y-2 border-ink">
              {FUNDING_PROGRAMS.map((f) => (
                <li key={f.area.en} className="py-4">
                  <p className="font-display text-lg font-extrabold text-ink">{t(f.area)}</p>
                  <p className="text-ink/85">{t(f.programs)}</p>
                </li>
              ))}
            </ul>
            <figure className="riso-shadow border-2 border-ink bg-white">
              <figcaption className="border-b-2 border-ink bg-coral px-5 py-2 font-mono text-xs font-semibold uppercase tracking-wider text-ink">
                {t({ es: 'Escenario ilustrativo, no una proyección', en: 'Illustrative scenario, not a projection' })}
              </figcaption>
              <div className="p-5">
                <p className="text-ink/85">
                  {t({ es: `Si el ${FUNDING_SCENARIO.undercountShare} de la población de Puerto Rico no se contara:`, en: `If ${FUNDING_SCENARIO.undercountShare} of Puerto Rico’s population weren’t counted:` })}
                </p>
                <dl className="mt-4 grid grid-cols-2 gap-4">
                  <div>
                    <dt className="font-mono text-xs uppercase tracking-wider text-ink/60">{t({ es: 'Personas sin contar', en: 'People uncounted' })}</dt>
                    <dd className="font-display text-3xl font-extrabold tabular-nums text-ink">{FUNDING_SCENARIO.uncounted}</dd>
                    <dd className="text-xs text-ink/60">{FUNDING_SCENARIO.population} × {FUNDING_SCENARIO.undercountShare}</dd>
                  </div>
                  <div>
                    <dt className="font-mono text-xs uppercase tracking-wider text-ink/60">{t({ es: 'Fondos por persona al año', en: 'Funds per person per year' })}</dt>
                    <dd className="font-display text-3xl font-extrabold tabular-nums text-ink">{t(FUNDING_SCENARIO.perCapita)}</dd>
                  </div>
                  <div>
                    <dt className="font-mono text-xs uppercase tracking-wider text-ink/60">{t({ es: 'Pérdida anual', en: 'Annual loss' })}</dt>
                    <dd className="font-display text-3xl font-extrabold tabular-nums text-coral-deep">{t(FUNDING_SCENARIO.annual)}</dd>
                  </div>
                  <div>
                    <dt className="font-mono text-xs uppercase tracking-wider text-ink/60">{t({ es: 'En los 10 años del censo', en: 'Over the 10-year census cycle' })}</dt>
                    <dd className="font-display text-3xl font-extrabold tabular-nums text-coral-deep">{t(FUNDING_SCENARIO.decade)}</dd>
                  </div>
                </dl>
                <p className="mt-5 border-t border-ink/20 pt-4 text-sm text-ink/75">
                  {t({
                    es: 'Supuestos: usa el extremo bajo del estimado de estructuras sin una dirección que se pueda validar (40%) como si todas esas personas quedaran fuera, y un rango aproximado de fondos federales por persona en programas que usan datos del Censo, como Medicaid, PAN, Título I, Head Start, WIC, Sección 8 y carreteras. El efecto real dependería de cuánta gente se recupere con trabajo de campo, y varios fondos grandes en Puerto Rico, como Medicaid y el PAN, tienen topes fijados por ley. Sirve para dimensionar lo que está en juego, no como estimado oficial.',
                    en: 'Assumptions: takes the low end of the estimate of structures without a verifiable address (40%) as if all those people were left out, and a rough range of federal funds per person in programs that use Census data, such as Medicaid, NAP, Title I, Head Start, WIC, Section 8, and highways. The real effect would depend on how many people field work recovers, and several large funding streams in Puerto Rico, such as Medicaid and NAP, are capped by statute. It shows the scale of what’s at stake, not an official estimate.',
                  })}
                </p>
              </div>
            </figure>
          </div>
        </section>

        {/* Districts */}
        <section id="distritos" className="scroll-mt-40">
          <SectionHead eyebrow={t({ es: 'Distritos electorales', en: 'Electoral districts' })} title={t({ es: 'Los mapas de Puerto Rico se dibujan con el Censo', en: 'Puerto Rico’s maps are drawn from the Census' })} />
          <div className="mt-8 grid gap-6 md:grid-cols-2">
            {DISTRICT_POINTS.map((p, i) => (
              <article key={p.title.en} className={`border-2 border-ink p-6 ${i === DISTRICT_POINTS.length - 1 ? 'bg-ink text-paper' : 'bg-paper'}`}>
                <h3 className={`font-display text-xl font-extrabold ${i === DISTRICT_POINTS.length - 1 ? 'text-coral' : 'text-ink'}`}>{t(p.title)}</h3>
                <p className={`mt-2 ${i === DISTRICT_POINTS.length - 1 ? 'text-paper/90' : 'text-ink/85'}`}>{t(p.body)}</p>
              </article>
            ))}
          </div>
          <div className="mt-6 grid grid-cols-2 gap-px border-2 border-ink bg-ink sm:w-fit">
            <div className="bg-paper px-6 py-4 text-center">
              <p className="font-display text-5xl font-extrabold text-ink">40</p>
              <p className="font-mono text-xs uppercase tracking-wider text-ink/70">{t({ es: 'distritos representativos', en: 'house districts' })}</p>
            </div>
            <div className="bg-paper px-6 py-4 text-center">
              <p className="font-display text-5xl font-extrabold text-ink">8</p>
              <p className="font-mono text-xs uppercase tracking-wider text-ink/70">{t({ es: 'distritos senatoriales', en: 'senate districts' })}</p>
            </div>
          </div>
        </section>

        {/* Asks */}
        <section id="pedidos" className="scroll-mt-40 border-2 border-ink bg-paper-deep p-8">
          <Eyebrow>{t({ es: 'Qué pedir en tu comentario', en: 'What to ask for in your comment' })}</Eyebrow>
          <h2 className="mt-2 font-display text-3xl font-extrabold text-ink">{t({ es: 'Ocho pedidos concretos a la Oficina del Censo', en: 'Eight concrete asks of the Census Bureau' })}</h2>
          <p className="mt-3 max-w-3xl text-ink/85">
            {t({
              es: 'Los comentarios desde Puerto Rico pesan más cuando nombran la sección, dan un dato local y piden algo específico.',
              en: 'Comments from Puerto Rico carry the most weight when they name the provision, give a local fact, and ask for something specific.',
            })}
          </p>
          <ol className="mt-6 grid gap-4 md:grid-cols-2">
            {ASKS.map((a, i) => (
              <li key={a.en} className="flex gap-3 border-2 border-ink bg-paper p-4">
                <span className="font-display text-2xl font-extrabold text-coral-deep">{i + 1}</span>
                <span className="text-ink/90">{t(a)}</span>
              </li>
            ))}
          </ol>
          <p className="mt-6 text-ink/85">
            <span className="font-bold text-ink">{t({ es: 'Quiénes deben comentar: ', en: 'Who should comment: ' })}</span>
            {t(WHO_SHOULD_COMMENT)}
          </p>
          <Link to="/comenta" className="riso-shadow-ink mt-8 inline-block border-2 border-ink bg-coral px-6 py-3 font-display text-lg font-extrabold text-ink">
            {t({ es: 'Escribe tu comentario →', en: 'Write your comment →' })}
          </Link>
        </section>

        <section>
          <p className="font-mono text-xs uppercase tracking-widest text-ink/60">{t({ es: 'Fuentes', en: 'Sources' })}</p>
          <p className="mt-2 max-w-3xl text-sm text-ink/75">
            {t({
              es: 'Los datos de la regla vienen del texto del Federal Register. Las afirmaciones marcadas como riesgo o inferencia razonan a partir del diseño de la regla; no son resultados medidos.',
              en: 'Facts about the rule come from the Federal Register text. Statements framed as risks or inferences reason from the rule’s design; they are not measured results.',
            })}
          </p>
          <ul className="mt-4 grid gap-2 text-sm md:grid-cols-2">
            {IMPACT_SOURCES.map((s) => (
              <li key={s.label} className="text-ink/85">
                {s.href ? (
                  <a href={s.href} target="_blank" rel="noreferrer" className="underline decoration-coral underline-offset-4 hover:text-coral-deep">{s.label} ↗</a>
                ) : (
                  s.label
                )}
              </li>
            ))}
          </ul>
        </section>
      </div>
    </>
  )
}
