import { Link } from '@tanstack/react-router'
import { Menu, X } from 'lucide-react'
import { useState } from 'react'
import { LINKS } from '@/content/site'
import { useLang } from '@/lib/i18n'
import { useCountdown } from './Countdown'
import { Logo } from './Star'

export const NAV = [
  { to: '/la-regla', label: { es: 'La regla', en: 'The rule' } },
  { to: '/impacto', label: { es: 'Impacto en PR', en: 'Impact on PR' } },
  { to: '/quienes-somos', label: { es: '¿Quiénes somos?', en: 'Who are we?' } },
  { to: '/comenta', label: { es: 'Escribe tu comentario', en: 'Write your comment' } },
  { to: '/herramientas', label: { es: 'Herramientas', en: 'Toolkit' } },
  { to: '/preguntas', label: { es: 'Preguntas', en: 'FAQ' } },
] as const

function LangToggle() {
  const { lang, setLang } = useLang()
  return (
    <div className="flex border-2 border-ink font-mono text-xs font-semibold" role="group" aria-label="Idioma / Language">
      {(['es', 'en'] as const).map((l) => (
        <button
          key={l}
          type="button"
          onClick={() => setLang(l)}
          aria-pressed={lang === l}
          className={`px-2.5 py-1 uppercase transition-colors ${lang === l ? 'bg-ink text-paper' : 'text-ink hover:bg-paper-deep'}`}
        >
          {l}
        </button>
      ))}
    </div>
  )
}

function DeadlineBar() {
  const { t } = useLang()
  const left = useCountdown()
  const daysText =
    left === undefined || left === null
      ? ''
      : t({ es: ` · Quedan ${left.days} días`, en: ` · ${left.days} days left` })
  return (
    <div className="bg-ink text-paper">
      <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-5 py-2 text-sm">
        <p className="font-mono text-xs tracking-wide sm:text-sm">
          <span className="mr-2 inline-block h-2 w-2 animate-pulse rounded-full bg-coral align-middle" />
          {t({ es: 'Los comentarios públicos cierran el 2 de noviembre de 2026', en: 'Public comments close November 2, 2026' })}
          {daysText}
        </p>
        <a href={LINKS.commentNow} target="_blank" rel="noreferrer" className="hidden shrink-0 font-semibold text-coral underline-offset-4 hover:underline sm:block">
          Regulations.gov →
        </a>
      </div>
    </div>
  )
}

export function SiteHeader() {
  const { t } = useLang()
  const [open, setOpen] = useState(false)
  return (
    <header className="sticky top-0 z-40">
      <DeadlineBar />
      <div className="border-b-2 border-ink bg-paper/95 backdrop-blur">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-5 py-3">
          <Link to="/" aria-label="Puerto Rico Cuenta" onClick={() => setOpen(false)}>
            <Logo />
          </Link>
          <nav className="hidden items-center gap-5 xl:flex" aria-label="Principal">
            {NAV.map((n) => (
              <Link
                key={n.to}
                to={n.to}
                className="text-sm font-semibold text-ink underline-offset-8 decoration-coral decoration-2 hover:underline"
                activeProps={{ className: 'underline' }}
              >
                {t(n.label)}
              </Link>
            ))}
          </nav>
          <div className="flex items-center gap-3">
            <LangToggle />
            <Link to="/comenta" className="riso-shadow-ink hidden border-2 border-ink bg-coral px-4 py-2 text-sm font-bold text-ink transition-transform hover:-translate-y-0.5 sm:block">
              {t({ es: 'Comenta ahora', en: 'Comment now' })}
            </Link>
            <button type="button" className="p-1 text-ink xl:hidden" onClick={() => setOpen(!open)} aria-expanded={open} aria-label={t({ es: 'Menú', en: 'Menu' })}>
              {open ? <X /> : <Menu />}
            </button>
          </div>
        </div>
        {open && (
          <nav className="border-t-2 border-ink bg-paper px-5 py-4 xl:hidden" aria-label="Móvil">
            {[{ to: '/', label: { es: 'Inicio', en: 'Home' } }, ...NAV].map((n) => (
              <Link key={n.to} to={n.to} onClick={() => setOpen(false)} className="block py-2.5 font-display text-2xl font-bold text-ink">
                {t(n.label)}
              </Link>
            ))}
          </nav>
        )}
      </div>
    </header>
  )
}
