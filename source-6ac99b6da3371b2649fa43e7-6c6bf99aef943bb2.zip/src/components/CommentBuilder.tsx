import { Check, Copy, Download, ExternalLink } from 'lucide-react'
import { useMemo, useState } from 'react'
import { CONCERNS, ROLES } from '@/content/comment'
import { LINKS, RULE } from '@/content/site'
import { type Lang, useLang } from '@/lib/i18n'

type OutLang = Lang | 'both'

const field = 'w-full border-2 border-ink bg-paper px-3 py-2.5 text-ink placeholder:text-ink/40 focus:bg-white'
const label = 'mb-1.5 block font-mono text-xs font-semibold uppercase tracking-wider text-ink'

function compose(lang: Lang, o: { role: string; place: string; name: string; story: string; concerns: string[] }) {
  const role = ROLES.find((r) => r.id === o.role) ?? ROLES[0]
  const where = o.place.trim() ? ` (${o.place.trim()})` : ''
  const head =
    lang === 'es'
      ? `A la Oficina del Censo de los Estados Unidos:\n\nRe: Docket No. ${RULE.docketNo}, RIN ${RULE.rin}, ${RULE.regsDocket}. “${RULE.title}”`
      : `To the U.S. Census Bureau:\n\nRe: Docket No. ${RULE.docketNo}, RIN ${RULE.rin}, ${RULE.regsDocket}. “${RULE.title}”`
  const intro =
    lang === 'es'
      ? `${role.intro.es}${where}. Someto este comentario para expresar mi oposición a las Partes 60 y 70 propuestas del Título 15 del Código de Regulaciones Federales, por el daño que causarían a un conteo completo y correcto de Puerto Rico y de los puertorriqueños.`
      : `${role.intro.en}${where}. I submit this comment to oppose proposed 15 CFR Parts 60 and 70 because of the harm they would cause to a complete and accurate count of Puerto Rico and of Puerto Ricans.`
  const story = o.story.trim()
  const body = CONCERNS.filter((c) => o.concerns.includes(c.id)).map((c) => c.paragraph[lang])
  const close =
    lang === 'es'
      ? 'Por estas razones, solicito que la Oficina del Censo retire la regla propuesta y garantice que todas las personas en Puerto Rico y en la diáspora sean contadas, una vez y en el lugar correcto.\n\nGracias por considerar este comentario.'
      : 'For these reasons, I ask the Census Bureau to withdraw the proposed rule and ensure that everyone in Puerto Rico and in the diaspora is counted, once, and in the right place.\n\nThank you for considering this comment.'
  return [head, intro, story, ...body, close, o.name.trim()].filter(Boolean).join('\n\n')
}

export function CommentBuilder() {
  const { t, lang } = useLang()
  const [role, setRole] = useState('resident')
  const [place, setPlace] = useState('')
  const [name, setName] = useState('')
  const [story, setStory] = useState('')
  const [concerns, setConcerns] = useState<string[]>(['silence', 'ethnicity', 'taxes'])
  const [outLang, setOutLang] = useState<OutLang>('en')
  const [copied, setCopied] = useState(false)

  const text = useMemo(() => {
    const o = { role, place, name, story, concerns }
    if (outLang === 'both') return `${compose('en', o)}\n\n— — —\n\n${compose('es', o)}`
    return compose(outLang, o)
  }, [role, place, name, story, concerns, outLang])

  const toggle = (id: string) =>
    setConcerns((c) => (c.includes(id) ? c.filter((x) => x !== id) : [...c, id]))

  async function copy() {
    await navigator.clipboard.writeText(text)
    setCopied(true)
    window.setTimeout(() => setCopied(false), 2500)
  }

  function download() {
    const url = URL.createObjectURL(new Blob([text], { type: 'text/plain;charset=utf-8' }))
    const a = Object.assign(document.createElement('a'), { href: url, download: 'comentario-censo-2030.txt' })
    a.click()
    URL.revokeObjectURL(url)
  }

  return (
    <div className="grid gap-8 lg:grid-cols-[1fr_1.1fr]">
      <div className="space-y-6">
        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <label htmlFor="cb-role" className={label}>{t({ es: '1 · Quién eres', en: '1 · Who you are' })}</label>
            <select id="cb-role" value={role} onChange={(e) => setRole(e.target.value)} className={field}>
              {ROLES.map((r) => <option key={r.id} value={r.id}>{t(r.label)}</option>)}
            </select>
          </div>
          <div>
            <label htmlFor="cb-place" className={label}>{t({ es: 'Municipio o ciudad', en: 'Municipio or city' })}</label>
            <input id="cb-place" value={place} onChange={(e) => setPlace(e.target.value)} placeholder={t({ es: 'Ej. Utuado, PR', en: 'e.g. Orlando, FL' })} className={field} />
          </div>
        </div>

        <fieldset>
          <legend className={label}>{t({ es: '2 · Lo que te preocupa', en: '2 · What concerns you' })}</legend>
          <div className="space-y-2">
            {CONCERNS.map((c) => {
              const on = concerns.includes(c.id)
              return (
                <label key={c.id} className={`flex cursor-pointer items-start gap-3 border-2 px-3 py-2.5 transition-colors ${on ? 'border-ink bg-coral/20' : 'border-ink/30 hover:border-ink'}`}>
                  <input type="checkbox" checked={on} onChange={() => toggle(c.id)} className="mt-1 h-4 w-4 accent-[var(--color-ink)]" />
                  <span className="font-semibold text-ink">{t(c.label)}</span>
                </label>
              )
            })}
          </div>
        </fieldset>

        <div>
          <label htmlFor="cb-story" className={label}>{t({ es: '3 · Tu historia (lo más importante)', en: '3 · Your story (the most important part)' })}</label>
          <textarea
            id="cb-story"
            rows={5}
            value={story}
            onChange={(e) => setStory(e.target.value)}
            className={field}
            placeholder={t({
              es: 'Ej.: Vivo en el campo y recibo la correspondencia en una ruta rural. Mi hija estudia en Florida y regresa cada verano. Después de María, mi familia pasó meses en Nueva York…',
              en: 'e.g.: I live in the countryside and get mail on a rural route. My daughter studies in Florida and comes home every summer. After Maria, my family spent months in New York…',
            })}
          />
          <p className="mt-1.5 text-xs text-ink/70">
            {t({
              es: 'Escríbela en tus propias palabras. Los comentarios únicos y concretos pesan más que las cartas idénticas.',
              en: 'Write it in your own words. Unique, concrete comments carry more weight than identical letters.',
            })}
          </p>
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <label htmlFor="cb-name" className={label}>{t({ es: 'Firma (opcional)', en: 'Signature (optional)' })}</label>
            <input id="cb-name" value={name} onChange={(e) => setName(e.target.value)} className={field} placeholder={t({ es: 'Tu nombre', en: 'Your name' })} />
          </div>
          <fieldset>
            <legend className={label}>{t({ es: 'Idioma del comentario', en: 'Comment language' })}</legend>
            <div className="grid grid-cols-3 border-2 border-ink">
              {(
                [
                  ['en', 'English'],
                  ['es', 'Español'],
                  ['both', lang === 'es' ? 'Ambos' : 'Both'],
                ] as const
              ).map(([v, l]) => (
                <button key={v} type="button" onClick={() => setOutLang(v)} aria-pressed={outLang === v} className={`py-2.5 text-sm font-semibold ${outLang === v ? 'bg-ink text-paper' : 'text-ink hover:bg-paper-deep'}`}>
                  {l}
                </button>
              ))}
            </div>
          </fieldset>
        </div>
      </div>

      <div className="lg:sticky lg:top-32 lg:self-start">
        <div className="riso-shadow border-2 border-ink bg-white">
          <div className="flex items-center justify-between border-b-2 border-ink bg-paper-deep px-4 py-2">
            <span className="font-mono text-xs font-semibold uppercase tracking-wider text-ink">{t({ es: 'Tu borrador', en: 'Your draft' })}</span>
            <span className="font-mono text-xs text-ink/60">{text.length.toLocaleString()} / 5,000</span>
          </div>
          <textarea
            readOnly
            value={text}
            aria-label={t({ es: 'Borrador del comentario', en: 'Comment draft' })}
            className="block h-[26rem] w-full resize-none bg-white p-4 font-mono text-[0.8rem] leading-relaxed text-ink-deep"
          />
        </div>
        {text.length > 5000 && (
          <p className="mt-3 text-sm font-semibold text-coral-deep">
            {t({
              es: 'Regulations.gov limita el cuadro de texto a 5,000 caracteres. Quita alguna preocupación o descarga el archivo y adjúntalo.',
              en: 'Regulations.gov limits the text box to 5,000 characters. Remove a concern, or download the file and attach it.',
            })}
          </p>
        )}
        <div className="mt-5 grid gap-3 sm:grid-cols-2">
          <button type="button" onClick={copy} className="flex items-center justify-center gap-2 border-2 border-ink bg-paper px-4 py-3 font-bold text-ink hover:bg-paper-deep">
            {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
            {copied ? t({ es: '¡Copiado!', en: 'Copied!' }) : t({ es: 'Copiar texto', en: 'Copy text' })}
          </button>
          <button type="button" onClick={download} className="flex items-center justify-center gap-2 border-2 border-ink bg-paper px-4 py-3 font-bold text-ink hover:bg-paper-deep">
            <Download className="h-4 w-4" />
            {t({ es: 'Descargar .txt', en: 'Download .txt' })}
          </button>
          <a href={LINKS.commentNow} target="_blank" rel="noreferrer" className="riso-shadow-ink flex items-center justify-center gap-2 border-2 border-ink bg-coral px-4 py-3.5 font-display text-lg font-extrabold text-ink transition-transform hover:-translate-y-0.5 sm:col-span-2">
            {t({ es: '4 · Pégalo en Regulations.gov', en: '4 · Paste it on Regulations.gov' })}
            <ExternalLink className="h-5 w-5" />
          </a>
        </div>
        <p className="mt-3 text-xs text-ink/70">
          {t({
            es: 'Todo lo que envíes allí será público. Para comentar de forma anónima, escribe “N/A” en los campos requeridos.',
            en: 'Everything you submit there is public. To comment anonymously, enter “N/A” in the required fields.',
          })}
        </p>
      </div>
    </div>
  )
}
